const btnCreateGroup = document.getElementById('btn-create-group');
const flowOverlay = document.getElementById('flow-overlay');
const closeFlow = document.getElementById('close-flow');
const node1 = document.getElementById('node-1');
const node2 = document.getElementById('node-2');
const btnNextNode = document.getElementById('btn-next-node');
const connector = document.getElementById('node-connector');
const contactSearch = document.getElementById('contact-search');

const checkMultipleGroups = document.getElementById('check-multiple-groups');
const inputMultipleQtd = document.getElementById('input-multiple-qtd');
const multipleGroupsHint = document.getElementById('multiple-groups-hint');

if (checkMultipleGroups && inputMultipleQtd) {
    checkMultipleGroups.addEventListener('change', (e) => {
        if (e.target.checked) {
            inputMultipleQtd.style.display = 'block';
            multipleGroupsHint.style.display = 'block';
        } else {
            inputMultipleQtd.style.display = 'none';
            multipleGroupsHint.style.display = 'none';
            inputMultipleQtd.value = '';
        }
    });
}

btnCreateGroup.addEventListener('click', () => {
    flowOverlay.classList.add('active');
    setTimeout(() => {
        node1.classList.add('active');
    }, 100);
});

closeFlow.addEventListener('click', () => {
    flowOverlay.classList.remove('active');
    node1.classList.remove('active');
    node2.classList.remove('active');
    connector.classList.remove('active');
    if (contactSearch) contactSearch.value = '';
    
    const contactItems = document.querySelectorAll('.contact-item');
    contactItems.forEach(item => {
        item.classList.remove('selected');
        item.style.display = 'flex';
    });

    if (checkMultipleGroups) checkMultipleGroups.checked = false;
    if (inputMultipleQtd) {
        inputMultipleQtd.style.display = 'none';
        inputMultipleQtd.value = '';
    }
    if (multipleGroupsHint) multipleGroupsHint.style.display = 'none';
});


btnNextNode.addEventListener('click', () => {
    connector.classList.add('active');
    setTimeout(() => {
        node2.classList.add('active');
    }, 300);
});

if (contactSearch) {
    contactSearch.addEventListener('input', (e) => {
        const term = e.target.value.toLowerCase();
        const items = document.querySelectorAll('.contact-item');
        
        items.forEach(item => {
            const name = item.querySelector('.contact-name').innerText.toLowerCase();
            const number = item.querySelector('.contact-number').innerText.toLowerCase();
            
            if (name.includes(term) || number.includes(term)) {
                item.style.display = 'flex';
            } else {
                item.style.display = 'none';
            }
        });
    });
}

const btnAddMembers = document.getElementById('btn-add-members');
const flowOverlayAdd = document.getElementById('flow-overlay-add-members');
const closeFlowAdd = document.getElementById('close-flow-add');
const nodeAdd1 = document.getElementById('node-add-1');
const nodeAdd2 = document.getElementById('node-add-2');
const btnNextNodeAdd = document.getElementById('btn-next-node-add');
const connectorAdd = document.getElementById('node-connector-add');

btnAddMembers.addEventListener('click', () => {
    flowOverlayAdd.classList.add('active');
    setTimeout(() => {
        nodeAdd1.classList.add('active');
    }, 100);
});

closeFlowAdd.addEventListener('click', () => {
    flowOverlayAdd.classList.remove('active');
    nodeAdd1.classList.remove('active');
    nodeAdd2.classList.remove('active');
    connectorAdd.classList.remove('active');
    
    const selectedItems = flowOverlayAdd.querySelectorAll('.contact-item.selected');
    selectedItems.forEach(item => item.classList.remove('selected'));

    if (typeof state !== 'undefined') {
        state.importedContactsToAdd = [];
    }
    const importedListContainer = document.getElementById('imported-list-container');
    if (importedListContainer) {
        importedListContainer.innerHTML = '<div style="text-align:center; color:var(--cp-text-muted); font-size:12px; margin-top: 20px;">Nenhum número importado</div>';
    }
});

btnNextNodeAdd.addEventListener('click', () => {
    if (!document.querySelector('#group-list-container .contact-item.selected')) {
        alert("Selecione um grupo primeiro!");
        return;
    }
    connectorAdd.classList.add('active');
    setTimeout(() => {
        nodeAdd2.classList.add('active');
    }, 300);
});

const groupSearchAdd = document.getElementById('group-search-add');
if (groupSearchAdd) {
    groupSearchAdd.addEventListener('input', (e) => {
        const term = e.target.value.toLowerCase();
        document.querySelectorAll('#group-list-container .contact-item').forEach(item => {
            const name = item.querySelector('.contact-name').innerText.toLowerCase();
            item.style.display = name.includes(term) ? 'flex' : 'none';
        });
    });
}

const contactSearchAdd = document.getElementById('contact-search-add');
if (contactSearchAdd) {
    contactSearchAdd.addEventListener('input', (e) => {
        const term = e.target.value.toLowerCase();
        document.querySelectorAll('#contact-list-add-container .contact-item').forEach(item => {
            const name = item.querySelector('.contact-name').innerText.toLowerCase();
            const number = item.querySelector('.contact-number').innerText.toLowerCase();
            item.style.display = (name.includes(term) || number.includes(term)) ? 'flex' : 'none';
        });
    });
}

document.getElementById('member-search-promote')?.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#member-list-promote-container .contact-item').forEach(item => {
        const name = item.querySelector('.contact-name').innerText.toLowerCase();
        item.style.display = name.includes(term) ? 'flex' : 'none';
    });
});

document.getElementById('member-search-demote')?.addEventListener('input', (e) => {
    
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#member-list-demote-container .contact-item').forEach(item => {
        const name = item.querySelector('.contact-name').innerText.toLowerCase();
        item.style.display = name.includes(term) ? 'flex' : 'none';
    });
});
// --- CORREÇÃO DOS BUGS DE PESQUISA ---

// Pesquisa de Grupos - Remover Membros
document.getElementById('group-search-remove')?.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#group-list-remove-container .contact-item').forEach(item => {
        const name = item.querySelector('.contact-name').innerText.toLowerCase();
        item.style.display = name.includes(term) ? 'flex' : 'none';
    });
});

// Pesquisa de Membros - Remover Membros
document.getElementById('member-search-remove')?.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#member-list-remove-container .contact-item').forEach(item => {
        const name = item.querySelector('.contact-name').innerText.toLowerCase();
        item.style.display = name.includes(term) ? 'flex' : 'none';
    });
});

// Pesquisa de Grupos - Promover Admin
document.getElementById('group-search-promote')?.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#group-list-promote-container .contact-item').forEach(item => {
        const name = item.querySelector('.contact-name').innerText.toLowerCase();
        item.style.display = name.includes(term) ? 'flex' : 'none';
    });
});

// Pesquisa de Grupos - Rebaixar Admin
document.getElementById('group-search-demote')?.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#group-list-demote-container .contact-item').forEach(item => {
        const name = item.querySelector('.contact-name').innerText.toLowerCase();
        item.style.display = name.includes(term) ? 'flex' : 'none';
    });
});
const btnLeaveGroupCard = document.getElementById('btn-leave-group-card');
const flowOverlayLeave = document.getElementById('flow-overlay-leave-group');
const closeFlowLeave = document.getElementById('close-flow-leave');
const nodeLeave1 = document.getElementById('node-leave-1');
const nodeLeave2 = document.getElementById('node-leave-2');
const connectorLeave = document.getElementById('node-connector-leave');

btnLeaveGroupCard?.addEventListener('click', () => {
    flowOverlayLeave.classList.add('active');
    setTimeout(() => {
        nodeLeave1.classList.add('active');
    }, 100);
});

closeFlowLeave?.addEventListener('click', () => {
    flowOverlayLeave.classList.remove('active');
    nodeLeave1.classList.remove('active');
    nodeLeave2.classList.remove('active');
    connectorLeave.classList.remove('active');
    
    const selectedItems = flowOverlayLeave.querySelectorAll('.contact-item.selected');
    selectedItems.forEach(item => item.classList.remove('selected'));
});

document.getElementById('group-search-leave')?.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#group-list-leave-container .contact-item').forEach(item => {
        const name = item.querySelector('.contact-name').innerText.toLowerCase();
        item.style.display = name.includes(term) ? 'flex' : 'none';
    });
});

const btnEditNameCard = document.getElementById('btn-edit-name-card');
const flowOverlayEditName = document.getElementById('flow-overlay-edit-name');
const closeFlowEditName = document.getElementById('close-flow-edit-name');
const nodeEditName1 = document.getElementById('node-edit-name-1');
const nodeEditName2 = document.getElementById('node-edit-name-2');
const btnNextNodeEditName = document.getElementById('btn-next-node-edit-name');
const connectorEditName = document.getElementById('node-connector-edit-name');
const groupSearchEditName = document.getElementById('group-search-edit-name');
const newGroupNameInput = document.getElementById('new-group-name-input');

btnEditNameCard?.addEventListener('click', () => {
    flowOverlayEditName.classList.add('active');
    setTimeout(() => {
        nodeEditName1.classList.add('active');
    }, 100);
});

closeFlowEditName?.addEventListener('click', () => {
    flowOverlayEditName.classList.remove('active');
    nodeEditName1.classList.remove('active');
    nodeEditName2.classList.remove('active');
    connectorEditName.classList.remove('active');
    
    if (groupSearchEditName) groupSearchEditName.value = '';
    if (newGroupNameInput) newGroupNameInput.value = '';
    
    const selectedItems = flowOverlayEditName.querySelectorAll('.contact-item.selected');
    selectedItems.forEach(item => item.classList.remove('selected'));
});

btnNextNodeEditName?.addEventListener('click', () => {
    if (!document.querySelector('#group-list-edit-name-container .contact-item.selected')) {
        alert("Selecione um grupo primeiro!");
        return;
    }
    connectorEditName.classList.add('active');
    setTimeout(() => {
        nodeEditName2.classList.add('active');
    }, 300);
});

groupSearchEditName?.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#group-list-edit-name-container .contact-item').forEach(item => {
        const name = item.querySelector('.contact-name').innerText.toLowerCase();
        item.style.display = name.includes(term) ? 'flex' : 'none';
    });
});

const btnEditImageCard = document.getElementById('btn-edit-image-card');
const flowOverlayEditImage = document.getElementById('flow-overlay-edit-image');
const closeFlowEditImage = document.getElementById('close-flow-edit-image');
const nodeEditImage1 = document.getElementById('node-edit-image-1');
const nodeEditImage2 = document.getElementById('node-edit-image-2');
const btnNextNodeEditImage = document.getElementById('btn-next-node-edit-image');
const connectorEditImage = document.getElementById('node-connector-edit-image');
const groupSearchEditImage = document.getElementById('group-search-edit-image');

btnEditImageCard?.addEventListener('click', () => {
    flowOverlayEditImage.classList.add('active');
    setTimeout(() => {
        nodeEditImage1.classList.add('active');
    }, 100);
});

closeFlowEditImage?.addEventListener('click', () => {
    flowOverlayEditImage.classList.remove('active');
    nodeEditImage1.classList.remove('active');
    nodeEditImage2.classList.remove('active');
    connectorEditImage.classList.remove('active');
    
    if (groupSearchEditImage) groupSearchEditImage.value = '';
    
    const selectedItems = flowOverlayEditImage.querySelectorAll('.contact-item.selected');
    selectedItems.forEach(item => item.classList.remove('selected'));

    const uploadBtnEdit = document.getElementById('edit-image-upload-btn');
    if (uploadBtnEdit) {
        uploadBtnEdit.style.backgroundImage = 'none';
        uploadBtnEdit.style.border = '';
        uploadBtnEdit.innerHTML = '<svg viewBox="0 0 24 24"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"></path></svg>';
    }
    
    if (window.state) {
        window.state.newGroupImageBase64 = null; 
    }
});

btnNextNodeEditImage?.addEventListener('click', () => {
    if (!document.querySelector('#group-list-edit-image-container .contact-item.selected')) {
        alert("Selecione um grupo primeiro!");
        return;
    }
    connectorEditImage.classList.add('active');
    setTimeout(() => {
        nodeEditImage2.classList.add('active');
    }, 300);
});

groupSearchEditImage?.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#group-list-edit-image-container .contact-item').forEach(item => {
        const name = item.querySelector('.contact-name').innerText.toLowerCase();
        item.style.display = name.includes(term) ? 'flex' : 'none';
    });
});

const btnExtractContactsCard = document.getElementById('btn-extract-contacts-card');
const flowOverlayExtract = document.getElementById('flow-overlay-extract');
const closeFlowExtract = document.getElementById('close-flow-extract');
const nodeExtract1 = document.getElementById('node-extract-1');
const groupSearchExtract = document.getElementById('group-search-extract');

btnExtractContactsCard?.addEventListener('click', () => {
    flowOverlayExtract.classList.add('active');
    setTimeout(() => {
        nodeExtract1.classList.add('active');
    }, 100);
});

closeFlowExtract?.addEventListener('click', () => {
    flowOverlayExtract.classList.remove('active');
    nodeExtract1.classList.remove('active');
    
    if (groupSearchExtract) groupSearchExtract.value = '';
    
    const selectedItems = flowOverlayExtract.querySelectorAll('.contact-item.selected');
    selectedItems.forEach(item => item.classList.remove('selected'));
    
    if (window.state) {
        window.state.selectedGroupToExtract = null;
    }
});

groupSearchExtract?.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#group-list-extract-container .contact-item').forEach(item => {
        const name = item.querySelector('.contact-name').innerText.toLowerCase();
        item.style.display = name.includes(term) ? 'flex' : 'none';
    });
});

const btnEditDescCard = document.getElementById('btn-edit-desc-card');
const flowOverlayEditDesc = document.getElementById('flow-overlay-edit-desc');
const closeFlowEditDesc = document.getElementById('close-flow-edit-desc');
const nodeEditDesc1 = document.getElementById('node-edit-desc-1');
const nodeEditDesc2 = document.getElementById('node-edit-desc-2');
const btnNextNodeEditDesc = document.getElementById('btn-next-node-edit-desc');
const connectorEditDesc = document.getElementById('node-connector-edit-desc');
const groupSearchEditDesc = document.getElementById('group-search-edit-desc');
const newGroupDescInput = document.getElementById('new-group-desc-input');

btnEditDescCard?.addEventListener('click', () => {
    flowOverlayEditDesc.classList.add('active');
    setTimeout(() => {
        nodeEditDesc1.classList.add('active');
    }, 100);
});

closeFlowEditDesc?.addEventListener('click', () => {
    flowOverlayEditDesc.classList.remove('active');
    nodeEditDesc1.classList.remove('active');
    nodeEditDesc2.classList.remove('active');
    connectorEditDesc.classList.remove('active');
    
    if (groupSearchEditDesc) groupSearchEditDesc.value = '';
    if (newGroupDescInput) newGroupDescInput.value = '';
    
    const selectedItems = flowOverlayEditDesc.querySelectorAll('.contact-item.selected');
    selectedItems.forEach(item => item.classList.remove('selected'));
});

btnNextNodeEditDesc?.addEventListener('click', () => {
    if (!document.querySelector('#group-list-edit-desc-container .contact-item.selected')) {
        alert("Selecione um grupo primeiro!");
        return;
    }
    connectorEditDesc.classList.add('active');
    setTimeout(() => {
        nodeEditDesc2.classList.add('active');
    }, 300);
});

groupSearchEditDesc?.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#group-list-edit-desc-container .contact-item').forEach(item => {
        const name = item.querySelector('.contact-name').innerText.toLowerCase();
        item.style.display = name.includes(term) ? 'flex' : 'none';
    });
});

const btnTransferMembersCard = document.getElementById('btn-transfer-members-card');
const flowOverlayTransfer = document.getElementById('flow-overlay-transfer-members');
const closeFlowTransfer = document.getElementById('close-flow-transfer');
const nodeTransfer1 = document.getElementById('node-transfer-1');
const nodeTransfer2 = document.getElementById('node-transfer-2');
const nodeTransfer3 = document.getElementById('node-transfer-3');
const btnNextNodeTransfer1 = document.getElementById('btn-next-node-transfer-1');
const btnNextNodeTransfer2 = document.getElementById('btn-next-node-transfer-2');
const connectorTransfer1 = document.getElementById('node-connector-transfer-1');
const connectorTransfer2 = document.getElementById('node-connector-transfer-2');
const groupSearchTransferSource = document.getElementById('group-search-transfer-source');
const groupSearchTransferTarget = document.getElementById('group-search-transfer-target');

btnTransferMembersCard?.addEventListener('click', () => {
    flowOverlayTransfer.classList.add('active');
    setTimeout(() => {
        nodeTransfer1.classList.add('active');
    }, 100);
});

closeFlowTransfer?.addEventListener('click', () => {
    flowOverlayTransfer.classList.remove('active');
    nodeTransfer1.classList.remove('active');
    nodeTransfer2.classList.remove('active');
    nodeTransfer3.classList.remove('active');
    connectorTransfer1.classList.remove('active');
    connectorTransfer2.classList.remove('active');
    
    if (groupSearchTransferSource) groupSearchTransferSource.value = '';
    if (groupSearchTransferTarget) groupSearchTransferTarget.value = '';
    
    const selectedItems = flowOverlayTransfer.querySelectorAll('.contact-item.selected');
    selectedItems.forEach(item => item.classList.remove('selected'));
    
    if (window.state) {
        window.state.selectedGroupTransferSource = null;
        window.state.selectedGroupTransferTarget = null;
    }
});

btnNextNodeTransfer1?.addEventListener('click', () => {
    if (!document.querySelector('#group-list-transfer-source-container .contact-item.selected')) {
        alert("Selecione um grupo de origem primeiro!");
        return;
    }
    connectorTransfer1.classList.add('active');
    setTimeout(() => {
        nodeTransfer2.classList.add('active');
    }, 300);
});

btnNextNodeTransfer2?.addEventListener('click', () => {
    if (!document.querySelector('#group-list-transfer-target-container .contact-item.selected')) {
        alert("Selecione um grupo de destino primeiro!");
        return;
    }
    connectorTransfer2.classList.add('active');
    setTimeout(() => {
        nodeTransfer3.classList.add('active');
    }, 300);
});

groupSearchTransferSource?.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#group-list-transfer-source-container .contact-item').forEach(item => {
        const name = item.querySelector('.contact-name').innerText.toLowerCase();
        item.style.display = name.includes(term) ? 'flex' : 'none';
    });
});

groupSearchTransferTarget?.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#group-list-transfer-target-container .contact-item').forEach(item => {
        const name = item.querySelector('.contact-name').innerText.toLowerCase();
        item.style.display = name.includes(term) ? 'flex' : 'none';
    });
});

const btnConfigGroupCard = document.getElementById('btn-config-group-card');
const flowOverlayConfig = document.getElementById('flow-overlay-config-group');
const closeFlowConfig = document.getElementById('close-flow-config');
const nodeConfig1 = document.getElementById('node-config-1');
const nodeConfig2 = document.getElementById('node-config-2');
const btnNextNodeConfig = document.getElementById('btn-next-node-config');
const connectorConfig = document.getElementById('node-connector-config');
const groupSearchConfig = document.getElementById('group-search-config');
const btnConfigAdmins = document.getElementById('btn-config-admins');
const btnConfigAll = document.getElementById('btn-config-all');

btnConfigGroupCard?.addEventListener('click', () => {
    flowOverlayConfig.classList.add('active');
    setTimeout(() => {
        nodeConfig1.classList.add('active');
    }, 100);
});

closeFlowConfig?.addEventListener('click', () => {
    flowOverlayConfig.classList.remove('active');
    nodeConfig1.classList.remove('active');
    nodeConfig2.classList.remove('active');
    connectorConfig.classList.remove('active');
    
    if (groupSearchConfig) groupSearchConfig.value = '';
    
    const selectedItems = flowOverlayConfig.querySelectorAll('.contact-item.selected');
    selectedItems.forEach(item => item.classList.remove('selected'));
    
    if (window.state) {
        window.state.selectedGroupToConfig = null;
    }
});

btnNextNodeConfig?.addEventListener('click', () => {
    if (!document.querySelector('#group-list-config-container .contact-item.selected')) {
        alert("Selecione um grupo primeiro!");
        return;
    }
    connectorConfig.classList.add('active');
    setTimeout(() => {
        nodeConfig2.classList.add('active');
    }, 300);
});

groupSearchConfig?.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#group-list-config-container .contact-item').forEach(item => {
        const name = item.querySelector('.contact-name').innerText.toLowerCase();
        item.style.display = name.includes(term) ? 'flex' : 'none';
    });
});

const resetConfigBtns = () => {
    if(!btnConfigAdmins || !btnConfigAll) return;
    
    btnConfigAdmins.style.borderColor = 'var(--cp-border)';
    btnConfigAdmins.style.background = 'transparent';
    btnConfigAdmins.style.color = 'var(--cp-text-muted)';
    btnConfigAdmins.style.boxShadow = 'none';
    btnConfigAdmins.classList.remove('selected');

    btnConfigAll.style.borderColor = 'var(--cp-border)';
    btnConfigAll.style.background = 'transparent';
    btnConfigAll.style.color = 'var(--cp-text-muted)';
    btnConfigAll.style.boxShadow = 'none';
    btnConfigAll.classList.remove('selected');
};

btnConfigAdmins?.addEventListener('click', () => {
    resetConfigBtns();
    btnConfigAdmins.style.borderColor = 'var(--cp-neon)';
    btnConfigAdmins.style.background = 'rgba(255, 102, 0, 0.1)';
    btnConfigAdmins.style.color = 'var(--cp-neon)';
    btnConfigAdmins.style.boxShadow = '0 0 10px rgba(255,102,0,0.2) inset';
    btnConfigAdmins.classList.add('selected');
});

btnConfigAll?.addEventListener('click', () => {
    resetConfigBtns();
    btnConfigAll.style.borderColor = 'var(--cp-neon)';
    btnConfigAll.style.background = 'rgba(255, 102, 0, 0.1)';
    btnConfigAll.style.color = 'var(--cp-neon)';
    btnConfigAll.style.boxShadow = '0 0 10px rgba(255,102,0,0.2) inset';
    btnConfigAll.classList.add('selected');
});

const navGroups = document.getElementById('nav-groups');
const navCampaigns = document.getElementById('nav-campaigns');
const navCommunities = document.getElementById('nav-communities');
const navChatbot = document.getElementById('nav-chatbot');
const navMonitoring = document.getElementById('nav-monitoring');

const sectionGroups = document.getElementById('section-groups');
const sectionCampaigns = document.getElementById('section-campaigns');
const sectionCommunities = document.getElementById('section-communities');
const sectionChatbot = document.getElementById('section-chatbot');
const sectionMonitoring = document.getElementById('section-monitoring');

function switchTab(activeNav, activeSection) {
    if (navGroups) navGroups.classList.remove('active');
    if (navCampaigns) navCampaigns.classList.remove('active');
    if (navCommunities) navCommunities.classList.remove('active');
    if (navChatbot) navChatbot.classList.remove('active');
    if (navMonitoring) navMonitoring.classList.remove('active');
    
    document.querySelectorAll('.section-content').forEach(sec => {
        sec.classList.remove('active');
    });
    
    if (activeNav) activeNav.classList.add('active');
    if (activeSection) activeSection.classList.add('active');
}

navGroups?.addEventListener('click', () => switchTab(navGroups, sectionGroups));
navCampaigns?.addEventListener('click', () => {
    switchTab(navCampaigns, sectionCampaigns);
    if (typeof loadGroupsForCampaign === 'function') loadGroupsForCampaign();
});
navCommunities?.addEventListener('click', () => switchTab(navCommunities, sectionCommunities));
navChatbot?.addEventListener('click', () => switchTab(navChatbot, sectionChatbot));
navMonitoring?.addEventListener('click', () => switchTab(navMonitoring, sectionMonitoring));

// Modais Gestão de Comunidades
const btnComSendCard = document.getElementById('btn-com-send-card');
const flowOverlayComSend = document.getElementById('flow-overlay-com-send');
const closeFlowComSend = document.getElementById('close-flow-com-send');
const nodeComSend1 = document.getElementById('node-com-send-1');
const nodeComSend2 = document.getElementById('node-com-send-2');
const btnNextNodeComSend1 = document.getElementById('btn-next-node-com-send-1');
const connectorComSend = document.getElementById('node-connector-com-send');

btnComSendCard?.addEventListener('click', () => {
    flowOverlayComSend.classList.add('active');
    setTimeout(() => { nodeComSend1.classList.add('active'); }, 100);
    // Carregar as comunidades ao abrir o modal
    if (typeof loadCommunitiesForSend === 'function') {
        loadCommunitiesForSend();
    }
});
closeFlowComSend?.addEventListener('click', () => {
    flowOverlayComSend.classList.remove('active');
    nodeComSend1.classList.remove('active');
    nodeComSend2.classList.remove('active');
    connectorComSend.classList.remove('active');
});
btnNextNodeComSend1?.addEventListener('click', () => {
    if (typeof state !== 'undefined' && !state.selectedCommunityForSend) {
        alert("Por favor, selecione uma comunidade antes de prosseguir.");
        return;
    }
    connectorComSend.classList.add('active');
    setTimeout(() => { nodeComSend2.classList.add('active'); }, 300);
});

// Vincular o botão de disparo
document.getElementById('btn-finish-com-send')?.addEventListener('click', () => {
    if (typeof handleCommunitySendSubmit === 'function') {
        handleCommunitySendSubmit();
    }
});

const btnComExtractCard = document.getElementById('btn-com-extract-card');
const flowOverlayComExtract = document.getElementById('flow-overlay-com-extract');
const closeFlowComExtract = document.getElementById('close-flow-com-extract');
const nodeComExtract1 = document.getElementById('node-com-extract-1');

btnComExtractCard?.addEventListener('click', () => {
    flowOverlayComExtract.classList.add('active');
    setTimeout(() => { nodeComExtract1.classList.add('active'); }, 100);
});
closeFlowComExtract?.addEventListener('click', () => {
    flowOverlayComExtract.classList.remove('active');
    nodeComExtract1.classList.remove('active');
});

const btnComReallocCard = document.getElementById('btn-com-realloc-card');
const flowOverlayComRealloc = document.getElementById('flow-overlay-com-realloc');
const closeFlowComRealloc = document.getElementById('close-flow-com-realloc');
const nodeComRealloc1 = document.getElementById('node-com-realloc-1');
const nodeComRealloc2 = document.getElementById('node-com-realloc-2');
const btnNextNodeComRealloc1 = document.getElementById('btn-next-node-com-realloc-1');
const connectorComRealloc1 = document.getElementById('node-connector-com-realloc-1');

btnComReallocCard?.addEventListener('click', () => {
    flowOverlayComRealloc.classList.add('active');
    setTimeout(() => { nodeComRealloc1.classList.add('active'); }, 100);
});
closeFlowComRealloc?.addEventListener('click', () => {
    flowOverlayComRealloc.classList.remove('active');
    nodeComRealloc1.classList.remove('active');
    nodeComRealloc2.classList.remove('active');
    connectorComRealloc1.classList.remove('active');
});
btnNextNodeComRealloc1?.addEventListener('click', () => {
    connectorComRealloc1.classList.add('active');
    setTimeout(() => { nodeComRealloc2.classList.add('active'); }, 300);
});


const btnCreateEvent = document.getElementById('btn-create-event');
const modalCreateEvent = document.getElementById('modal-create-event');
const closeEventModal = document.getElementById('close-event-modal');
const binderTabs = document.querySelectorAll('.binder-tab');
const binderPanes = document.querySelectorAll('.binder-pane');

if (btnCreateEvent) {
    btnCreateEvent.addEventListener('click', () => {
        modalCreateEvent.classList.add('active');
    });
}

if (closeEventModal) {
    closeEventModal.addEventListener('click', () => {
        modalCreateEvent.classList.remove('active');
    });
}

binderTabs.forEach(tab => {
    tab.addEventListener('click', () => {
        binderTabs.forEach(t => t.classList.remove('active'));
        binderPanes.forEach(p => p.classList.remove('active'));
        
        tab.classList.add('active');
        
        const targetId = tab.getAttribute('data-target');
        const targetPane = document.getElementById(targetId);
        if (targetPane) {
            targetPane.classList.add('active');
        }
    });
});
// --------------------------------- //

let editingBotEventId = null;

if (closeEventModal) {
    closeEventModal.addEventListener('click', () => {
        editingBotEventId = null;
    });
}

const btnTypeTextJoined = document.getElementById('btn-type-text-joined');
const btnTypeMediaJoined = document.getElementById('btn-type-media-joined');
const areaTextJoined = document.getElementById('area-text-joined');
const areaMediaJoined = document.getElementById('area-media-joined');
const btnSaveEventJoined = document.getElementById('btn-save-event-joined');
const eventsGrid = document.getElementById('events-grid');

let currentMediaBase64 = null;

if (btnTypeTextJoined && btnTypeMediaJoined) {
    btnTypeTextJoined.addEventListener('click', () => {
        btnTypeTextJoined.classList.add('active');
        btnTypeMediaJoined.classList.remove('active');
        areaTextJoined.style.display = 'flex';
        areaMediaJoined.style.display = 'none';
    });

    btnTypeMediaJoined.addEventListener('click', () => {
        btnTypeMediaJoined.classList.add('active');
        btnTypeTextJoined.classList.remove('active');
        areaMediaJoined.style.display = 'flex';
        areaTextJoined.style.display = 'none';
    });
}

const uploadMediaJoined = document.getElementById('upload-media-joined');
const fileMediaJoined = document.getElementById('file-media-joined');
if (uploadMediaJoined && fileMediaJoined) {
    uploadMediaJoined.addEventListener('click', () => {
        fileMediaJoined.click();
    });

    fileMediaJoined.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = (event) => {
            currentMediaBase64 = event.target.result;
            uploadMediaJoined.style.backgroundImage = `url(${currentMediaBase64})`;
            uploadMediaJoined.style.backgroundSize = 'cover';
            uploadMediaJoined.style.backgroundPosition = 'center';
            uploadMediaJoined.innerHTML = '';
            uploadMediaJoined.style.border = 'none';
        };
        reader.readAsDataURL(file);
    });
}

if (btnSaveEventJoined) {
    btnSaveEventJoined.addEventListener('click', async () => {
        const inputText = document.getElementById('input-text-joined').value;
        const isPrivate = document.getElementById('check-private-joined').checked;
        const isText = btnTypeTextJoined.classList.contains('active');

        if (isText && !inputText.trim()) {
            alert('Digite uma mensagem para o evento.');
            return;
        }
        if (!isText && !currentMediaBase64) {
            alert('Faça o upload de uma mídia primeiro.');
            return;
        }

        const eventId = editingBotEventId || ('evt_' + new Date().getTime());
        const eventData = {
            id: eventId,
            eventType: 'joined',
            isText: isText,
            content: inputText,
            mediaBase64: !isText ? currentMediaBase64 : null,
            isPrivate: isPrivate
        };

        if (editingBotEventId) {
            await window.removeBotEvent(editingBotEventId);
            const oldCard = document.getElementById(editingBotEventId);
            if (oldCard) oldCard.remove();
            editingBotEventId = null;
        }

        if (typeof window.addBotEvent === 'function') {
            await window.addBotEvent(eventData);
        }

        const emptyState = eventsGrid.querySelector('.card[style*="dashed"]');
        if (emptyState) emptyState.remove();

        const newCard = document.createElement('div');
        newCard.className = 'card';
        newCard.id = eventId;
        newCard.innerHTML = `
            <div class="event-badge badge-joined">ENTROU NO GRUPO</div>
            <div class="card-icon" style="margin-bottom: 15px;">
                <svg viewBox="0 0 24 24"><path d="M15 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm-9-2V7H4v3H1v2h3v3h2v-3h3v-2H6zm9 4c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"></path></svg>
            </div>
            <div class="card-title" style="font-size: 16px;">Mensagem de Boas-Vindas</div>
            <div class="card-desc" style="margin-bottom: 15px; flex-grow: 0;">
                Tipo: <strong style="color: var(--cp-text-main);">${isText ? 'Texto' : 'Mídia'}</strong><br>
                Destino: <strong style="color: var(--cp-text-main);">${isPrivate ? 'Privado' : 'No Grupo'}</strong>
            </div>
            <div style="display: flex; gap: 10px; margin-top: auto;">
                <button class="card-btn btn-edit-event" style="border-color: #ffcc00; color: #ffcc00; flex: 1;">Editar</button>
                <button class="card-btn btn-delete-event" style="border-color: #ff5555; color: #ff5555; flex: 1;">Excluir</button>
            </div>
        `;

        newCard.querySelector('.btn-edit-event').addEventListener('click', () => {
            editingBotEventId = eventData.id;
            document.getElementById('modal-create-event').classList.add('active');
            document.querySelector('[data-target="tab-joined"]').click();
            
            document.getElementById('input-text-joined').value = eventData.content || '';
            document.getElementById('check-private-joined').checked = eventData.isPrivate;
            
            if (eventData.isText) {
                btnTypeTextJoined.click();
            } else {
                btnTypeMediaJoined.click();
                currentMediaBase64 = eventData.mediaBase64;
                uploadMediaJoined.style.backgroundImage = `url(${currentMediaBase64})`;
                uploadMediaJoined.style.backgroundSize = 'cover';
                uploadMediaJoined.style.backgroundPosition = 'center';
                uploadMediaJoined.innerHTML = '';
                uploadMediaJoined.style.border = 'none';
            }
        });

        newCard.querySelector('.btn-delete-event').addEventListener('click', async () => {
            if (typeof window.removeBotEvent === 'function') await window.removeBotEvent(eventId);
            newCard.remove();
            if (eventsGrid.children.length === 0) {
                eventsGrid.innerHTML = '<div class="card" style="border-style: dashed; border-color: var(--cp-border); align-items: center; justify-content: center; opacity: 0.5;"><div class="card-title" style="margin-bottom: 0;">Nenhum evento criado</div></div>';
            }
        });

        eventsGrid.appendChild(newCard);
        document.getElementById('modal-create-event').classList.remove('active');

        document.getElementById('input-text-joined').value = '';
        document.getElementById('check-private-joined').checked = false;
        currentMediaBase64 = null;
        if (uploadMediaJoined) {
            uploadMediaJoined.style.backgroundImage = 'none';
            uploadMediaJoined.style.border = '';
            uploadMediaJoined.innerHTML = '<svg viewBox="0 0 24 24" style="width: 30px; height: 30px; fill: currentColor; margin-bottom: 10px;"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 10h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"></path></svg><span>Clique para anexar Imagem ou Vídeo</span>';
        }
        btnTypeTextJoined.click(); 
    });
}

const btnTypeTextLeft = document.getElementById('btn-type-text-left');
const btnTypeMediaLeft = document.getElementById('btn-type-media-left');
const areaTextLeft = document.getElementById('area-text-left');
const areaMediaLeft = document.getElementById('area-media-left');
const btnSaveEventLeft = document.getElementById('btn-save-event-left');
let currentMediaBase64Left = null;

if (btnTypeTextLeft && btnTypeMediaLeft) {
    btnTypeTextLeft.addEventListener('click', () => {
        btnTypeTextLeft.classList.add('active');
        btnTypeMediaLeft.classList.remove('active');
        areaTextLeft.style.display = 'flex';
        areaMediaLeft.style.display = 'none';
    });

    btnTypeMediaLeft.addEventListener('click', () => {
        btnTypeMediaLeft.classList.add('active');
        btnTypeTextLeft.classList.remove('active');
        areaMediaLeft.style.display = 'flex';
        areaTextLeft.style.display = 'none';
    });
}

const uploadMediaLeft = document.getElementById('upload-media-left');
const fileMediaLeft = document.getElementById('file-media-left');
if (uploadMediaLeft && fileMediaLeft) {
    uploadMediaLeft.addEventListener('click', () => {
        fileMediaLeft.click();
    });

    fileMediaLeft.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = (event) => {
            currentMediaBase64Left = event.target.result;
            uploadMediaLeft.style.backgroundImage = `url(${currentMediaBase64Left})`;
            uploadMediaLeft.style.backgroundSize = 'cover';
            uploadMediaLeft.style.backgroundPosition = 'center';
            uploadMediaLeft.innerHTML = '';
            uploadMediaLeft.style.border = 'none';
        };
        reader.readAsDataURL(file);
    });
}

if (btnSaveEventLeft) {
    btnSaveEventLeft.addEventListener('click', async () => {
        const inputText = document.getElementById('input-text-left').value;
        const isPrivate = document.getElementById('check-private-left').checked;
        const isText = btnTypeTextLeft.classList.contains('active');

        if (isText && !inputText.trim()) {
            alert('Digite uma mensagem para o evento.');
            return;
        }
        if (!isText && !currentMediaBase64Left) {
            alert('Faça o upload de uma mídia primeiro.');
            return;
        }

        const eventId = editingBotEventId || ('evt_' + new Date().getTime());
        const eventData = {
            id: eventId,
            eventType: 'left',
            isText: isText,
            content: inputText,
            mediaBase64: !isText ? currentMediaBase64Left : null,
            isPrivate: isPrivate
        };

        if (editingBotEventId) {
            await window.removeBotEvent(editingBotEventId);
            const oldCard = document.getElementById(editingBotEventId);
            if (oldCard) oldCard.remove();
            editingBotEventId = null;
        }

        if (typeof window.addBotEvent === 'function') {
            await window.addBotEvent(eventData);
        }

        const emptyState = eventsGrid.querySelector('.card[style*="dashed"]');
        if (emptyState) emptyState.remove();

        const newCard = document.createElement('div');
        newCard.className = 'card';
        newCard.id = eventId;
        newCard.innerHTML = `
            <div class="event-badge badge-left">SAIU DO GRUPO</div>
            <div class="card-icon" style="margin-bottom: 15px;">
                <svg viewBox="0 0 24 24"><path d="M10.09 15.59L11.5 17l5-5-5-5-1.41 1.41L12.67 11H3v2h9.67l-2.58 2.59zM19 3H5c-1.11 0-2 .9-2 2v4h2V5h14v14H5v-4H3v4c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z"></path></svg>
            </div>
            <div class="card-title" style="font-size: 16px;">Mensagem de Despedida</div>
            <div class="card-desc" style="margin-bottom: 15px; flex-grow: 0;">
                Tipo: <strong style="color: var(--cp-text-main);">${isText ? 'Texto' : 'Mídia'}</strong><br>
                Destino: <strong style="color: var(--cp-text-main);">${isPrivate ? 'Privado' : 'No Grupo'}</strong>
            </div>
            <div style="display: flex; gap: 10px; margin-top: auto;">
                <button class="card-btn btn-edit-event" style="border-color: #ffcc00; color: #ffcc00; flex: 1;">Editar</button>
                <button class="card-btn btn-delete-event" style="border-color: #ff5555; color: #ff5555; flex: 1;">Excluir</button>
            </div>
        `;

        newCard.querySelector('.btn-edit-event').addEventListener('click', () => {
            editingBotEventId = eventData.id;
            document.getElementById('modal-create-event').classList.add('active');
            document.querySelector('[data-target="tab-left"]').click();
            
            document.getElementById('input-text-left').value = eventData.content || '';
            document.getElementById('check-private-left').checked = eventData.isPrivate;
            
            if (eventData.isText) {
                btnTypeTextLeft.click();
            } else {
                btnTypeMediaLeft.click();
                currentMediaBase64Left = eventData.mediaBase64;
                uploadMediaLeft.style.backgroundImage = `url(${currentMediaBase64Left})`;
                uploadMediaLeft.style.backgroundSize = 'cover';
                uploadMediaLeft.style.backgroundPosition = 'center';
                uploadMediaLeft.innerHTML = '';
                uploadMediaLeft.style.border = 'none';
            }
        });

        newCard.querySelector('.btn-delete-event').addEventListener('click', async () => {
            if (typeof window.removeBotEvent === 'function') await window.removeBotEvent(eventId);
            newCard.remove();
            if (eventsGrid.children.length === 0) {
                eventsGrid.innerHTML = '<div class="card" style="border-style: dashed; border-color: var(--cp-border); align-items: center; justify-content: center; opacity: 0.5;"><div class="card-title" style="margin-bottom: 0;">Nenhum evento criado</div></div>';
            }
        });

        eventsGrid.appendChild(newCard);
        document.getElementById('modal-create-event').classList.remove('active');

        document.getElementById('input-text-left').value = '';
        document.getElementById('check-private-left').checked = false;
        currentMediaBase64Left = null;
        if (uploadMediaLeft) {
            uploadMediaLeft.style.backgroundImage = 'none';
            uploadMediaLeft.style.border = '';
            uploadMediaLeft.innerHTML = '<svg viewBox="0 0 24 24" style="width: 30px; height: 30px; fill: currentColor; margin-bottom: 10px;"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 10h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"></path></svg><span>Clique para anexar Imagem ou Vídeo</span>';
        }
        btnTypeTextLeft.click(); 
    });
}

const btnTypeTextResponse = document.getElementById('btn-type-text-response');
const btnTypeMediaResponse = document.getElementById('btn-type-media-response');
const areaTextResponse = document.getElementById('area-text-response');
const areaMediaResponse = document.getElementById('area-media-response');
const btnSaveEventResponse = document.getElementById('btn-save-event-response');
let currentMediaBase64Response = null;

if (btnTypeTextResponse && btnTypeMediaResponse) {
    btnTypeTextResponse.addEventListener('click', () => {
        btnTypeTextResponse.classList.add('active');
        btnTypeMediaResponse.classList.remove('active');
        areaTextResponse.style.display = 'flex';
        areaMediaResponse.style.display = 'none';
    });

    btnTypeMediaResponse.addEventListener('click', () => {
        btnTypeMediaResponse.classList.add('active');
        btnTypeTextResponse.classList.remove('active');
        areaMediaResponse.style.display = 'flex';
        areaTextResponse.style.display = 'none';
    });
}

const uploadMediaResponse = document.getElementById('upload-media-response');
const fileMediaResponse = document.getElementById('file-media-response');
if (uploadMediaResponse && fileMediaResponse) {
    uploadMediaResponse.addEventListener('click', () => {
        fileMediaResponse.click();
    });

    fileMediaResponse.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = (event) => {
            currentMediaBase64Response = event.target.result;
            uploadMediaResponse.style.backgroundImage = `url(${currentMediaBase64Response})`;
            uploadMediaResponse.style.backgroundSize = 'cover';
            uploadMediaResponse.style.backgroundPosition = 'center';
            uploadMediaResponse.innerHTML = '';
            uploadMediaResponse.style.border = 'none';
        };
        reader.readAsDataURL(file);
    });
}

if (btnSaveEventResponse) {
    btnSaveEventResponse.addEventListener('click', async () => {
        const keyword = document.getElementById('input-keyword-response').value;
        const inputText = document.getElementById('input-text-response').value;
        const isPrivate = document.getElementById('check-private-response').checked;
        const deleteMsg = document.getElementById('check-delete-msg').checked;
        const removeUser = document.getElementById('check-remove-user').checked;
        const isText = btnTypeTextResponse.classList.contains('active');

        if (!keyword.trim()) {
            alert('A palavra-chave é obrigatória!');
            return;
        }

        const eventId = editingBotEventId || ('evt_' + new Date().getTime());
        const eventData = {
            id: eventId,
            eventType: 'response',
            keyword: keyword.trim(),
            isText: isText,
            content: inputText,
            mediaBase64: !isText ? currentMediaBase64Response : null,
            isPrivate: isPrivate,
            deleteMsg: deleteMsg,
            removeUser: removeUser
        };

        if (editingBotEventId) {
            await window.removeBotEvent(editingBotEventId);
            const oldCard = document.getElementById(editingBotEventId);
            if (oldCard) oldCard.remove();
            editingBotEventId = null;
        }

        if (typeof window.addBotEvent === 'function') {
            await window.addBotEvent(eventData);
        }

        const emptyState = eventsGrid.querySelector('.card[style*="dashed"]');
        if (emptyState) emptyState.remove();

        const newCard = document.createElement('div');
        newCard.className = 'card';
        newCard.id = eventId;
        
        let tagsHTML = '';
        if (deleteMsg) tagsHTML += '<span style="color:#ffcc00; font-size:10px; border:1px solid rgba(255,204,0,0.3); background:rgba(255,204,0,0.1); padding:2px 4px; border-radius:4px; margin-right:5px;">EXCLUI MSG</span>';
        if (removeUser) tagsHTML += '<span style="color:#ff5555; font-size:10px; border:1px solid rgba(255,85,85,0.3); background:rgba(255,85,85,0.1); padding:2px 4px; border-radius:4px;">BAN</span>';

        newCard.innerHTML = `
            <div class="event-badge badge-response">RESPOSTA / MODERAÇÃO</div>
            <div class="card-icon" style="margin-bottom: 15px;">
                <svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"></path></svg>
            </div>
            <div class="card-title" style="font-size: 16px;">Gatilho: "${keyword}"</div>
            <div class="card-desc" style="margin-bottom: 15px; flex-grow: 0;">
                <div style="margin-bottom: 5px;">${tagsHTML}</div>
                Ação: <strong style="color: var(--cp-text-main);">${inputText || currentMediaBase64Response ? 'Responde' : 'Apenas Modera'}</strong>
            </div>
            <div style="display: flex; gap: 10px; margin-top: auto;">
                <button class="card-btn btn-edit-event" style="border-color: #ffcc00; color: #ffcc00; flex: 1;">Editar</button>
                <button class="card-btn btn-delete-event" style="border-color: #ff5555; color: #ff5555; flex: 1;">Excluir</button>
            </div>
        `;

        newCard.querySelector('.btn-edit-event').addEventListener('click', () => {
            editingBotEventId = eventData.id;
            document.getElementById('modal-create-event').classList.add('active');
            document.querySelector('[data-target="tab-response"]').click();
            
            document.getElementById('input-keyword-response').value = eventData.keyword || '';
            document.getElementById('input-text-response').value = eventData.content || '';
            document.getElementById('check-private-response').checked = eventData.isPrivate;
            document.getElementById('check-delete-msg').checked = eventData.deleteMsg;
            document.getElementById('check-remove-user').checked = eventData.removeUser;
            
            if (eventData.isText) {
                btnTypeTextResponse.click();
            } else {
                btnTypeMediaResponse.click();
                currentMediaBase64Response = eventData.mediaBase64;
                if(currentMediaBase64Response){
                    uploadMediaResponse.style.backgroundImage = `url(${currentMediaBase64Response})`;
                    uploadMediaResponse.style.backgroundSize = 'cover';
                    uploadMediaResponse.style.backgroundPosition = 'center';
                    uploadMediaResponse.innerHTML = '';
                    uploadMediaResponse.style.border = 'none';
                }
            }
        });

        newCard.querySelector('.btn-delete-event').addEventListener('click', async () => {
            if (typeof window.removeBotEvent === 'function') await window.removeBotEvent(eventId);
            newCard.remove();
            if (eventsGrid.children.length === 0) {
                eventsGrid.innerHTML = '<div class="card" style="border-style: dashed; border-color: var(--cp-border); align-items: center; justify-content: center; opacity: 0.5;"><div class="card-title" style="margin-bottom: 0;">Nenhum evento criado</div></div>';
            }
        });

        eventsGrid.appendChild(newCard);
        document.getElementById('modal-create-event').classList.remove('active');

        document.getElementById('input-keyword-response').value = '';
        document.getElementById('input-text-response').value = '';
        document.getElementById('check-private-response').checked = false;
        document.getElementById('check-delete-msg').checked = false;
        document.getElementById('check-remove-user').checked = false;
        currentMediaBase64Response = null;
        if (uploadMediaResponse) {
            uploadMediaResponse.style.backgroundImage = 'none';
            uploadMediaResponse.style.border = '';
            uploadMediaResponse.innerHTML = '<svg viewBox="0 0 24 24" style="width: 30px; height: 30px; fill: currentColor; margin-bottom: 10px;"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 10h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"></path></svg><span>Clique para anexar Imagem, Vídeo ou Áudio</span>';
        }
        btnTypeTextResponse.click(); 
    });
}

const uploadFileAddBtn = document.getElementById('upload-file-add-btn');
const fileAddMembers = document.getElementById('file-add-members');
const importedListContainer = document.getElementById('imported-list-container');
const inputDddAdd = document.getElementById('input-ddd-add');
const btnApplyDdd = document.getElementById('btn-apply-ddd');

if (uploadFileAddBtn && fileAddMembers) {
    uploadFileAddBtn.addEventListener('click', () => {
        fileAddMembers.click();
    });

    fileAddMembers.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
            const text = event.target.result;
            const lines = text.split('\n');
            state.importedContactsToAdd = [];

            lines.forEach(line => {
                const cleanNumber = line.replace(/\D/g, "");
                if (cleanNumber.length >= 8) {
                    state.importedContactsToAdd.push(cleanNumber);
                }
            });

            renderImportedList();
            fileAddMembers.value = ''; 
        };
        reader.readAsText(file);
    });
}

if (btnApplyDdd && inputDddAdd) {
    btnApplyDdd.addEventListener('click', () => {
        const ddd = inputDddAdd.value.replace(/\D/g, "");
        if (!ddd) return;

        state.importedContactsToAdd = state.importedContactsToAdd.map(num => ddd + num);
        renderImportedList();
        inputDddAdd.value = '';
    });
}

function renderImportedList() {
    if (!importedListContainer) return;
    importedListContainer.innerHTML = '';

    if (state.importedContactsToAdd.length === 0) {
        importedListContainer.innerHTML = '<div style="text-align:center; color:var(--cp-text-muted); font-size:12px; margin-top: 20px;">Nenhum número importado</div>';
        return;
    }

    state.importedContactsToAdd.forEach((num, index) => {
        const item = document.createElement('div');
        item.className = 'contact-item';
        item.style.marginBottom = '5px';
        item.innerHTML = `
            <div class="contact-avatar" style="width: 30px; height: 30px; font-size: 12px; margin-right: 10px;">#</div>
            <div class="contact-info" style="flex: 1;">
                <span class="contact-name">+${num}</span>
            </div>
            <button class="card-btn" style="width: auto; padding: 5px 10px; border-color: #ff5555; color: #ff5555; margin-left: 10px;" data-index="${index}">X</button>
        `;

        item.querySelector('button').addEventListener('click', (e) => {
            const idx = e.target.getAttribute('data-index');
            state.importedContactsToAdd.splice(idx, 1);
            renderImportedList();
        });

        importedListContainer.appendChild(item);
    });
}

let chartInstances = [];
let monitoringInterval = null;

function initCharts() {
    for (let i = 0; i < 8; i++) {
        const ctx = document.getElementById(`chart-${i}`);
        if (!ctx) continue;
        
        // Trava absoluta de largura/altura para o ChartJS não explodir a tela
        ctx.width = 60;
        ctx.height = 60;
        
        const chart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Mensagens do Grupo', 'Outros Grupos'],
                datasets: [{
                    data: [0, 1],
                    backgroundColor: ['#ffaa00', 'rgba(255, 170, 0, 0.1)'],
                    borderWidth: 0,
                    borderRadius: 4,
                    hoverOffset: 0
                }]
            },
            options: {
                responsive: false, // <-- ISTO RESOLVE O BUG GRÁFICO!
                maintainAspectRatio: false,
                cutout: '75%',
                animation: {
                    animateScale: true,
                    animateRotate: true
                },
                plugins: {
                    legend: { display: false },
                    tooltip: { enabled: false }
                }
            }
        });
        chartInstances.push(chart);
    }
}

async function updateMonitoringUI() {
    if (!sectionMonitoring.classList.contains('active')) return;
    
    const stats = await getTopActiveGroups();
    if (!stats || stats.top.length === 0) return;

    for (let i = 0; i < 8; i++) {
        const titleEl = document.getElementById(`mon-title-${i}`);
        const countEl = document.getElementById(`mon-count-${i}`);
        const topUsersEl = document.getElementById(`mon-top-${i}`);
        const chart = chartInstances[i];
        
        if (i < stats.top.length) {
            const groupData = stats.top[i];
            
            if (titleEl) titleEl.innerText = groupData.name;
            if (countEl) countEl.innerText = `${groupData.count} msgs`;
            
            if (topUsersEl && groupData.topUsers) {
                let html = '<div class="mon-top-title">Membros mais ativos</div>';
                if (groupData.topUsers.length === 0) {
                    html += '<div class="top-user-item"><span class="top-user-name" style="color:var(--cp-text-muted);">A processar dados...</span></div>';
                } else {
                    groupData.topUsers.forEach((u, index) => {
                        html += `
                            <div class="top-user-item">
                                <span class="top-user-name">${index + 1}. ${u.name}</span>
                                <span class="top-user-count">${u.count}</span>
                            </div>
                        `;
                    });
                }
                topUsersEl.innerHTML = html;
            }
            
            if (chart) {
                const othersCount = stats.total - groupData.count;
                chart.data.datasets[0].data = [groupData.count, othersCount < 0 ? 0 : othersCount];
                chart.update();
            }
        } else {
            if (titleEl) titleEl.innerText = 'Aguardando...';
            if (countEl) countEl.innerText = '-';
            if (topUsersEl) topUsersEl.innerHTML = '';
            
            if (chart) {
                chart.data.datasets[0].data = [0, 1];
                chart.update();
            }
        }
    }
}
navMonitoring?.addEventListener('click', () => {
    if (chartInstances.length === 0) {
        initCharts();
    }
    if (!monitoringInterval) {
        updateMonitoringUI();
        monitoringInterval = setInterval(updateMonitoringUI, 3000);
    }
    
    if (typeof loadGroupsLinksForMonitoring === 'function') {
        loadGroupsLinksForMonitoring();
    }
});

document.getElementById('btn-reset-all-links')?.addEventListener('click', () => {
    if (typeof handleResetAllLinks === 'function') {
        handleResetAllLinks();
    }
});

navGroups?.addEventListener('click', () => { clearInterval(monitoringInterval); monitoringInterval = null; });
navChatbot?.addEventListener('click', () => { clearInterval(monitoringInterval); monitoringInterval = null; });

const btnAddCampText = document.getElementById('btn-add-camp-text');
const btnAddCampImage = document.getElementById('btn-add-camp-image');
const campFlowContainer = document.getElementById('campaign-flow-container');
const campEmptyState = document.getElementById('camp-empty-state');
const btnSendCampaign = document.getElementById('btn-send-campaign');
const campGroupSearch = document.getElementById('campaign-group-search');

campGroupSearch?.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#campaign-group-list .contact-item').forEach(item => {
        const name = item.querySelector('.contact-name').innerText.toLowerCase();
        item.style.display = name.includes(term) ? 'flex' : 'none';
    });
});

document.getElementById('btn-select-all-groups')?.addEventListener('click', () => {
    const items = document.querySelectorAll('#campaign-group-list .contact-item');
    const allSelected = Array.from(items).every(item => item.classList.contains('selected'));

    items.forEach(item => {
        if (item.style.display === 'none') return;

        if (allSelected) {
            item.classList.remove('selected');
            state.selectedGroupsForCampaign = state.selectedGroupsForCampaign.filter(gId => gId !== item.dataset.id);
        } else {
            if (!item.classList.contains('selected')) {
                item.classList.add('selected');
                if (!state.selectedGroupsForCampaign.includes(item.dataset.id)) {
                    state.selectedGroupsForCampaign.push(item.dataset.id);
                }
            }
        }
    });
});

function checkCampEmptyState() {
    if (!campEmptyState) return;
    const items = campFlowContainer.querySelectorAll('.camp-flow-item');
    campEmptyState.style.display = items.length > 0 ? 'none' : 'block';
}

function addCampaignDelayBlock(value = 10) {
    const div = document.createElement('div');
    div.className = 'camp-flow-delay';
    div.innerHTML = `
        <svg viewBox="0 0 24 24" style="width: 16px; height: 16px; fill: var(--cp-neon);"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"></path></svg>
        <span style="color: var(--cp-text-muted); font-size: 12px; font-family: var(--font-cyber);">DELAY:</span>
        <input type="number" class="camp-delay-input" min="1" max="300" value="${value}">
        <span style="color: var(--cp-text-muted); font-size: 12px;">SEG</span>
    `;
    return div;
}

function handleAppendFlowItem(div) {
    const items = campFlowContainer.querySelectorAll('.camp-flow-item');
    if (items.length > 0) {
        campFlowContainer.appendChild(addCampaignDelayBlock());
    }
    campFlowContainer.appendChild(div);
    checkCampEmptyState();
}

function handleRemoveFlowItem(div) {
    if (div.previousElementSibling && div.previousElementSibling.classList.contains('camp-flow-delay')) {
        div.previousElementSibling.remove();
    } else if (div.nextElementSibling && div.nextElementSibling.classList.contains('camp-flow-delay')) {
        div.nextElementSibling.remove();
    }
    div.remove();
    checkCampEmptyState();
}

btnAddCampText?.addEventListener('click', () => {
    const div = document.createElement('div');
    div.className = 'card camp-flow-item';
    div.dataset.type = 'text';
    div.style.padding = '15px';
    div.style.flexShrink = '0'; 
    div.innerHTML = `
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px; align-items: center;">
            <span style="color: var(--cp-neon); font-family: var(--font-cyber); font-size: 12px;">MENSAGEM DE TEXTO</span>
            <button class="card-btn btn-remove-item" style="width: auto; padding: 5px 10px; border-color: #ff5555; color: #ff5555;">X</button>
        </div>
        <textarea class="event-textarea camp-val-text" placeholder="Digite sua mensagem aqui..."></textarea>
        <div style="display: flex; align-items: center; gap: 10px; margin-top: 10px;">
            <label class="cyber-checkbox-container">
                <input type="checkbox" class="camp-mention-all">
                <span class="cyber-checkmark"></span>
                Mencionar todos os membros
            </label>
        </div>
    `;
    
    div.querySelector('.btn-remove-item').addEventListener('click', () => {
        handleRemoveFlowItem(div);
    });

    handleAppendFlowItem(div);
});

btnAddCampImage?.addEventListener('click', () => {
    const id = 'camp_img_' + Date.now();
    const div = document.createElement('div');
    div.className = 'card camp-flow-item';
    div.dataset.type = 'image';
    div.style.padding = '15px';
    div.style.flexShrink = '0';
    div.innerHTML = `
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px; align-items: center;">
            <span style="color: var(--cp-neon); font-family: var(--font-cyber); font-size: 12px;">MÍDIA (IMAGEM)</span>
            <button class="card-btn btn-remove-item" style="width: auto; padding: 5px 10px; border-color: #ff5555; color: #ff5555;">X</button>
        </div>
        <div class="event-media-box camp-img-box" id="box_${id}" style="height: 150px; margin-bottom: 10px;">
            <svg viewBox="0 0 24 24" style="width: 30px; height: 30px; fill: currentColor; margin-bottom: 10px;"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 10h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"></path></svg>
            <span>Clique para anexar Imagem</span>
            <input type="file" id="file_${id}" accept="image/*" hidden>
            <input type="hidden" class="camp-val-base64" id="b64_${id}">
        </div>
        <textarea class="event-textarea camp-val-caption" placeholder="Legenda (opcional)" style="margin-bottom: 0; min-height: 60px;"></textarea>
    `;
    
    div.querySelector('.btn-remove-item').addEventListener('click', () => {
        handleRemoveFlowItem(div);
    });

    handleAppendFlowItem(div);

    const box = div.querySelector(`#box_${id}`);
    const file = div.querySelector(`#file_${id}`);
    const b64 = div.querySelector(`#b64_${id}`);

    box.addEventListener('click', () => file.click());
    file.addEventListener('change', (e) => {
        const f = e.target.files[0];
        if (!f) return;
        const reader = new FileReader();
        reader.onload = (event) => {
            b64.value = event.target.result;
            box.style.backgroundImage = `url(${event.target.result})`;
            box.style.backgroundSize = 'contain';
            box.style.backgroundPosition = 'center';
            box.style.backgroundRepeat = 'no-repeat';
            box.innerHTML = '';
            box.style.border = 'none';
            box.appendChild(file);
            box.appendChild(b64);
        };
        reader.readAsDataURL(f);
    });
});

btnSendCampaign?.addEventListener('click', () => {
    if (typeof handleSendCampaign === 'function') handleSendCampaign();
});

const btnSaveCampaign = document.getElementById('btn-save-campaign');
const savedCampaignsGrid = document.getElementById('saved-campaigns-grid');

async function renderSavedCampaignsList() {
    const campaigns = await getSavedCampaigns();
    if (!savedCampaignsGrid) return;
    
    savedCampaignsGrid.innerHTML = '';

    if (campaigns.length === 0) {
        savedCampaignsGrid.innerHTML = `
            <div class="card" style="border-style: dashed; border-color: var(--cp-border); align-items: center; justify-content: center; opacity: 0.5; grid-column: 1 / -1;">
                <div class="card-title" style="margin-bottom: 0;">Nenhuma campanha salva</div>
            </div>
        `;
        return;
    }

    campaigns.forEach(camp => {
        const div = document.createElement('div');
        div.className = 'card';
        div.style.flexShrink = '0';
        div.innerHTML = `
            <div class="card-title" style="color: var(--cp-neon);">${camp.name}</div>
            <div class="card-desc" style="margin-bottom: 15px;">
                Destinos: <strong>${camp.groups.length} grupos</strong><br>
                Itens no fluxo: <strong>${camp.payload.length}</strong><br>
                Salva em: ${camp.date}
            </div>
            <div style="display: flex; gap: 10px;">
                <button class="card-btn btn-load-camp" style="flex: 2;">ABRIR</button>
                <button class="card-btn btn-del-camp" style="flex: 1; border-color: #ff5555; color: #ff5555;">X</button>
            </div>
        `;

        div.querySelector('.btn-load-camp').addEventListener('click', () => loadCampaignIntoUI(camp));
        div.querySelector('.btn-del-camp').addEventListener('click', async () => {
            if (confirm('Deseja excluir esta campanha?')) {
                await deleteCampaignFromStorage(camp.id);
                renderSavedCampaignsList();
            }
        });

        savedCampaignsGrid.appendChild(div);
    });
}

function loadCampaignIntoUI(camp) {
    state.selectedGroupsForCampaign = [...camp.groups];
    
    document.querySelectorAll('#campaign-group-list .contact-item').forEach(item => {
        item.classList.toggle('selected', state.selectedGroupsForCampaign.includes(item.dataset.id));
    });

    campFlowContainer.innerHTML = '';
    camp.payload.forEach(item => {
        if (item.type === 'text') {
            btnAddCampText.click();
            const lastItem = campFlowContainer.lastElementChild;
            lastItem.querySelector('.camp-val-text').value = item.content;
            if (item.mentionAll) {
                const mentionCheckbox = lastItem.querySelector('.camp-mention-all');
                if (mentionCheckbox) mentionCheckbox.checked = true;
            }
        } else if (item.type === 'image' || item.type === 'video') {
            if (item.type === 'image') btnAddCampImage.click();
            else btnAddCampVideo.click();
            
            const lastItem = campFlowContainer.lastElementChild;
            const b64Input = lastItem.querySelector('.camp-val-base64');
            const captionInput = lastItem.querySelector('.camp-val-caption');
            
            b64Input.value = item.base64;
            captionInput.value = item.content;
            
            if (item.type === 'image') {
                const box = lastItem.querySelector('.camp-img-box');
                box.style.backgroundImage = `url(${item.base64})`;
                box.style.backgroundSize = 'contain';
                box.style.backgroundPosition = 'center';
                box.style.backgroundRepeat = 'no-repeat';
                box.style.border = 'none';
                box.querySelector('span').style.display = 'none';
                box.querySelector('svg').style.display = 'none';
            } else {
                const box = lastItem.querySelector('.camp-vid-box');
                box.style.background = 'rgba(255, 102, 0, 0.1)';
                box.style.borderColor = 'var(--cp-neon)';
                box.querySelector('svg').style.display = 'none';
                box.querySelector('span').innerHTML = '<strong style="color:var(--cp-neon); font-size:14px;">Vídeo Carregado com Sucesso</strong>';
            }
        } else if (item.type === 'poll') {
            btnAddCampPoll.click();
            const lastItem = campFlowContainer.lastElementChild;
            lastItem.querySelector('.camp-poll-name').value = item.name;
            const optsContainer = lastItem.querySelector('div[id^="opts_"]');
            optsContainer.innerHTML = '';
            item.options.forEach((opt, idx) => {
                const inp = document.createElement('input');
                inp.type = 'text';
                inp.className = 'contact-search-input camp-poll-opt';
                inp.placeholder = `Opção ${idx + 1}`;
                inp.style.marginBottom = '0';
                inp.value = opt;
                optsContainer.appendChild(inp);
            });
        }
        
        const currentItem = campFlowContainer.lastElementChild;
        if (currentItem && currentItem.previousElementSibling && currentItem.previousElementSibling.classList.contains('camp-flow-delay')) {
            if (item.delayBefore) {
                currentItem.previousElementSibling.querySelector('.camp-delay-input').value = item.delayBefore;
            }
        }
    });
    
    alert(`Campanha "${camp.name}" carregada com sucesso!`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

const btnAddCampVideo = document.getElementById('btn-add-camp-video');
const btnAddCampPoll = document.getElementById('btn-add-camp-poll');

btnAddCampVideo?.addEventListener('click', () => {
    const id = 'camp_vid_' + Date.now();
    const div = document.createElement('div');
    div.className = 'card camp-flow-item';
    div.dataset.type = 'video';
    div.style.padding = '15px';
    div.style.flexShrink = '0';
    div.innerHTML = `
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px; align-items: center;">
            <span style="color: var(--cp-neon); font-family: var(--font-cyber); font-size: 12px;">MÍDIA (VÍDEO)</span>
            <button class="card-btn btn-remove-item" style="width: auto; padding: 5px 10px; border-color: #ff5555; color: #ff5555;">X</button>
        </div>
        <div class="event-media-box camp-vid-box" id="box_${id}" style="height: 150px; margin-bottom: 10px;">
            <svg viewBox="0 0 24 24" style="width: 30px; height: 30px; fill: currentColor; margin-bottom: 10px;"><path d="M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z"></path></svg>
            <span>Clique para anexar Vídeo (MP4)</span>
            <input type="file" id="file_${id}" accept="video/mp4,video/x-m4v,video/*" hidden>
            <input type="hidden" class="camp-val-base64" id="b64_${id}">
        </div>
        <textarea class="event-textarea camp-val-caption" placeholder="Legenda (opcional)" style="margin-bottom: 0; min-height: 60px;"></textarea>
    `;
    
    div.querySelector('.btn-remove-item').addEventListener('click', () => {
        handleRemoveFlowItem(div);
    });

    handleAppendFlowItem(div);

    const box = div.querySelector(`#box_${id}`);
    const file = div.querySelector(`#file_${id}`);
    const b64 = div.querySelector(`#b64_${id}`);

    box.addEventListener('click', () => file.click());
    file.addEventListener('change', (e) => {
        const f = e.target.files[0];
        if (!f) return;
        const reader = new FileReader();
        reader.onload = (event) => {
            b64.value = event.target.result;
            box.style.background = 'rgba(255, 102, 0, 0.1)';
            box.style.borderColor = 'var(--cp-neon)';
            box.innerHTML = '<span style="color:var(--cp-neon); font-size:14px; font-weight:bold;">Vídeo Carregado com Sucesso</span>';
            box.appendChild(file);
            box.appendChild(b64);
        };
        reader.readAsDataURL(f);
    });
});

btnAddCampPoll?.addEventListener('click', () => {
    const id = 'camp_poll_' + Date.now();
    const div = document.createElement('div');
    div.className = 'card camp-flow-item';
    div.dataset.type = 'poll';
    div.style.padding = '15px';
    div.style.flexShrink = '0';
    div.innerHTML = `
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px; align-items: center;">
            <span style="color: var(--cp-neon); font-family: var(--font-cyber); font-size: 12px;">ENQUETE</span>
            <button class="card-btn btn-remove-item" style="width: auto; padding: 5px 10px; border-color: #ff5555; color: #ff5555;">X</button>
        </div>
        <input type="text" class="contact-search-input camp-poll-name" placeholder="Pergunta da enquete..." style="margin-bottom: 10px;">
        <div id="opts_${id}" style="display: flex; flex-direction: column; gap: 5px; margin-bottom: 10px;">
            <input type="text" class="contact-search-input camp-poll-opt" placeholder="Opção 1" style="margin-bottom: 0;">
            <input type="text" class="contact-search-input camp-poll-opt" placeholder="Opção 2" style="margin-bottom: 0;">
        </div>
        <button class="card-btn btn-add-opt" style="width: 100%; border-style: dashed; color: var(--cp-text-muted); border-color: var(--cp-border);">+ Adicionar Opção</button>
    `;

    div.querySelector('.btn-remove-item').addEventListener('click', () => {
        handleRemoveFlowItem(div);
    });

    div.querySelector('.btn-add-opt').addEventListener('click', () => {
        const optsContainer = div.querySelector(`#opts_${id}`);
        const count = optsContainer.children.length + 1;
        if (count > 12) return alert('Máximo de 12 opções permitido pelo WhatsApp.');
        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'contact-search-input camp-poll-opt';
        input.placeholder = `Opção ${count}`;
        input.style.marginBottom = '0';
        optsContainer.appendChild(input);
    });

    handleAppendFlowItem(div);
});

btnSaveCampaign?.addEventListener('click', async () => {
    const items = campFlowContainer.querySelectorAll('.camp-flow-item');
    if (items.length === 0) return alert("Adicione itens ao fluxo antes de salvar.");
    
    const campaigns = await getSavedCampaigns();
    if (campaigns.length >= 10) {
        alert("Limite máximo de 10 campanhas atingido. Exclua uma campanha salva para adicionar outra.");
        return;
    }
    
    const name = prompt("Digite um nome para identificar esta campanha:");
    if (!name) return;

    const payload = [];
    items.forEach(item => {
        let delayBefore = 10;
        if (item.previousElementSibling && item.previousElementSibling.classList.contains('camp-flow-delay')) {
            delayBefore = parseInt(item.previousElementSibling.querySelector('.camp-delay-input').value) || 10;
        }

        const type = item.dataset.type;
        if (type === 'text') {
            payload.push({ type: 'text', content: item.querySelector('.camp-val-text').value, mentionAll: item.querySelector('.camp-mention-all')?.checked || false, delayBefore: delayBefore });
        } else if (type === 'image' || type === 'video') {
            payload.push({ type: type, content: item.querySelector('.camp-val-caption').value, base64: item.querySelector('.camp-val-base64').value, delayBefore: delayBefore });
        } else if (type === 'poll') {
            const name = item.querySelector('.camp-poll-name').value;
            const options = Array.from(item.querySelectorAll('.camp-poll-opt')).map(inp => inp.value).filter(v => v.trim() !== '');
            payload.push({ type: 'poll', name: name, options: options, delayBefore: delayBefore });
        }
    });

    const savedSuccessfully = await saveCampaignToStorage(name, state.selectedGroupsForCampaign, payload);
    
    if (savedSuccessfully) {
        renderSavedCampaignsList();
        alert("Campanha salva na biblioteca!");
    }
});


// Inicializa a lista ao abrir a aba
navCampaigns?.addEventListener('click', () => {
    renderSavedCampaignsList();
});

// --- EVENTOS: GRUPOS PERMITIDOS DO CHATBOT ---
const btnBotGroups = document.getElementById('btn-bot-groups');
const flowOverlayBotGroups = document.getElementById('flow-overlay-bot-groups');
const closeFlowBotGroups = document.getElementById('close-flow-bot-groups');
const groupSearchBot = document.getElementById('group-search-bot');

btnBotGroups?.addEventListener('click', async () => {
    flowOverlayBotGroups.classList.add('active');
    
    const container = document.getElementById('group-list-bot-container');
    container.innerHTML = '<div style="text-align:center; padding:20px; color:var(--cp-neon);">Carregando grupos...</div>';

    // Reaproveita a função da engine para pegar a lista
    const groupsJson = await runInWa(async () => {
        if (!window.FMARK || !window.FMARK.infoAllGroupList) return "[]";
        return await window.FMARK.infoAllGroupList();
    });

    const groups = JSON.parse(groupsJson || "[]");
    container.innerHTML = '';

    if (groups.error || groups.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">Nenhum grupo encontrado.</div>';
        return;
    }

    groups.forEach(group => {
        const item = document.createElement('div');
        item.className = 'contact-item';
        
        // PROTEÇÃO: Garante que a ID sempre será um texto limpo
        const safeId = typeof group.id === 'object' ? group.id._serialized : group.id;
        item.dataset.id = safeId;

        // Se já estiver na lista de permitidos do state, marca como selecionado
        if (state.botAllowedGroups.includes(String(safeId))) {
            item.classList.add('selected');
        }

        const initial = group.subject ? group.subject.charAt(0).toUpperCase() : 'G';
        const adminBadge = group.isAdmin 
            ? '<span style="color:#00ff00; font-size:10px; border:1px solid rgba(0,255,0,0.3); background:rgba(0,255,0,0.1); padding:2px 4px; border-radius:4px; margin-left:8px;">ADMIN</span>' 
            : '';

        item.innerHTML = `
            <div class="contact-avatar">${initial}</div>
            <div class="contact-info" style="flex: 1; min-width: 0;">
                <span class="contact-name" style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${group.subject || 'Grupo sem nome'}</span>
                    ${adminBadge}
                </span>
                <span class="contact-number">${group.participantsCount} participantes</span>
            </div>
        `;

        item.addEventListener('click', () => {
            item.classList.toggle('selected');
        });

        container.appendChild(item);
    });
});

closeFlowBotGroups?.addEventListener('click', () => {
    flowOverlayBotGroups.classList.remove('active');
    if (groupSearchBot) groupSearchBot.value = '';
});

groupSearchBot?.addEventListener('input', (e) => {
    const term = e.target.value.toLowerCase();
    document.querySelectorAll('#group-list-bot-container .contact-item').forEach(item => {
        const name = item.querySelector('.contact-name').innerText.toLowerCase();
        item.style.display = name.includes(term) ? 'flex' : 'none';
    });
});

document.getElementById('btn-save-bot-groups')?.addEventListener('click', async () => {
    const selectedNodes = document.querySelectorAll('#group-list-bot-container .contact-item.selected');
    const selectedIds = Array.from(selectedNodes).map(node => node.dataset.id);
    
    // Atualiza o estado
    state.botAllowedGroups = selectedIds;
    
    // Sincroniza com o WhatsApp injetando a nova lista
    await syncBotEvents();
    
    if (selectedIds.length > 0) {
        alert(`Filtro Salvo!\nO Chatbot agora atua SOMENTE em ${selectedIds.length} grupo(s).`);
    } else {
        alert(`Filtro Limpo!\nO Chatbot agora atua em TODOS os grupos novamente.`);
    }
    
    flowOverlayBotGroups.classList.remove('active');
});
// -------------------------------------------------------------

const btnSaveEventAntispam = document.getElementById('btn-save-event-antispam');

if (btnSaveEventAntispam) {
    btnSaveEventAntispam.addEventListener('click', async () => {
        const blockLinks = document.getElementById('check-block-links').checked;
        const blockGifs = document.getElementById('check-block-gifs').checked;
        const banUser = document.getElementById('check-antispam-ban').checked;

        if (!blockLinks && !blockGifs) {
            alert('Selecione pelo menos uma opção para bloquear (Links ou GIFs).');
            return;
        }

        const eventId = editingBotEventId || ('evt_' + new Date().getTime());
        const eventData = {
            id: eventId,
            eventType: 'antispam',
            blockLinks: blockLinks,
            blockGifs: blockGifs,
            banUser: banUser
        };

        if (editingBotEventId) {
            await window.removeBotEvent(editingBotEventId);
            const oldCard = document.getElementById(editingBotEventId);
            if (oldCard) oldCard.remove();
            editingBotEventId = null;
        }

        if (typeof window.addBotEvent === 'function') {
            await window.addBotEvent(eventData);
        }

        const emptyState = eventsGrid.querySelector('.card[style*="dashed"]');
        if (emptyState) emptyState.remove();

        const newCard = document.createElement('div');
        newCard.className = 'card';
        newCard.id = eventId;
        
        let tagsHTML = '<span style="color:#ffcc00; font-size:10px; border:1px solid rgba(255,204,0,0.3); background:rgba(255,204,0,0.1); padding:2px 4px; border-radius:4px; margin-right:5px;">EXCLUI MSG</span>';
        if (banUser) tagsHTML += '<span style="color:#ff5555; font-size:10px; border:1px solid rgba(255,85,85,0.3); background:rgba(255,85,85,0.1); padding:2px 4px; border-radius:4px;">BAN</span>';

        let desc = [];
        if (blockLinks) desc.push('Links');
        if (blockGifs) desc.push('GIFs');

        newCard.innerHTML = `
            <div class="event-badge" style="background: rgba(255, 170, 0, 0.1); border: 1px solid rgba(255, 170, 0, 0.5); color: #ffaa00; box-shadow: 0 0 5px rgba(255, 170, 0, 0.2);">ANTI-SPAM</div>
            <div class="card-icon" style="margin-bottom: 15px;">
                <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11H7v-2h10v2z"></path></svg>
            </div>
            <div class="card-title" style="font-size: 16px;">Bloqueio Automático</div>
            <div class="card-desc" style="margin-bottom: 15px; flex-grow: 0;">
                <div style="margin-bottom: 5px;">${tagsHTML}</div>
                Bloqueando: <strong style="color: var(--cp-text-main);">${desc.join(' e ')}</strong>
            </div>
            <div style="display: flex; gap: 10px; margin-top: auto;">
                <button class="card-btn btn-edit-event" style="border-color: #ffcc00; color: #ffcc00; flex: 1;">Editar</button>
                <button class="card-btn btn-delete-event" style="border-color: #ff5555; color: #ff5555; flex: 1;">Excluir</button>
            </div>
        `;

        newCard.querySelector('.btn-edit-event').addEventListener('click', () => {
            editingBotEventId = eventData.id;
            document.getElementById('modal-create-event').classList.add('active');
            document.querySelector('[data-target="tab-antispam"]').click();
            
            document.getElementById('check-block-links').checked = eventData.blockLinks;
            document.getElementById('check-block-gifs').checked = eventData.blockGifs;
            document.getElementById('check-antispam-ban').checked = eventData.banUser;
        });

        newCard.querySelector('.btn-delete-event').addEventListener('click', async () => {
            if (typeof window.removeBotEvent === 'function') await window.removeBotEvent(eventId);
            newCard.remove();
            if (eventsGrid.children.length === 0) {
                eventsGrid.innerHTML = '<div class="card" style="border-style: dashed; border-color: var(--cp-border); align-items: center; justify-content: center; opacity: 0.5;"><div class="card-title" style="margin-bottom: 0;">Nenhum evento criado</div></div>';
            }
        });

        eventsGrid.appendChild(newCard);
        document.getElementById('modal-create-event').classList.remove('active');

        document.getElementById('check-block-links').checked = false;
        document.getElementById('check-block-gifs').checked = false;
        document.getElementById('check-antispam-ban').checked = false;
    });
}

// --- CARREGAR EVENTOS SALVOS AO INICIAR ---
setTimeout(async () => {
    if (typeof loadBotEvents !== 'function') return;
    
    const savedEvents = await loadBotEvents();
    const grid = document.getElementById('events-grid');
    
    if (savedEvents.length > 0 && grid) {
        grid.innerHTML = ''; // Limpa o card vazio
        
        savedEvents.forEach(eventData => {
            const newCard = document.createElement('div');
            newCard.className = 'card';
            newCard.id = eventData.id;
            
            // Renderiza o visual correspondente ao tipo de evento
            if (eventData.eventType === 'joined' || eventData.eventType === 'left') {
                const isJoin = eventData.eventType === 'joined';
                newCard.innerHTML = `
                    <div class="event-badge ${isJoin ? 'badge-joined' : 'badge-left'}">${isJoin ? 'ENTROU NO GRUPO' : 'SAIU DO GRUPO'}</div>
                    <div class="card-icon" style="margin-bottom: 15px;">
                        <svg viewBox="0 0 24 24"><path d="${isJoin ? 'M15 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm-9-2V7H4v3H1v2h3v3h2v-3h3v-2H6zm9 4c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z' : 'M10.09 15.59L11.5 17l5-5-5-5-1.41 1.41L12.67 11H3v2h9.67l-2.58 2.59zM19 3H5c-1.11 0-2 .9-2 2v4h2V5h14v14H5v-4H3v4c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2z'}"></path></svg>
                    </div>
                    <div class="card-title" style="font-size: 16px;">${isJoin ? 'Mensagem de Boas-Vindas' : 'Mensagem de Despedida'}</div>
                    <div class="card-desc" style="margin-bottom: 15px; flex-grow: 0;">
                        Tipo: <strong style="color: var(--cp-text-main);">${eventData.isText ? 'Texto' : 'Mídia'}</strong><br>
                        Destino: <strong style="color: var(--cp-text-main);">${eventData.isPrivate ? 'Privado' : 'No Grupo'}</strong>
                    </div>
                    <div style="display: flex; gap: 10px; margin-top: auto;">
                        <button class="card-btn btn-delete-event" style="border-color: #ff5555; color: #ff5555; width: 100%;">Excluir</button>
                    </div>
                `;
            } else if (eventData.eventType === 'response') {
                let tagsHTML = '';
                if (eventData.deleteMsg) tagsHTML += '<span style="color:#ffcc00; font-size:10px; border:1px solid rgba(255,204,0,0.3); background:rgba(255,204,0,0.1); padding:2px 4px; border-radius:4px; margin-right:5px;">EXCLUI MSG</span>';
                if (eventData.removeUser) tagsHTML += '<span style="color:#ff5555; font-size:10px; border:1px solid rgba(255,85,85,0.3); background:rgba(255,85,85,0.1); padding:2px 4px; border-radius:4px;">BAN</span>';
                
                newCard.innerHTML = `
                    <div class="event-badge badge-response">RESPOSTA / MODERAÇÃO</div>
                    <div class="card-icon" style="margin-bottom: 15px;">
                        <svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"></path></svg>
                    </div>
                    <div class="card-title" style="font-size: 16px;">Gatilho: "${eventData.keyword}"</div>
                    <div class="card-desc" style="margin-bottom: 15px; flex-grow: 0;">
                        <div style="margin-bottom: 5px;">${tagsHTML}</div>
                        Ação: <strong style="color: var(--cp-text-main);">${eventData.content || eventData.mediaBase64 ? 'Responde' : 'Apenas Modera'}</strong>
                    </div>
                    <div style="display: flex; gap: 10px; margin-top: auto;">
                        <button class="card-btn btn-delete-event" style="border-color: #ff5555; color: #ff5555; width: 100%;">Excluir</button>
                    </div>
                `;
            } else if (eventData.eventType === 'antispam') {
                let tagsHTML = '<span style="color:#ffcc00; font-size:10px; border:1px solid rgba(255,204,0,0.3); background:rgba(255,204,0,0.1); padding:2px 4px; border-radius:4px; margin-right:5px;">EXCLUI MSG</span>';
                if (eventData.banUser) tagsHTML += '<span style="color:#ff5555; font-size:10px; border:1px solid rgba(255,85,85,0.3); background:rgba(255,85,85,0.1); padding:2px 4px; border-radius:4px;">BAN</span>';
                
                let desc = [];
                if (eventData.blockLinks) desc.push('Links');
                if (eventData.blockGifs) desc.push('GIFs');

                newCard.innerHTML = `
                    <div class="event-badge" style="background: rgba(255, 170, 0, 0.1); border: 1px solid rgba(255, 170, 0, 0.5); color: #ffaa00; box-shadow: 0 0 5px rgba(255, 170, 0, 0.2);">ANTI-SPAM</div>
                    <div class="card-icon" style="margin-bottom: 15px;">
                        <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11H7v-2h10v2z"></path></svg>
                    </div>
                    <div class="card-title" style="font-size: 16px;">Bloqueio Automático</div>
                    <div class="card-desc" style="margin-bottom: 15px; flex-grow: 0;">
                        <div style="margin-bottom: 5px;">${tagsHTML}</div>
                        Bloqueando: <strong style="color: var(--cp-text-main);">${desc.join(' e ')}</strong>
                    </div>
                    <div style="display: flex; gap: 10px; margin-top: auto;">
                        <button class="card-btn btn-delete-event" style="border-color: #ff5555; color: #ff5555; width: 100%;">Excluir</button>
                    </div>
                `;
            }

            // Mantém apenas a função de excluir para evitar erros na edição de eventos recuperados da memória
            newCard.querySelector('.btn-delete-event').addEventListener('click', async () => {
                if (typeof window.removeBotEvent === 'function') await window.removeBotEvent(eventData.id);
                newCard.remove();
                if (grid.children.length === 0) {
                    grid.innerHTML = '<div class="card" style="border-style: dashed; border-color: var(--cp-border); align-items: center; justify-content: center; opacity: 0.5;"><div class="card-title" style="margin-bottom: 0;">Nenhum evento criado</div></div>';
                }
            });

            grid.appendChild(newCard);
        });
    }
    
    // Força a reinjeção da lista no background do WhatsApp
    if (typeof syncBotEvents === 'function') await syncBotEvents();
}, 600);

// --- AGENDAR DISPARO ---
const btnScheduleCampaign = document.getElementById('btn-schedule-campaign');
const scheduleModal = document.getElementById('schedule-modal');
const closeScheduleModal = document.getElementById('close-schedule-modal');
const calDaysGrid = document.getElementById('cal-days-grid');
const calMonthLabel = document.getElementById('cal-month-label');
const calPrevMonth = document.getElementById('cal-prev-month');
const calNextMonth = document.getElementById('cal-next-month');
const scheduleTimeInput = document.getElementById('schedule-time-input');
const scheduleSummary = document.getElementById('schedule-summary');
const scheduleSummaryDate = document.getElementById('schedule-summary-date');
const scheduleSummaryTime = document.getElementById('schedule-summary-time');
const btnConfirmSchedule = document.getElementById('btn-confirm-schedule');

let calendarCurrentMonth = new Date().getMonth();
let calendarCurrentYear = new Date().getFullYear();
let selectedScheduleDate = null;

const monthNames = [
    'Janeiro', 'Fevereiro', 'Marco', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
];

function renderCalendar() {
    if (!calDaysGrid || !calMonthLabel) return;

    calMonthLabel.textContent = `${monthNames[calendarCurrentMonth]} ${calendarCurrentYear}`;

    const firstDay = new Date(calendarCurrentYear, calendarCurrentMonth, 1).getDay();
    const daysInMonth = new Date(calendarCurrentYear, calendarCurrentMonth + 1, 0).getDate();
    const today = new Date();

    calDaysGrid.innerHTML = '';

    for (let i = 0; i < firstDay; i++) {
        const empty = document.createElement('div');
        empty.className = 'calendar-day empty';
        calDaysGrid.appendChild(empty);
    }

    for (let day = 1; day <= daysInMonth; day++) {
        const dayEl = document.createElement('div');
        dayEl.className = 'calendar-day';
        dayEl.textContent = day;

        const dateObj = new Date(calendarCurrentYear, calendarCurrentMonth, day);

        if (dateObj.toDateString() === today.toDateString()) {
            dayEl.classList.add('today');
        }

        if (dateObj < new Date(today.getFullYear(), today.getMonth(), today.getDate())) {
            dayEl.classList.add('disabled');
        }

        if (selectedScheduleDate &&
            selectedScheduleDate.getFullYear() === calendarCurrentYear &&
            selectedScheduleDate.getMonth() === calendarCurrentMonth &&
            selectedScheduleDate.getDate() === day) {
            dayEl.classList.add('selected');
        }

        dayEl.addEventListener('click', () => {
            if (dayEl.classList.contains('disabled') || dayEl.classList.contains('empty')) return;

            calDaysGrid.querySelectorAll('.calendar-day').forEach(d => d.classList.remove('selected'));
            dayEl.classList.add('selected');

            selectedScheduleDate = new Date(calendarCurrentYear, calendarCurrentMonth, day);
            updateScheduleSummary();
        });

        calDaysGrid.appendChild(dayEl);
    }
}

function updateScheduleSummary() {
    if (!selectedScheduleDate || !scheduleTimeInput.value) {
        scheduleSummary.classList.remove('active');
        btnConfirmSchedule.disabled = true;
        return;
    }

    const dateStr = selectedScheduleDate.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
    const timeStr = scheduleTimeInput.value;

    scheduleSummaryDate.textContent = dateStr;
    scheduleSummaryTime.textContent = timeStr;
    scheduleSummary.classList.add('active');
    btnConfirmSchedule.disabled = false;
}

btnScheduleCampaign?.addEventListener('click', () => {
    if (state.selectedGroupsForCampaign.length === 0) {
        alert("Selecione pelo menos um grupo de destino antes de agendar!");
        return;
    }

    const flowContainer = document.getElementById('campaign-flow-container');
    const items = flowContainer.querySelectorAll('.camp-flow-item');
    if (items.length === 0) {
        alert("Adicione pelo menos um texto ou imagem ao fluxo antes de agendar!");
        return;
    }

    calendarCurrentMonth = new Date().getMonth();
    calendarCurrentYear = new Date().getFullYear();
    selectedScheduleDate = null;
    scheduleTimeInput.value = '';
    scheduleSummary.classList.remove('active');
    btnConfirmSchedule.disabled = true;

    renderCalendar();
    scheduleModal.classList.add('active');
});

closeScheduleModal?.addEventListener('click', () => {
    scheduleModal.classList.remove('active');
});

calPrevMonth?.addEventListener('click', () => {
    calendarCurrentMonth--;
    if (calendarCurrentMonth < 0) {
        calendarCurrentMonth = 11;
        calendarCurrentYear--;
    }
    renderCalendar();
});

calNextMonth?.addEventListener('click', () => {
    calendarCurrentMonth++;
    if (calendarCurrentMonth > 11) {
        calendarCurrentMonth = 0;
        calendarCurrentYear++;
    }
    renderCalendar();
});

scheduleTimeInput?.addEventListener('input', updateScheduleSummary);
scheduleTimeInput?.addEventListener('change', updateScheduleSummary);

btnConfirmSchedule?.addEventListener('click', async () => {
    if (!selectedScheduleDate || !scheduleTimeInput.value) return;

    const flowContainer = document.getElementById('campaign-flow-container');
    const items = flowContainer.querySelectorAll('.camp-flow-item');

    const payload = [];
    let hasError = false;

    items.forEach(item => {
        const type = item.dataset.type;
        if (type === 'text') {
            const text = item.querySelector('.camp-val-text').value.trim();
            if (!text) hasError = true;
            const mentionAll = item.querySelector('.camp-mention-all')?.checked || false;
            payload.push({ type: 'text', content: text, mentionAll: mentionAll });
        } else if (type === 'image' || type === 'video') {
            const b64 = item.querySelector('.camp-val-base64').value;
            const caption = item.querySelector('.camp-val-caption').value.trim();
            if (!b64) hasError = true;
            payload.push({ type: type, content: caption, base64: b64 });
        } else if (type === 'poll') {
            const pollName = item.querySelector('.camp-poll-name').value.trim();
            const optionsArr = Array.from(item.querySelectorAll('.camp-poll-opt')).map(inp => inp.value.trim()).filter(v => v !== '');
            if (!pollName || optionsArr.length < 2) hasError = true;
            payload.push({ type: 'poll', name: pollName, options: optionsArr });
        }
    });

    if (hasError) {
        alert("Preencha todos os campos corretamente. Enquetes exigem no minimo 2 opcoes e midias precisam ser carregadas.");
        return;
    }

    const timeParts = scheduleTimeInput.value.split(':');
    const scheduledTimestamp = new Date(
        selectedScheduleDate.getFullYear(),
        selectedScheduleDate.getMonth(),
        selectedScheduleDate.getDate(),
        parseInt(timeParts[0]),
        parseInt(timeParts[1]),
        0
    ).getTime();

    if (scheduledTimestamp <= Date.now()) {
        alert("O horario selecionado ja passou. Escolha um horario futuro.");
        return;
    }

    btnConfirmSchedule.innerText = 'AGENDANDO...';
    btnConfirmSchedule.disabled = true;

    const delayMinInput = document.getElementById('camp-delay-min');
    const delayMaxInput = document.getElementById('camp-delay-max');
    const delayMin = parseInt(delayMinInput?.value) || 10;
    const delayMax = parseInt(delayMaxInput?.value) || 30;

    const scheduledData = {
        id: 'sched_' + Date.now(),
        scheduledDate: selectedScheduleDate.toISOString().split('T')[0],
        scheduledTime: scheduleTimeInput.value,
        scheduledTimestamp: scheduledTimestamp,
        groups: [...state.selectedGroupsForCampaign],
        payload: payload,
        delayMin: delayMin,
        delayMax: delayMax,
        fired: false,
        createdAt: new Date().toLocaleString('pt-BR')
    };

    const success = await saveScheduledCampaign(scheduledData);

    if (success) {
        scheduleModal.classList.remove('active');
        alert(`Campanha agendada com sucesso!\nData: ${scheduledData.scheduledDate.split('-').reverse().join('/')}\nHorario: ${scheduledData.scheduledTime}\n\nMantenha a extensao aberta no horario do disparo.`);
        renderScheduledList();
        startScheduleChecker();
    } else {
        alert("Erro ao agendar campanha. Tente novamente.");
    }

    btnConfirmSchedule.innerText = 'CONFIRMAR AGENDAMENTO';
    btnConfirmSchedule.disabled = false;
});

async function renderScheduledList() {
    const scheduled = await getScheduledCampaigns();
    const listContainer = document.getElementById('scheduled-campaigns-list');
    const section = document.getElementById('scheduled-campaigns-section');

    if (!listContainer || !section) return;

    const pending = scheduled.filter(s => !s.fired);

    if (pending.length === 0) {
        section.style.display = 'none';
        return;
    }

    section.style.display = 'block';
    listContainer.innerHTML = '';

    pending.sort((a, b) => a.scheduledTimestamp - b.scheduledTimestamp).forEach(item => {
        const dateFormatted = item.scheduledDate.split('-').reverse().join('/');
        const div = document.createElement('div');
        div.className = 'scheduled-list-item';
        div.innerHTML = `
            <div class="scheduled-list-info">
                <span class="scheduled-list-date">${dateFormatted} as ${item.scheduledTime}</span>
                <span class="scheduled-list-groups">${item.groups.length} grupo(s) | ${item.payload.length} item(ns) no fluxo</span>
            </div>
            <button class="scheduled-list-cancel" data-id="${item.id}">CANCELAR</button>
        `;

        div.querySelector('.scheduled-list-cancel').addEventListener('click', async (e) => {
            const id = e.target.dataset.id;
            if (confirm('Deseja cancelar este agendamento?')) {
                await deleteScheduledCampaign(id);
                renderScheduledList();
            }
        });

        listContainer.appendChild(div);
    });
}

navCampaigns?.addEventListener('click', () => {
    renderScheduledList();
    startScheduleChecker();
});

navGroups?.addEventListener('click', () => { if (scheduleCheckInterval) { clearInterval(scheduleCheckInterval); scheduleCheckInterval = null; } });
navChatbot?.addEventListener('click', () => { if (scheduleCheckInterval) { clearInterval(scheduleCheckInterval); scheduleCheckInterval = null; } });
navMonitoring?.addEventListener('click', () => { if (scheduleCheckInterval) { clearInterval(scheduleCheckInterval); scheduleCheckInterval = null; } });

setTimeout(() => {
    renderScheduledList();
    startScheduleChecker();
    renderAutoCampaignStatus();
    startAutoChecker();
}, 800);

// --- DISPARO AUTOMATICO ---
const btnAutoCampaign = document.getElementById('btn-auto-campaign');
const autoModal = document.getElementById('auto-modal');
const closeAutoModal = document.getElementById('close-auto-modal');
const autoTimeInput = document.getElementById('auto-time-input');
const autoSummary = document.getElementById('auto-summary');
const autoSummaryTime = document.getElementById('auto-summary-time');
const btnConfirmAuto = document.getElementById('btn-confirm-auto');

autoTimeInput?.addEventListener('input', () => {
    if (autoTimeInput.value) {
        autoSummaryTime.textContent = autoTimeInput.value;
        autoSummary.classList.add('active');
        btnConfirmAuto.disabled = false;
    } else {
        autoSummary.classList.remove('active');
        btnConfirmAuto.disabled = true;
    }
});

autoTimeInput?.addEventListener('change', () => {
    if (autoTimeInput.value) {
        autoSummaryTime.textContent = autoTimeInput.value;
        autoSummary.classList.add('active');
        btnConfirmAuto.disabled = false;
    } else {
        autoSummary.classList.remove('active');
        btnConfirmAuto.disabled = true;
    }
});

btnAutoCampaign?.addEventListener('click', async () => {
    const autoData = await getAutoCampaign();
    if (autoData && autoData.active) {
        if (confirm('Ja existe um disparo automatico ativo as ' + autoData.time + '. Deseja substituir?')) {
            await deleteAutoCampaign();
            renderAutoCampaignStatus();
        } else {
            return;
        }
    }

    if (state.selectedGroupsForCampaign.length === 0) {
        alert("Selecione pelo menos um grupo de destino antes de configurar o disparo automatico!");
        return;
    }

    const flowContainer = document.getElementById('campaign-flow-container');
    const items = flowContainer.querySelectorAll('.camp-flow-item');
    if (items.length === 0) {
        alert("Adicione pelo menos um item ao fluxo antes de configurar o disparo automatico!");
        return;
    }

    autoTimeInput.value = '';
    autoSummary.classList.remove('active');
    btnConfirmAuto.disabled = true;
    autoModal.classList.add('active');
});

closeAutoModal?.addEventListener('click', () => {
    autoModal.classList.remove('active');
});

btnConfirmAuto?.addEventListener('click', async () => {
    if (!autoTimeInput.value) return;

    const flowContainer = document.getElementById('campaign-flow-container');
    const items = flowContainer.querySelectorAll('.camp-flow-item');

    const payload = [];
    let hasError = false;

    items.forEach(item => {
        const type = item.dataset.type;
        if (type === 'text') {
            const text = item.querySelector('.camp-val-text').value.trim();
            if (!text) hasError = true;
            const mentionAll = item.querySelector('.camp-mention-all')?.checked || false;
            payload.push({ type: 'text', content: text, mentionAll: mentionAll });
        } else if (type === 'image' || type === 'video') {
            const b64 = item.querySelector('.camp-val-base64').value;
            const caption = item.querySelector('.camp-val-caption').value.trim();
            if (!b64) hasError = true;
            payload.push({ type: type, content: caption, base64: b64 });
        } else if (type === 'poll') {
            const pollName = item.querySelector('.camp-poll-name').value.trim();
            const optionsArr = Array.from(item.querySelectorAll('.camp-poll-opt')).map(inp => inp.value.trim()).filter(v => v !== '');
            if (!pollName || optionsArr.length < 2) hasError = true;
            payload.push({ type: 'poll', name: pollName, options: optionsArr });
        }
    });

    if (hasError) {
        alert("Preencha todos os campos corretamente antes de ativar o disparo automatico.");
        return;
    }

    btnConfirmAuto.innerText = 'ATIVANDO...';
    btnConfirmAuto.disabled = true;

    const autoData = {
        active: true,
        time: autoTimeInput.value,
        groups: [...state.selectedGroupsForCampaign],
        payload: payload,
        createdAt: new Date().toLocaleString('pt-BR'),
        lastFired: null,
        lastFiredDate: null
    };

    const success = await saveAutoCampaign(autoData);

    if (success) {
        autoModal.classList.remove('active');
        alert(`Disparo automatico ativado!\nHorario diario: ${autoData.time}\n\nTodos os dias nesse horario a campanha sera enviada. Mantenha a extensao aberta.`);
        renderAutoCampaignStatus();
        startAutoChecker();
    } else {
        alert("Erro ao ativar disparo automatico. Tente novamente.");
    }

    btnConfirmAuto.innerText = 'ATIVAR DISPARO AUTOMATICO';
    btnConfirmAuto.disabled = false;
});

async function renderAutoCampaignStatus() {
    const autoData = await getAutoCampaign();
    const section = document.getElementById('auto-campaign-section');
    const info = document.getElementById('auto-campaign-info');

    if (!section || !info) return;

    if (!autoData || !autoData.active) {
        section.style.display = 'none';
        return;
    }

    section.style.display = 'block';

    info.innerHTML = `
        <div class="scheduled-list-item">
            <div class="scheduled-list-info">
                <span class="scheduled-list-date" style="color: #00ff00;">Diariamente as ${autoData.time}</span>
                <span class="scheduled-list-groups">${autoData.groups.length} grupo(s) | ${autoData.payload.length} item(ns) no fluxo</span>
                ${autoData.lastFired ? '<span class="scheduled-list-groups" style="margin-top: 2px;">Ultimo envio: ' + autoData.lastFired + '</span>' : ''}
            </div>
            <button class="scheduled-list-cancel" id="btn-cancel-auto" style="border-color: rgba(255,85,85,0.5); color: #ff5555;">DESATIVAR</button>
        </div>
    `;

    document.getElementById('btn-cancel-auto')?.addEventListener('click', async () => {
        if (confirm('Deseja desativar o disparo automatico?')) {
            await deleteAutoCampaign();
            renderAutoCampaignStatus();
        }
    });
}

navCampaigns?.addEventListener('click', () => {
    renderAutoCampaignStatus();
    startAutoChecker();
});

navGroups?.addEventListener('click', () => { if (autoCheckInterval) { clearInterval(autoCheckInterval); autoCheckInterval = null; } });
navChatbot?.addEventListener('click', () => { if (autoCheckInterval) { clearInterval(autoCheckInterval); autoCheckInterval = null; } });
navMonitoring?.addEventListener('click', () => { if (autoCheckInterval) { clearInterval(autoCheckInterval); autoCheckInterval = null; } });