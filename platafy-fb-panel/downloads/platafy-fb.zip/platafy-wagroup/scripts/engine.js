 const state = {
    waTabId: null,
    selectedContacts: [],
    selectedGroupsForCampaign: [],
    groupImageBase64: null,
    selectedGroupToAdd: null,
    selectedContactsToAdd: [],
    importedContactsToAdd: [],
    selectedGroupToRemove: null,
    selectedMembersToRemove: [],
    selectedGroupToPromote: null,
    selectedMembersToPromote: [],
    selectedGroupToDemote: null,
    selectedMembersToDemote: [],
    selectedGroupsToLeave: [],
    selectedGroupToEditName: null,
    selectedGroupToEditImage: null,
    newGroupImageBase64: null,
    selectedGroupToExtract: null,
    selectedGroupToEditDesc: null,
    selectedGroupTransferSource: null,
    selectedGroupTransferTarget: null,
    selectedGroupToConfig: null,
    botAllowedGroups: []
};

async function getWaTab() {
    const tabs = await chrome.tabs.query({ url: "*://web.whatsapp.com/*" });
    return tabs[0] || null;
}

async function runInWa(func, args = []) {
    if (!state.waTabId) {
        const tab = await getWaTab();
        if (tab) state.waTabId = tab.id;
        else return null;
    }

    async function ensureFmark(tabId) {
        try {
            const check = await chrome.scripting.executeScript({
                target: { tabId: tabId },
                world: "MAIN",
                func: () => typeof window.FMARK !== 'undefined' && typeof window.Store !== 'undefined'
            });
            if (!check[0]?.result) {
                await chrome.scripting.executeScript({
                    target: { tabId: tabId },
                    world: "MAIN",
                    files: ["fmark.js"]
                });
                await new Promise(r => setTimeout(r, 2000));
            }
            return true;
        } catch (e) {
            return false;
        }
    }

    try {
        await ensureFmark(state.waTabId);
        const result = await chrome.scripting.executeScript({
            target: { tabId: state.waTabId },
            world: "MAIN",
            func: func,
            args: args
        });
        return result[0]?.result;
    } catch (e) {
        state.waTabId = null;

        const tab = await getWaTab();
        if (tab) {
            state.waTabId = tab.id;
            try {
                await ensureFmark(state.waTabId);
                const retryResult = await chrome.scripting.executeScript({
                    target: { tabId: state.waTabId },
                    world: "MAIN",
                    func: func,
                    args: args
                });
                return retryResult[0]?.result;
            } catch (err) {
                return null;
            }
        }
        return null;
    }
}

async function loadContacts() {
    const btn = document.getElementById('btn-next-node');
    const originalText = btn.innerText;
    btn.innerText = 'Carregando...';

    const contacts = await runInWa(() => {
        let models = [];
        
        if (window.Store && window.Store.Contact && window.Store.Contact.getModelsArray) {
            models = window.Store.Contact.getModelsArray();
        } else if (window.FMARK && typeof window.FMARK.getAllContacts === 'function') {
            models = window.FMARK.getAllContacts();
        }

        const contactList = [];

        models.forEach(contact => {
            try {
                if (contact.isGroup || contact.isBroadcast || (contact.id && contact.id.server !== 'c.us')) return;

                const numero = contact.id?.user || contact.userid;
                const nome = contact.name || contact.pushname || contact.formattedName || "Desconhecido";

                if (numero) {
                    const cleanNumber = String(numero).replace(/\D/g, "");
                    if (cleanNumber.length >= 8 && cleanNumber.length <= 15) {
                        contactList.push({
                            id: contact.id?._serialized || `${cleanNumber}@c.us`,
                            name: nome,
                            number: cleanNumber
                        });
                    }
                }
            } catch (err) {}
        });
        
        return contactList.sort((a, b) => a.name.localeCompare(b.name));
    });
    
    const container = document.getElementById('contact-list-container');
    if (!contacts || !container) {
        btn.innerText = 'Sincronizando...';
        alert('O WhatsApp ainda está montando os dados no navegador.\nPor favor, aguarde alguns segundos, clique em qualquer chat no WhatsApp e tente novamente.');
        return;
    }
    
    container.innerHTML = '';
    state.selectedContacts = [];
    
    contacts.forEach(contact => {
        const item = document.createElement('div');
        item.className = 'contact-item';
        item.dataset.id = contact.id;
        
        const initial = contact.name.charAt(0).toUpperCase();
        
        item.innerHTML = `
    <div class="contact-avatar">${initial}</div>
    <div class="contact-info" style="flex: 1; min-width: 0;">
        <span class="contact-name" style="display: flex; justify-content: space-between; align-items: center;">
            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${contact.name}</span>
        </span>
        <span class="contact-number">+${contact.number}</span>
    </div>
`;
        
        item.addEventListener('click', () => {
            item.classList.toggle('selected');
            const id = item.dataset.id;
            if (item.classList.contains('selected')) {
                state.selectedContacts.push(id);
            } else {
                state.selectedContacts = state.selectedContacts.filter(cId => cId !== id);
            }
        });
        
        container.appendChild(item);
    });

    btn.innerText = originalText;
}

async function loadGroupsForLeave() {
    const container = document.getElementById('group-list-leave-container');
    container.innerHTML = '<div style="text-align:center; padding:20px; color:var(--cp-neon);">Carregando grupos...</div>';

    const groupsJson = await runInWa(async () => {
        if (!window.FMARK || !window.FMARK.infoAllGroupList) return "[]";
        return await window.FMARK.infoAllGroupList();
    });

    const groups = JSON.parse(groupsJson || "[]");
    container.innerHTML = '';
    state.selectedGroupsToLeave = [];

    if (groups.error || groups.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">Nenhum grupo encontrado.</div>';
        return;
    }

    groups.forEach(group => {
        const item = document.createElement('div');
        item.className = 'contact-item';
        item.dataset.id = group.id;
        item.dataset.name = group.subject || 'Grupo sem nome';
        item.dataset.count = group.participantsCount || 0;

        const initial = group.subject ? group.subject.charAt(0).toUpperCase() : 'G';

        item.innerHTML = `
    <div class="contact-avatar">${initial}</div>
    <div class="contact-info" style="flex: 1; min-width: 0;">
        <span class="contact-name" style="display: flex; justify-content: space-between; align-items: center;">
            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${group.subject || 'Grupo sem nome'}</span>
            ${typeof adminBadge !== 'undefined' ? adminBadge : ''}
        </span>
        <span class="contact-number">${group.participantsCount} participantes</span>
    </div>
`;

        item.addEventListener('click', () => {
            item.classList.toggle('selected');
            const id = item.dataset.id;
            
            if (item.classList.contains('selected')) {
                if (!state.selectedGroupsToLeave.some(g => g.id === id)) {
                    state.selectedGroupsToLeave.push({
                        id: id,
                        name: item.dataset.name,
                        count: item.dataset.count
                    });
                }
            } else {
                state.selectedGroupsToLeave = state.selectedGroupsToLeave.filter(g => g.id !== id);
            }

            const node2 = document.getElementById('node-leave-2');
            const connector = document.getElementById('node-connector-leave');

            if (node2 && node2.classList.contains('active')) {
                node2.classList.remove('active');
                if (connector) connector.classList.remove('active');

                setTimeout(() => {
                    if (state.selectedGroupsToLeave.length > 0) {
                        if (connector) connector.classList.add('active');
                        setTimeout(() => {
                            node2.classList.add('active');
                            loadSelectedGroupsForLeaveConfirm();
                        }, 300);
                    }
                }, 400);
            }
        });

        container.appendChild(item);
    });
}

function loadSelectedGroupsForLeaveConfirm() {
    const container = document.getElementById('selected-groups-leave-container');
    container.innerHTML = '';

    state.selectedGroupsToLeave.forEach(group => {
        const item = document.createElement('div');
        item.className = 'contact-item';
        const initial = group.name.charAt(0).toUpperCase();
        
        item.innerHTML = `
    <div class="contact-avatar">${initial}</div>
    <div class="contact-info" style="flex: 1; min-width: 0;">
        <span class="contact-name" style="display: flex; justify-content: space-between; align-items: center;">
            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${group.subject || 'Grupo sem nome'}</span>
            ${typeof adminBadge !== 'undefined' ? adminBadge : ''}
        </span>
        <span class="contact-number">${group.participantsCount} participantes</span>
    </div>
`;
        container.appendChild(item);
    });
}

async function handleLeaveGroupsSubmit() {
    if (state.selectedGroupsToLeave.length === 0) return;

    const btn = document.getElementById('btn-finish-leave-group');
    const originalText = btn.innerText;
    btn.innerText = 'Saindo...';

    let successCount = 0;
    let failCount = 0;

    for (let i = 0; i < state.selectedGroupsToLeave.length; i++) {
        const group = state.selectedGroupsToLeave[i];
        
        const result = await runInWa(async (groupId) => {
            try {
                const wid = window.Store.WidFactory.createWid(groupId);
                let chat = window.Store.Chat.get(wid);
                
                if (!chat && window.FMARK && window.FMARK.findChat) {
                    chat = await window.FMARK.findChat(wid, "username_contactless_search", { forceUsync: true });
                }

                if (!chat) return false;

                if (window.Store.GroupActions && typeof window.Store.GroupActions.sendExitGroup === 'function') {
                    await window.Store.GroupActions.sendExitGroup(chat);
                    return true;
                }
                
                if (window.Store.sendExitGroup && typeof window.Store.sendExitGroup === 'function') {
                    await window.Store.sendExitGroup(chat);
                    return true;
                }

                if (window.FMARK && window.FMARK.findModuleByFunctions) {
                    const exitModule = window.FMARK.findModuleByFunctions(['sendExitGroup']);
                    if (exitModule && exitModule.module && typeof exitModule.module.sendExitGroup === 'function') {
                        await exitModule.module.sendExitGroup(chat);
                        return true;
                    }
                }

                if (window.FMARK && typeof window.FMARK.leaveGroup === 'function') {
                    await window.FMARK.leaveGroup(groupId);
                    return true;
                }

                return false;
            } catch (e) {
                return false;
            }
        }, [group.id]);

        if (result) successCount++;
        else failCount++;

        if (i < state.selectedGroupsToLeave.length - 1) {
            await new Promise(resolve => setTimeout(resolve, 1500));
        }
    }

    btn.innerText = originalText;
    alert(`Processo concluído!\nGrupos que você saiu: ${successCount}\nFalhas: ${failCount}`);
    
    if (successCount > 0) {
        document.getElementById('close-flow-leave').click();
    }
}

function setupImageUpload() {
    const uploadBtn = document.querySelector('.group-image-upload');
    if (!uploadBtn) return;
    
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/jpeg, image/png';
    fileInput.style.display = 'none';
    document.body.appendChild(fileInput);
    
    uploadBtn.addEventListener('click', () => fileInput.click());
    
    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = (event) => {
            state.groupImageBase64 = event.target.result;
            uploadBtn.innerHTML = '';
            uploadBtn.style.backgroundImage = `url(${state.groupImageBase64})`;
            uploadBtn.style.backgroundSize = 'cover';
            uploadBtn.style.backgroundPosition = 'center';
            uploadBtn.style.border = 'none';
        };
        reader.readAsDataURL(file);
    });
}

async function handleCreateGroup() {
    const nameInput = document.querySelector('.group-name-input');
    const baseName = nameInput ? nameInput.value.trim() : '';
    const isMultiple = document.getElementById('check-multiple-groups')?.checked;
    const qtdInput = document.getElementById('input-multiple-qtd');
    const qtd = parseInt(qtdInput?.value) || 0;
    
    if (!baseName) {
        alert("Digite um nome para o grupo!");
        return;
    }
    if (state.selectedContacts.length === 0) {
        alert("Selecione pelo menos um contato!");
        return;
    }
    if (isMultiple && (qtd < 2 || qtd > 50)) {
        alert("Para múltiplos grupos, digite uma quantidade válida (entre 2 e 50).");
        return;
    }
    
    const btn = document.getElementById('btn-finish-group');
    const originalText = btn.innerText;
    
    let successCount = 0;
    let failCount = 0;
    const totalGroups = isMultiple ? qtd : 1;

    btn.disabled = true;

    for (let i = 1; i <= totalGroups; i++) {
        const currentName = isMultiple ? `${baseName} ${i}` : baseName;
        btn.innerText = isMultiple ? `Criando (${i}/${totalGroups})...` : 'Criando...';
        
        console.log(`[WAgroup] Tentando criar grupo: ${currentName}`);
        
        const result = await runInWa(async (groupName, participants, imageB64) => {
            try {
                let groupId = null;

                if (window.FMARK && window.FMARK.groupCreate) {
                    const res = await window.FMARK.groupCreate(groupName, participants);
                    groupId = res?.gid?._serialized || res?.gid || null;
                }

                if (!groupId && window.FMARK && window.FMARK.createGroup) {
                    const res = await window.FMARK.createGroup(groupName, participants);
                    groupId = typeof res === 'string' ? res : null;
                }

                console.log("[WAgroup] Resposta criação:", groupId);

                if (groupId && imageB64) {
                    try {
                        await window.FMARK.setIconToGroup(groupId, imageB64);
                    } catch (e) {}
                }
                
                return groupId;
            } catch (err) {
                return null;
            }
        }, [currentName, state.selectedContacts, state.groupImageBase64]);

        console.log(`[WAgroup] Resultado do runInWa para ${currentName}:`, result);

        if (result) {
            successCount++;
        } else {
            failCount++;
        }

        if (i < totalGroups) {
            await new Promise(r => setTimeout(r, 3500));
        }
    }
    
    btn.disabled = false;
    btn.innerText = originalText;

    if (successCount > 0) {
        if (isMultiple) {
            alert(`Processo concluído!\nGrupos criados: ${successCount}\nFalhas: ${failCount}`);
        } else {
            alert("Grupo criado com sucesso!");
        }
        
        document.getElementById('close-flow').click();
        nameInput.value = '';
        if (qtdInput) qtdInput.value = '';
        state.groupImageBase64 = null;
        
        const uploadBtn = document.querySelector('.group-image-upload');
        if (uploadBtn) {
            uploadBtn.style.backgroundImage = 'none';
            uploadBtn.style.border = '';
            uploadBtn.innerHTML = '<svg viewBox="0 0 24 24"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"></path></svg>';
        }
    } else {
        alert("Falha ao criar o(s) grupo(s). Verifique o console (F12) para ver o erro exato.");
    }
}

async function loadGroupsForAddMembers() {
    const container = document.getElementById('group-list-container');
    container.innerHTML = '<div style="text-align:center; padding:20px; color:var(--cp-neon);">Carregando grupos...</div>';

    const groupsJson = await runInWa(async () => {
        if (!window.FMARK || !window.FMARK.infoAllGroupList) return "[]";
        return await window.FMARK.infoAllGroupList();
    });

    const groups = JSON.parse(groupsJson || "[]");
    container.innerHTML = '';
    state.selectedGroupToAdd = null;

    if (groups.error || groups.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">Nenhum grupo encontrado.</div>';
        return;
    }

    groups.forEach(group => {
        const item = document.createElement('div');
        item.className = 'contact-item';
        item.dataset.id = group.id;

        const initial = group.subject ? group.subject.charAt(0).toUpperCase() : 'G';
        const adminBadge = group.isAdmin
            ? '<span style="color:#00ff00; font-size:10px; border:1px solid rgba(0,255,0,0.3); background:rgba(0,255,0,0.1); padding:2px 4px; border-radius:4px; margin-left:8px;">ADMIN</span>'
            : '<span style="color:#ff5555; font-size:10px; border:1px solid rgba(255,85,85,0.3); background:rgba(255,85,85,0.1); padding:2px 4px; border-radius:4px; margin-left:8px;">MEMBRO</span>';

        item.innerHTML = `
        <div class="contact-avatar">${initial}</div>
        <div class="contact-info" style="flex: 1; min-width: 0;">
            <span class="contact-name" style="display: flex; justify-content: space-between; align-items: center;">
                <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${group.subject || 'Grupo sem nome'}</span>
                ${typeof adminBadge !== 'undefined' ? adminBadge : ''}
            </span>
            <span class="contact-number">${group.participantsCount} participantes</span>
        </div>
    `;
        item.addEventListener('click', () => {
            document.querySelectorAll('#group-list-container .contact-item').forEach(el => el.classList.remove('selected'));
            item.classList.add('selected');
            
            const isSameGroup = state.selectedGroupToAdd === group.id;
            state.selectedGroupToAdd = group.id;

            const node2 = document.getElementById('node-add-2');
            const connector = document.getElementById('node-connector-add');
            
            if (node2 && node2.classList.contains('active') && !isSameGroup) {
                node2.classList.remove('active');
                if (connector) connector.classList.remove('active');
                
                setTimeout(() => {
                    if (connector) connector.classList.add('active');
                    setTimeout(() => {
                        node2.classList.add('active');
                        loadContactsForAddMembers();
                    }, 300);
                }, 400); 
            }
        });

        container.appendChild(item);
    });
}

async function loadContactsForAddMembers() {
    const btn = document.getElementById('btn-next-node-add');
    const originalText = btn.innerText;
    btn.innerText = 'Carregando...';

    const contacts = await runInWa(() => {
        let models = [];
        if (window.Store && window.Store.Contact && window.Store.Contact.getModelsArray) {
            models = window.Store.Contact.getModelsArray();
        } else if (window.FMARK && typeof window.FMARK.getAllContacts === 'function') {
            models = window.FMARK.getAllContacts();
        }

        const contactList = [];
        models.forEach(contact => {
            try {
                if (contact.isGroup || contact.isBroadcast || (contact.id && contact.id.server !== 'c.us')) return;
                const numero = contact.id?.user || contact.userid;
                const nome = contact.name || contact.pushname || contact.formattedName || "Desconhecido";
                if (numero) {
                    const cleanNumber = String(numero).replace(/\D/g, "");
                    if (cleanNumber.length >= 8 && cleanNumber.length <= 15) {
                        contactList.push({
                            id: contact.id?._serialized || `${cleanNumber}@c.us`,
                            name: nome,
                            number: cleanNumber
                        });
                    }
                }
            } catch (err) {}
        });
        return contactList.sort((a, b) => a.name.localeCompare(b.name));
    });

    const container = document.getElementById('contact-list-add-container');
    container.innerHTML = '';
    state.selectedContactsToAdd = [];

    if (!contacts) {
        btn.innerText = 'Erro ao carregar';
        return;
    }

    contacts.forEach(contact => {
        const item = document.createElement('div');
        item.className = 'contact-item';
        item.dataset.id = contact.id;
        const initial = contact.name.charAt(0).toUpperCase();

        item.innerHTML = `
    <div class="contact-avatar">${initial}</div>
    <div class="contact-info" style="flex: 1; min-width: 0;">
        <span class="contact-name" style="display: flex; justify-content: space-between; align-items: center;">
            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${contact.name}</span>
        </span>
        <span class="contact-number">+${contact.number}</span>
    </div>
`;

        item.addEventListener('click', () => {
            item.classList.toggle('selected');
            const id = item.dataset.id;
            if (item.classList.contains('selected')) {
                state.selectedContactsToAdd.push(id);
            } else {
                state.selectedContactsToAdd = state.selectedContactsToAdd.filter(cId => cId !== id);
            }
        });

        container.appendChild(item);
    });

    btn.innerText = originalText;
}

async function handleAddMembersSubmit() {
    const finalContactsList = [...state.selectedContactsToAdd];
    
    if (state.importedContactsToAdd && state.importedContactsToAdd.length > 0) {
        state.importedContactsToAdd.forEach(num => {
            finalContactsList.push(`${num}@c.us`);
        });
    }

    if (finalContactsList.length === 0) {
        alert("Selecione contatos na lista ou importe um arquivo!");
        return;
    }

    const btn = document.getElementById('btn-finish-add-members');
    const originalText = btn.innerText;
    btn.innerText = 'Adicionando...';

    const result = await runInWa(async (groupId, participantsIds) => {
        if (!window.FMARK || !window.FMARK.addParticipantsBatch) return { error: "API FMARK indisponível" };
        return await window.FMARK.addParticipantsBatch(groupId, participantsIds);
    }, [state.selectedGroupToAdd, finalContactsList]);

    btn.innerText = originalText;

    if (result && !result.error) {
        let success = 0, fail = 0;
        Object.values(result).forEach(r => (r.code === 200 || r.code === 403) ? success++ : fail++);
        alert(`Processo concluído!\nAdicionados/Convites: ${success}\nFalhas: ${fail}`);
        document.getElementById('close-flow-add').click();
    } else {
        alert("Falha ao adicionar: " + (result?.error || "Verifique suas permissões no grupo."));
    }
}

async function loadGroupsForRemoveMembers() {
    const container = document.getElementById('group-list-remove-container');
    container.innerHTML = '<div style="text-align:center; padding:20px; color:var(--cp-neon);">Carregando grupos...</div>';

    const groupsJson = await runInWa(async () => {
        if (!window.FMARK || !window.FMARK.infoAllGroupList) return "[]";
        return await window.FMARK.infoAllGroupList();
    });

    const groups = JSON.parse(groupsJson || "[]");
    container.innerHTML = '';
    state.selectedGroupToRemove = null;

    if (groups.error || groups.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">Nenhum grupo encontrado.</div>';
        return;
    }

    groups.forEach(group => {
        const item = document.createElement('div');
        item.className = 'contact-item';
        item.dataset.id = group.id;

        const initial = group.subject ? group.subject.charAt(0).toUpperCase() : 'G';
        const adminBadge = group.isAdmin
            ? '<span style="color:#00ff00; font-size:10px; border:1px solid rgba(0,255,0,0.3); background:rgba(0,255,0,0.1); padding:2px 4px; border-radius:4px; margin-left:8px;">ADMIN</span>'
            : '<span style="color:#ff5555; font-size:10px; border:1px solid rgba(255,85,85,0.3); background:rgba(255,85,85,0.1); padding:2px 4px; border-radius:4px; margin-left:8px;">MEMBRO</span>';

        item.innerHTML = `
    <div class="contact-avatar">${initial}</div>
    <div class="contact-info" style="flex: 1; min-width: 0;">
        <span class="contact-name" style="display: flex; justify-content: space-between; align-items: center;">
            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${group.subject || 'Grupo sem nome'}</span>
            ${typeof adminBadge !== 'undefined' ? adminBadge : ''}
        </span>
        <span class="contact-number">${group.participantsCount} participantes</span>
    </div>
`;

        item.addEventListener('click', () => {
            document.querySelectorAll('#group-list-remove-container .contact-item').forEach(el => el.classList.remove('selected'));
            item.classList.add('selected');
            
            const isSameGroup = state.selectedGroupToRemove === group.id;
            state.selectedGroupToRemove = group.id;

            const node2 = document.getElementById('node-remove-2');
            const connector = document.getElementById('node-connector-remove');
            
            if (node2 && node2.classList.contains('active') && !isSameGroup) {
                node2.classList.remove('active');
                if (connector) connector.classList.remove('active');
                
                setTimeout(() => {
                    if (connector) connector.classList.add('active');
                    setTimeout(() => {
                        node2.classList.add('active');
                        loadMembersForRemoval();
                    }, 300);
                }, 400); 
            }
        });

        container.appendChild(item);
    });
}

async function loadMembersForRemoval() {
    const btn = document.getElementById('btn-next-node-remove');
    const originalText = btn.innerText;
    btn.innerText = 'Carregando...';

    const membersJson = await runInWa(async (groupId) => {
        if (!window.FMARK || !window.FMARK.getGroupMetadata) return "[]";
        try {
            const metadata = await window.FMARK.getGroupMetadata(groupId);
            const models = metadata?.participants?.getModelsArray ? metadata.participants.getModelsArray() : (metadata?.participants?._models || []);
            const me = window.FMARK.getMyUserId();
            const meUser = me ? me.user : "";

            const list = [];
            
            for (const p of models) {
                const isMe = p.id.user === meUser || (p.contact?.id?.user === meUser);
                if (isMe) continue;

                let validId = p.id._serialized;
                let validNumber = p.id.user;

                if (p.contact?.phoneNumber) {
                    validNumber = p.contact.phoneNumber.user;
                } else if (p.id.server === 'lid') {
                    try {
                        const pn = window.Store?.WeblidPnCache?.getPhoneNumber(p.id) || window.Store?.ApiContact?.getPhoneNumber(p.id);
                        if (pn) validNumber = pn.user;
                    } catch (e) {}
                }

                const name = p.contact?.name || p.contact?.pushname || validNumber || "Desconhecido";

                list.push({
                    id: validId,
                    name: name,
                    number: validNumber,
                    isAdmin: p.isAdmin
                });
            }

            return JSON.stringify(list.sort((a, b) => a.name.localeCompare(b.name)));
        } catch (e) {
            return "[]";
        }
    }, [state.selectedGroupToRemove]);

    const members = JSON.parse(membersJson || "[]");
    const container = document.getElementById('member-list-remove-container');
    container.innerHTML = '';
    state.selectedMembersToRemove = [];

    if (members.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">Nenhum membro passível de remoção encontrado.</div>';
        btn.innerText = originalText;
        return;
    }

    members.forEach(member => {
        const item = document.createElement('div');
        item.className = 'contact-item';
        item.dataset.id = member.id;
        
        const initial = member.name.charAt(0).toUpperCase();
        const adminBadge = member.isAdmin ? '<span style="color:#00ff00; font-size:10px; border:1px solid rgba(0,255,0,0.3); background:rgba(0,255,0,0.1); padding:2px 4px; border-radius:4px; margin-left:8px;">ADMIN</span>' : '';

        item.innerHTML = `
            <div class="contact-avatar">${initial}</div>
            <div class="contact-info" style="flex: 1; min-width: 0;">
                <span class="contact-name" style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${member.name}</span>
                    ${adminBadge}
                </span>
                <span class="contact-number">+${member.number}</span>
            </div>
        `;

        item.addEventListener('click', () => {
            item.classList.toggle('selected');
            const id = item.dataset.id;
            if (item.classList.contains('selected')) {
                state.selectedMembersToRemove.push(id);
            } else {
                state.selectedMembersToRemove = state.selectedMembersToRemove.filter(cId => cId !== id);
            }
        });

        container.appendChild(item);
    });

    btn.innerText = originalText;
}

async function handleRemoveMembersSubmit() {
    if (state.selectedMembersToRemove.length === 0) {
        alert("Selecione pelo menos um membro para remover!");
        return;
    }

    const btn = document.getElementById('btn-finish-remove-members');
    const originalText = btn.innerText;
    btn.innerText = 'Removendo...';

    const result = await runInWa(async (groupId, membersIds) => {
        if (!window.FMARK || !window.FMARK.removeParticipant) return null;
        try {
            return await window.FMARK.removeParticipant(groupId, membersIds);
        } catch (e) {
            return null;
        }
    }, [state.selectedGroupToRemove, state.selectedMembersToRemove]);

    btn.innerText = originalText;

    if (result) {
        let success = 0, fail = 0;
        if (typeof result === 'object' && !Array.isArray(result)) {
            Object.values(result).forEach(r => (r === 200 || r.code === 200) ? success++ : fail++);
        } else {
            success = state.selectedMembersToRemove.length;
        }
        alert(`Processo concluído!\nRemovidos: ${success}\nFalhas: ${fail}`);
        document.getElementById('close-flow-remove').click();
    } else {
        alert("Falha ao remover membros. Verifique sua conexão e permissões.");
    }
}

async function loadGroupsForPromoteMembers() {
    const container = document.getElementById('group-list-promote-container');
    container.innerHTML = '<div style="text-align:center; padding:20px; color:var(--cp-neon);">Carregando grupos...</div>';
    
    const groupsJson = await runInWa(async () => {
        if (!window.FMARK || !window.FMARK.infoAllGroupList) return "[]";
        return await window.FMARK.infoAllGroupList();
    });
    
    const groups = JSON.parse(groupsJson || "[]");
    container.innerHTML = '';
    state.selectedGroupToPromote = null;
    
    groups.forEach(group => {
        if(!group.isAdmin) return;
        
        const item = document.createElement('div');
        item.className = 'contact-item';
        const initial = group.subject ? group.subject.charAt(0).toUpperCase() : 'G';
        item.innerHTML = `<div class="contact-avatar">${initial}</div><div class="contact-info"><span class="contact-name">${group.subject}</span><span class="contact-number">${group.participantsCount} participantes</span></div>`;
        
        item.addEventListener('click', () => {
            document.querySelectorAll('#group-list-promote-container .contact-item').forEach(el => el.classList.remove('selected'));
            item.classList.add('selected');
            
            const isSameGroup = state.selectedGroupToPromote === group.id;
            state.selectedGroupToPromote = group.id;
            
            const node2 = document.getElementById('node-promote-2');
            const connector = document.getElementById('node-connector-promote');
            
            if (node2 && node2.classList.contains('active') && !isSameGroup) {
                node2.classList.remove('active');
                if (connector) connector.classList.remove('active');
                
                setTimeout(() => {
                    if (connector) connector.classList.add('active');
                    setTimeout(() => {
                        node2.classList.add('active');
                        loadMembersForPromotion();
                    }, 300);
                }, 400);
            }
        });
        
        container.appendChild(item);
    });
}

async function loadMembersForPromotion() {
    const btn = document.getElementById('btn-next-node-promote');
    btn.innerText = 'Carregando...';
    const membersJson = await runInWa(async (groupId) => {
        if (!window.FMARK || !window.FMARK.getGroupMetadata) return "[]";
        const metadata = await window.FMARK.getGroupMetadata(groupId);
        const models = metadata?.participants?.getModelsArray ? metadata.participants.getModelsArray() : (metadata?.participants?._models || []);
        const list = models.filter(p => !p.isAdmin).map(p => ({
            id: p.id._serialized,
            name: p.contact?.name || p.contact?.pushname || p.id.user || "Desconhecido"
        }));
        return JSON.stringify(list);
    }, [state.selectedGroupToPromote]);
    const members = JSON.parse(membersJson || "[]");
    const container = document.getElementById('member-list-promote-container');
    container.innerHTML = '';
    state.selectedMembersToPromote = [];
    members.forEach(member => {
        const item = document.createElement('div');
        item.className = 'contact-item';
        item.innerHTML = `<div class="contact-avatar">${member.name.charAt(0)}</div><div class="contact-info"><span class="contact-name">${member.name}</span></div>`;
        item.addEventListener('click', () => {
            item.classList.toggle('selected');
            const id = member.id;
            if (item.classList.contains('selected')) state.selectedMembersToPromote.push(id);
            else state.selectedMembersToPromote = state.selectedMembersToPromote.filter(mId => mId !== id);
        });
        container.appendChild(item);
    });
    btn.innerText = 'Próximo';
}

async function handlePromoteMembersSubmit() {
    if (state.selectedMembersToPromote.length === 0) { 
        alert("Selecione pelo menos um membro!"); 
        return; 
    }
    
    const btn = document.getElementById('btn-finish-promote-members');
    const originalText = btn.innerText;
    btn.innerText = 'Promovendo...';

    // Garantimos que estamos enviando um array limpo de IDs (strings)
    const participantsToPromote = Array.from(state.selectedMembersToPromote);

    const result = await runInWa(async (groupId, ids) => {
        try {
            if (!window.FMARK || !window.FMARK.promoteParticipant) {
                console.error("FMARK promoteParticipant não encontrada");
                return false;
            }
            // A FMARK internamente já trata a busca dos modelos dos participantes
            return await window.FMARK.promoteParticipant(groupId, ids);
        } catch (e) {
            console.error("Erro interno na promoção:", e);
            return false;
        }
    }, [state.selectedGroupToPromote, participantsToPromote]);

    if (result) {
        alert("Sucesso ao promover membros!");
        document.getElementById('close-flow-promote').click();
    } else { 
        alert("Erro ao promover. Certifique-se de que você é ADMIN do grupo e os membros ainda estão lá."); 
    }
    
    btn.innerText = originalText;
}

async function loadGroupsForDemoteMembers() {
    const container = document.getElementById('group-list-demote-container');
    container.innerHTML = '<div style="text-align:center; padding:20px; color:var(--cp-neon);">Carregando grupos...</div>';
    
    const groupsJson = await runInWa(async () => {
        if (!window.FMARK || !window.FMARK.infoAllGroupList) return "[]";
        return await window.FMARK.infoAllGroupList();
    });
    
    const groups = JSON.parse(groupsJson || "[]");
    container.innerHTML = '';
    state.selectedGroupToDemote = null;
    
    groups.forEach(group => {
        if(!group.isAdmin) return;
        
        const item = document.createElement('div');
        item.className = 'contact-item';
        item.innerHTML = `<div class="contact-avatar">${group.subject ? group.subject.charAt(0).toUpperCase() : 'G'}</div><div class="contact-info"><span class="contact-name">${group.subject}</span><span class="contact-number">${group.participantsCount} participantes</span></div>`;
        
        item.addEventListener('click', () => {
            document.querySelectorAll('#group-list-demote-container .contact-item').forEach(el => el.classList.remove('selected'));
            item.classList.add('selected');
            
            const isSameGroup = state.selectedGroupToDemote === group.id;
            state.selectedGroupToDemote = group.id;
            
            const node2 = document.getElementById('node-demote-2');
            const connector = document.getElementById('node-connector-demote');
            
            if (node2 && node2.classList.contains('active') && !isSameGroup) {
                node2.classList.remove('active');
                if (connector) connector.classList.remove('active');
                
                setTimeout(() => {
                    if (connector) connector.classList.add('active');
                    setTimeout(() => {
                        node2.classList.add('active');
                        loadMembersForDemotion();
                    }, 300);
                }, 400);
            }
        });
        
        container.appendChild(item);
    });
}

async function loadMembersForDemotion() {
    const btn = document.getElementById('btn-next-node-demote');
    btn.innerText = 'Carregando...';
    const membersJson = await runInWa(async (groupId) => {
        if (!window.FMARK || !window.FMARK.getGroupMetadata) return "[]";
        const metadata = await window.FMARK.getGroupMetadata(groupId);
        const models = metadata?.participants?.getModelsArray ? metadata.participants.getModelsArray() : (metadata?.participants?._models || []);
        const me = window.FMARK.getMyUserId()?.user;
        const list = models.filter(p => p.isAdmin && p.id.user !== me).map(p => ({
            id: p.id._serialized,
            name: p.contact?.name || p.contact?.pushname || p.id.user || "Desconhecido"
        }));
        return JSON.stringify(list);
    }, [state.selectedGroupToDemote]);
    const members = JSON.parse(membersJson || "[]");
    const container = document.getElementById('member-list-demote-container');
    container.innerHTML = '';
    state.selectedMembersToDemote = [];
    members.forEach(member => {
        const item = document.createElement('div');
        item.className = 'contact-item';
        item.innerHTML = `<div class="contact-avatar">${member.name.charAt(0)}</div><div class="contact-info"><span class="contact-name">${member.name}</span></div>`;
        item.addEventListener('click', () => {
            item.classList.toggle('selected');
            if (item.classList.contains('selected')) state.selectedMembersToDemote.push(member.id);
            else state.selectedMembersToDemote = state.selectedMembersToDemote.filter(mId => mId !== member.id);
        });
        container.appendChild(item);
    });
    btn.innerText = 'Próximo';
}

async function handleDemoteMembersSubmit() {
    if (state.selectedMembersToDemote.length === 0) { alert("Selecione pelo menos um admin!"); return; }
    const btn = document.getElementById('btn-finish-demote-members');
    btn.innerText = 'Rebaixando...';
    const result = await runInWa(async (groupId, ids) => {
        if (!window.FMARK || !window.FMARK.demoteParticipant) return false;
        return await window.FMARK.demoteParticipant(groupId, ids);
    }, [state.selectedGroupToDemote, state.selectedMembersToDemote]);
    if (result) {
        alert("Sucesso ao rebaixar administradores!");
        document.getElementById('close-flow-demote').click();
    } else { alert("Erro ao rebaixar. Verifique suas permissões."); }
    btn.innerText = 'Rebaixar Selecionados';
}

async function loadGroupsForEditName() {
    const container = document.getElementById('group-list-edit-name-container');
    container.innerHTML = '<div style="text-align:center; padding:20px; color:var(--cp-neon);">Carregando grupos...</div>';
    
    const groupsJson = await runInWa(async () => {
        if (!window.FMARK || !window.FMARK.infoAllGroupList) return "[]";
        return await window.FMARK.infoAllGroupList();
    });
    
    const groups = JSON.parse(groupsJson || "[]");
    container.innerHTML = '';
    state.selectedGroupToEditName = null;
    
    if (groups.error || groups.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">Nenhum grupo encontrado.</div>';
        return;
    }

    groups.forEach(group => {
        const item = document.createElement('div');
        item.className = 'contact-item';
        item.dataset.id = group.id;

        const initial = group.subject ? group.subject.charAt(0).toUpperCase() : 'G';
        const adminBadge = group.isAdmin
            ? '<span style="color:#00ff00; font-size:10px; border:1px solid rgba(0,255,0,0.3); background:rgba(0,255,0,0.1); padding:2px 4px; border-radius:4px; margin-left:8px;">ADMIN</span>'
            : '<span style="color:#ff5555; font-size:10px; border:1px solid rgba(255,85,85,0.3); background:rgba(255,85,85,0.1); padding:2px 4px; border-radius:4px; margin-left:8px;">MEMBRO</span>';

        item.innerHTML = `
    <div class="contact-avatar">${initial}</div>
    <div class="contact-info" style="flex: 1; min-width: 0;">
        <span class="contact-name" style="display: flex; justify-content: space-between; align-items: center;">
            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${group.subject || 'Grupo sem nome'}</span>
            ${typeof adminBadge !== 'undefined' ? adminBadge : ''}
        </span>
        <span class="contact-number">${group.participantsCount} participantes</span>
    </div>
`;

        item.addEventListener('click', () => {
            document.querySelectorAll('#group-list-edit-name-container .contact-item').forEach(el => el.classList.remove('selected'));
            item.classList.add('selected');
            state.selectedGroupToEditName = group.id;
        });

        container.appendChild(item);
    });
}

async function handleEditNameSubmit() {
    if (!state.selectedGroupToEditName) {
        alert("Selecione um grupo primeiro!");
        return;
    }

    const newNameInput = document.getElementById('new-group-name-input');
    const newName = newNameInput ? newNameInput.value.trim() : '';

    if (!newName) {
        alert("Digite o novo nome do grupo!");
        return;
    }

    const btn = document.getElementById('btn-finish-edit-name');
    const originalText = btn.innerText;
    btn.innerText = 'Alterando...';

    const result = await runInWa(async (groupId, title) => {
        try {
            const wid = window.Store.WidFactory.createWid(groupId);

            if (window.Store.sendSetGroupProperty && typeof window.Store.sendSetGroupProperty.sendSetGroupSubject === 'function') {
                await window.Store.sendSetGroupProperty.sendSetGroupSubject(wid, title);
                return true;
            }

            if (window.Store.sendSetGroupProperty && typeof window.Store.sendSetGroupProperty.setGroupSubject === 'function') {
                await window.Store.sendSetGroupProperty.setGroupSubject(wid, title);
                return true;
            }

            if (window.Store.setGroupOptions && typeof window.Store.setGroupOptions.setGroupSubject === 'function') {
                await window.Store.setGroupOptions.setGroupSubject(wid, title);
                return true;
            }

            if (window.FMARK && typeof window.FMARK.setGroupTitle === 'function') {
                return await window.FMARK.setGroupTitle(groupId, title);
            }

            if (window.FMARK && typeof window.FMARK.alterednamegroup === 'function') {
                window.FMARK.alterednamegroup(groupId, title);
                return true;
            }

            return false;
        } catch (e) {
            return false;
        }
    }, [state.selectedGroupToEditName, newName]);

    btn.innerText = originalText;

    if (result) {
        alert("Nome do grupo alterado com sucesso!");
        document.getElementById('close-flow-edit-name').click();
    } else {
        alert("Falha ao alterar o nome. Verifique se você tem permissão neste grupo.");
    }
}

function setupEditImageUpload() {
    const uploadBtn = document.getElementById('edit-image-upload-btn');
    if (!uploadBtn) return;
    
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/jpeg, image/png';
    fileInput.style.display = 'none';
    document.body.appendChild(fileInput);
    
    uploadBtn.addEventListener('click', () => fileInput.click());
    
    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = (event) => {
            state.newGroupImageBase64 = event.target.result;
            uploadBtn.innerHTML = '';
            uploadBtn.style.backgroundImage = `url(${state.newGroupImageBase64})`;
            uploadBtn.style.backgroundSize = 'cover';
            uploadBtn.style.backgroundPosition = 'center';
            uploadBtn.style.border = 'none';
        };
        reader.readAsDataURL(file);
    });
}

async function loadGroupsForEditImage() {
    const container = document.getElementById('group-list-edit-image-container');
    container.innerHTML = '<div style="text-align:center; padding:20px; color:var(--cp-neon);">Carregando grupos...</div>';
    
    const groupsJson = await runInWa(async () => {
        if (!window.FMARK || !window.FMARK.infoAllGroupList) return "[]";
        return await window.FMARK.infoAllGroupList();
    });
    
    const groups = JSON.parse(groupsJson || "[]");
    container.innerHTML = '';
    state.selectedGroupToEditImage = null;
    
    if (groups.error || groups.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">Nenhum grupo encontrado.</div>';
        return;
    }

    groups.forEach(group => {
        const item = document.createElement('div');
        item.className = 'contact-item';
        item.dataset.id = group.id;

        const initial = group.subject ? group.subject.charAt(0).toUpperCase() : 'G';
        const adminBadge = group.isAdmin
            ? '<span style="color:#00ff00; font-size:10px; border:1px solid rgba(0,255,0,0.3); background:rgba(0,255,0,0.1); padding:2px 4px; border-radius:4px; margin-left:8px;">ADMIN</span>'
            : '<span style="color:#ff5555; font-size:10px; border:1px solid rgba(255,85,85,0.3); background:rgba(255,85,85,0.1); padding:2px 4px; border-radius:4px; margin-left:8px;">MEMBRO</span>';

        item.innerHTML = `
    <div class="contact-avatar">${initial}</div>
    <div class="contact-info" style="flex: 1; min-width: 0;">
        <span class="contact-name" style="display: flex; justify-content: space-between; align-items: center;">
            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${group.subject || 'Grupo sem nome'}</span>
            ${typeof adminBadge !== 'undefined' ? adminBadge : ''}
        </span>
        <span class="contact-number">${group.participantsCount} participantes</span>
    </div>
`;

        item.addEventListener('click', () => {
            document.querySelectorAll('#group-list-edit-image-container .contact-item').forEach(el => el.classList.remove('selected'));
            item.classList.add('selected');
            state.selectedGroupToEditImage = group.id;
        });

        container.appendChild(item);
    });
}

async function handleEditImageSubmit() {
    if (!state.selectedGroupToEditImage) {
        alert("Selecione um grupo primeiro!");
        return;
    }

    if (!state.newGroupImageBase64) {
        alert("Faça o upload de uma nova imagem primeiro!");
        return;
    }

    const btn = document.getElementById('btn-finish-edit-image');
    const originalText = btn.innerText;
    btn.innerText = 'Alterando...';

    const result = await runInWa(async (groupId, imageB64) => {
        try {
            if (window.FMARK && typeof window.FMARK.setIconToGroup === 'function') {
                await window.FMARK.setIconToGroup(groupId, imageB64);
                return true;
            }
            return false;
        } catch (e) {
            return false;
        }
    }, [state.selectedGroupToEditImage, state.newGroupImageBase64]);

    btn.innerText = originalText;

    if (result) {
        alert("Imagem do grupo alterada com sucesso!");
        document.getElementById('close-flow-edit-image').click();
    } else {
        alert("Falha ao alterar a imagem. Verifique se você tem permissão ou se é o administrador deste grupo.");
    }
}

async function loadGroupsForExtract() {
    const container = document.getElementById('group-list-extract-container');
    container.innerHTML = '<div style="text-align:center; padding:20px; color:var(--cp-neon);">Carregando grupos...</div>';
    
    const groupsJson = await runInWa(async () => {
        if (!window.FMARK || !window.FMARK.infoAllGroupList) return "[]";
        return await window.FMARK.infoAllGroupList();
    });
    
    const groups = JSON.parse(groupsJson || "[]");
    container.innerHTML = '';
    state.selectedGroupToExtract = null;
    
    if (groups.error || groups.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">Nenhum grupo encontrado.</div>';
        return;
    }

    groups.forEach(group => {
        const item = document.createElement('div');
        item.className = 'contact-item';
        item.dataset.id = group.id;

        const initial = group.subject ? group.subject.charAt(0).toUpperCase() : 'G';

        item.innerHTML = `
    <div class="contact-avatar">${initial}</div>
    <div class="contact-info" style="flex: 1; min-width: 0;">
        <span class="contact-name" style="display: flex; justify-content: space-between; align-items: center;">
            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${group.subject || 'Grupo sem nome'}</span>
            ${typeof adminBadge !== 'undefined' ? adminBadge : ''}
        </span>
        <span class="contact-number">${group.participantsCount} participantes</span>
    </div>
`;

        item.addEventListener('click', () => {
            document.querySelectorAll('#group-list-extract-container .contact-item').forEach(el => el.classList.remove('selected'));
            item.classList.add('selected');
            state.selectedGroupToExtract = group.id;
        });

        container.appendChild(item);
    });
}

function exportFile(data, format, prefix) {
    if (!data || data.length === 0) {
        alert("Nenhum contato encontrado para exportar.");
        return;
    }

    let content = "";
    let mime = "";
    let ext = "";

    if (format === 'csv') {
        content = "Nome,Numero\n" + data.map(c => `"${c.name}","${c.number}"`).join("\n");
        mime = "text/csv;charset=utf-8;";
        ext = "csv";
    } else {
        content = data.map(c => `${c.name} - ${c.number}`).join("\n");
        mime = "text/plain;charset=utf-8;";
        ext = "txt";
    }

    const blob = new Blob(["\ufeff" + content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${prefix}_${new Date().getTime()}.${ext}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

async function handleExtractGroup(format) {
    if (!state.selectedGroupToExtract) {
        alert("Selecione um grupo na lista à esquerda primeiro!");
        return;
    }

    const btn = document.getElementById(`btn-extract-group-${format}`);
    const originalText = btn.innerText;
    btn.innerText = 'Extraindo...';

    const groupContacts = await runInWa(async (groupId) => {
        if (!window.FMARK || !window.FMARK.getGroupMetadata) return [];
        try {
            const metadata = await window.FMARK.getGroupMetadata(groupId);
            const models = metadata?.participants?.getModelsArray ? metadata.participants.getModelsArray() : (metadata?.participants?._models || []);
            const list = [];
            for (const p of models) {
                let validNumber = p.id.user;
                if (p.contact?.phoneNumber) {
                    validNumber = p.contact.phoneNumber.user;
                } else if (p.id.server === 'lid') {
                    try {
                        const pn = window.Store?.WeblidPnCache?.getPhoneNumber(p.id) || window.Store?.ApiContact?.getPhoneNumber(p.id);
                        if (pn) validNumber = pn.user;
                    } catch (e) {}
                }
                const name = p.contact?.name || p.contact?.pushname || "Desconhecido";
                list.push({ name: name, number: validNumber });
            }
            return list.sort((a,b) => a.name.localeCompare(b.name));
        } catch(e) {
            return [];
        }
    }, [state.selectedGroupToExtract]);

    btn.innerText = originalText;
    exportFile(groupContacts, format, 'Grupo_Contatos');
}

async function handleExtractAll(format) {
    const btn = document.getElementById(`btn-extract-all-${format}`);
    const originalText = btn.innerText;
    btn.innerText = 'Extraindo...';

    const allContacts = await runInWa(() => {
        let models = [];
        if (window.Store && window.Store.Contact && window.Store.Contact.getModelsArray) {
            models = window.Store.Contact.getModelsArray();
        } else if (window.FMARK && typeof window.FMARK.getAllContacts === 'function') {
            models = window.FMARK.getAllContacts();
        }
        const list = [];
        models.forEach(c => {
            if (c.isGroup || c.isBroadcast || (c.id && c.id.server !== 'c.us')) return;
            const num = c.id?.user || c.userid;
            const name = c.name || c.pushname || c.formattedName || "Desconhecido";
            if (num) {
                const clean = String(num).replace(/\D/g, "");
                if (clean.length >= 8) {
                    list.push({ name: name, number: clean });
                }
            }
        });
        return list.sort((a,b) => a.name.localeCompare(b.name));
    });

    btn.innerText = originalText;
    exportFile(allContacts, format, 'Todos_Contatos');
}

async function loadGroupsForEditDesc() {
    const container = document.getElementById('group-list-edit-desc-container');
    container.innerHTML = '<div style="text-align:center; padding:20px; color:var(--cp-neon);">Carregando grupos...</div>';
    
    const groupsJson = await runInWa(async () => {
        if (!window.FMARK || !window.FMARK.infoAllGroupList) return "[]";
        return await window.FMARK.infoAllGroupList();
    });
    
    const groups = JSON.parse(groupsJson || "[]");
    container.innerHTML = '';
    state.selectedGroupToEditDesc = null;
    
    if (groups.error || groups.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">Nenhum grupo encontrado.</div>';
        return;
    }

    groups.forEach(group => {
        const item = document.createElement('div');
        item.className = 'contact-item';
        item.dataset.id = group.id;

        const initial = group.subject ? group.subject.charAt(0).toUpperCase() : 'G';
        const adminBadge = group.isAdmin
            ? '<span style="color:#00ff00; font-size:10px; border:1px solid rgba(0,255,0,0.3); background:rgba(0,255,0,0.1); padding:2px 4px; border-radius:4px; margin-left:8px;">ADMIN</span>'
            : '<span style="color:#ff5555; font-size:10px; border:1px solid rgba(255,85,85,0.3); background:rgba(255,85,85,0.1); padding:2px 4px; border-radius:4px; margin-left:8px;">MEMBRO</span>';

        item.innerHTML = `
    <div class="contact-avatar">${initial}</div>
    <div class="contact-info" style="flex: 1; min-width: 0;">
        <span class="contact-name" style="display: flex; justify-content: space-between; align-items: center;">
            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${group.subject || 'Grupo sem nome'}</span>
            ${typeof adminBadge !== 'undefined' ? adminBadge : ''}
        </span>
        <span class="contact-number">${group.participantsCount} participantes</span>
    </div>
`;

        item.addEventListener('click', () => {
            document.querySelectorAll('#group-list-edit-desc-container .contact-item').forEach(el => el.classList.remove('selected'));
            item.classList.add('selected');
            state.selectedGroupToEditDesc = group.id;
        });

        container.appendChild(item);
    });
}

async function handleEditDescSubmit() {
    if (!state.selectedGroupToEditDesc) {
        alert("Selecione um grupo primeiro!");
        return;
    }

    const newDescInput = document.getElementById('new-group-desc-input');
    const newDesc = newDescInput ? newDescInput.value.trim() : '';

    if (!newDesc && !confirm("A descrição está vazia. Deseja realmente remover a descrição atual do grupo?")) {
        return;
    }

    const btn = document.getElementById('btn-finish-edit-desc');
    const originalText = btn.innerText;
    btn.innerText = 'Alterando...';

    const result = await runInWa(async (groupId, desc) => {
        try {
            // A função setGroupDescription está mapeada diretamente no fmark.js
            if (window.FMARK && typeof window.FMARK.setGroupDescription === 'function') {
                await window.FMARK.setGroupDescription(groupId, desc);
                return true;
            }

            // Fallback usando o WidFactory caso a FMARK.setGroupDescription falhe ou mude
            const wid = window.Store.WidFactory.createWid(groupId);
            let chat = window.Store.Chat.get(wid);
            if (!chat && window.FMARK && window.FMARK.findChat) {
                chat = await window.FMARK.findChat(wid, "username_contactless_search", { forceUsync: true });
            }

            const targetId = chat ? chat.id : wid;

            if (window.Store.sendSetGroupProperty && typeof window.Store.sendSetGroupProperty.sendSetGroupDescription === 'function') {
                let newId = await window.Store.MsgKey.newId_DEPRECATED();
                let descId = chat && chat.groupMetadata ? chat.groupMetadata.descId : null;
                await window.Store.sendSetGroupProperty.sendSetGroupDescription(targetId, desc, newId, descId);
                return true;
            }

            return false;
        } catch (e) {
            return false;
        }
    }, [state.selectedGroupToEditDesc, newDesc]);

    btn.innerText = originalText;

    if (result) {
        alert("Descrição do grupo alterada com sucesso!");
        document.getElementById('close-flow-edit-desc').click();
    } else {
        alert("Falha ao alterar a descrição. Certifique-se de que o grupo permite edições ou que você é Admin.");
    }
}

async function loadGroupsForTransferSource() {
    const container = document.getElementById('group-list-transfer-source-container');
    container.innerHTML = '<div style="text-align:center; padding:20px; color:var(--cp-neon);">Carregando grupos...</div>';

    const groupsJson = await runInWa(async () => {
        if (!window.FMARK || !window.FMARK.infoAllGroupList) return "[]";
        return await window.FMARK.infoAllGroupList();
    });

    const groups = JSON.parse(groupsJson || "[]");
    container.innerHTML = '';
    state.selectedGroupTransferSource = null;

    if (groups.error || groups.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">Nenhum grupo encontrado.</div>';
        return;
    }

    groups.forEach(group => {
        const item = document.createElement('div');
        item.className = 'contact-item';
        item.dataset.id = group.id;

        const initial = group.subject ? group.subject.charAt(0).toUpperCase() : 'G';
        
        item.innerHTML = `
    <div class="contact-avatar">${initial}</div>
    <div class="contact-info" style="flex: 1; min-width: 0;">
        <span class="contact-name" style="display: flex; justify-content: space-between; align-items: center;">
            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${group.subject || 'Grupo sem nome'}</span>
            ${typeof adminBadge !== 'undefined' ? adminBadge : ''}
        </span>
        <span class="contact-number">${group.participantsCount} participantes</span>
    </div>
`;

        item.addEventListener('click', () => {
            document.querySelectorAll('#group-list-transfer-source-container .contact-item').forEach(el => el.classList.remove('selected'));
            item.classList.add('selected');
            state.selectedGroupTransferSource = group.id;
        });

        container.appendChild(item);
    });
}

async function loadGroupsForTransferTarget() {
    const container = document.getElementById('group-list-transfer-target-container');
    container.innerHTML = '<div style="text-align:center; padding:20px; color:var(--cp-neon);">Carregando grupos...</div>';

    const groupsJson = await runInWa(async () => {
        if (!window.FMARK || !window.FMARK.infoAllGroupList) return "[]";
        return await window.FMARK.infoAllGroupList();
    });

    const groups = JSON.parse(groupsJson || "[]");
    container.innerHTML = '';
    state.selectedGroupTransferTarget = null;

    if (groups.error || groups.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">Nenhum grupo encontrado.</div>';
        return;
    }

    groups.forEach(group => {
        const item = document.createElement('div');
        item.className = 'contact-item';
        item.dataset.id = group.id;

        const initial = group.subject ? group.subject.charAt(0).toUpperCase() : 'G';
        const adminBadge = group.isAdmin
            ? '<span style="color:#00ff00; font-size:10px; border:1px solid rgba(0,255,0,0.3); background:rgba(0,255,0,0.1); padding:2px 4px; border-radius:4px; margin-left:8px;">ADMIN</span>'
            : '<span style="color:#ff5555; font-size:10px; border:1px solid rgba(255,85,85,0.3); background:rgba(255,85,85,0.1); padding:2px 4px; border-radius:4px; margin-left:8px;">MEMBRO</span>';

        item.innerHTML = `
    <div class="contact-avatar">${initial}</div>
    <div class="contact-info" style="flex: 1; min-width: 0;">
        <span class="contact-name" style="display: flex; justify-content: space-between; align-items: center;">
            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${group.subject || 'Grupo sem nome'}</span>
            ${typeof adminBadge !== 'undefined' ? adminBadge : ''}
        </span>
        <span class="contact-number">${group.participantsCount} participantes</span>
    </div>
`;

        item.addEventListener('click', () => {
            document.querySelectorAll('#group-list-transfer-target-container .contact-item').forEach(el => el.classList.remove('selected'));
            item.classList.add('selected');
            state.selectedGroupTransferTarget = group.id;
        });

        container.appendChild(item);
    });
}

async function handleTransferMembersSubmit() {
    if (!state.selectedGroupTransferSource || !state.selectedGroupTransferTarget) {
        alert("Selecione os grupos de origem e destino!");
        return;
    }

    const btn = document.getElementById('btn-finish-transfer-members');
    const originalText = btn.innerText;
    btn.innerText = 'Transferindo...';

    const delayInput = document.getElementById('transfer-delay');
    const delaySec = delayInput ? parseInt(delayInput.value) || 5 : 5;

    const result = await runInWa(async (sourceGroupId, targetGroupId, delaySec) => {
        try {
            if (!window.FMARK) return { error: "API FMARK indisponível" };

            const metadata = await window.FMARK.getGroupMetadata(sourceGroupId);
            const models = metadata?.participants?.getModelsArray ? metadata.participants.getModelsArray() : (metadata?.participants?._models || []);
            
            const membersToTransfer = [];
            const me = window.FMARK.getMyUserId();
            const meUser = me ? me.user : "";

            for (const p of models) {
                const isMe = p.id.user === meUser || (p.contact?.id?.user === meUser);
                if (isMe) continue;

                let validId = p.id._serialized;
                if (p.id.server === 'lid') {
                    try {
                        const pn = window.Store?.WeblidPnCache?.getPhoneNumber(p.id) || window.Store?.ApiContact?.getPhoneNumber(p.id);
                        if (pn) validId = pn._serialized || `${pn.user}@c.us`;
                    } catch (e) {}
                }
                
                membersToTransfer.push(validId);
            }

            if (membersToTransfer.length === 0) return { error: "O grupo de origem não possui membros válidos para transferir." };

            const addResult = await window.FMARK.addParticipantsBatch(targetGroupId, membersToTransfer);
            return { success: true, result: addResult };

        } catch (e) {
            return { error: "Erro interno: " + e.message };
        }
    }, [state.selectedGroupTransferSource, state.selectedGroupTransferTarget]);

    btn.innerText = originalText;

    if (result && result.success) {
        let success = 0, fail = 0;
        Object.values(result.result).forEach(r => (r.code === 200 || r.code === 403) ? success++ : fail++);
        alert(`Transferência concluída!\nAdicionados/Convites: ${success}\nFalhas: ${fail}`);
        document.getElementById('close-flow-transfer').click();
    } else {
        alert("Falha na transferência: " + (result?.error || "Verifique suas permissões no grupo de destino."));
    }
}

async function loadGroupsForConfig() {
    const container = document.getElementById('group-list-config-container');
    container.innerHTML = '<div style="text-align:center; padding:20px; color:var(--cp-neon);">Carregando grupos...</div>';

    const groupsJson = await runInWa(async () => {
        if (!window.FMARK || !window.FMARK.infoAllGroupList) return "[]";
        return await window.FMARK.infoAllGroupList();
    });

    const groups = JSON.parse(groupsJson || "[]");
    container.innerHTML = '';
    state.selectedGroupToConfig = null;

    if (groups.error || groups.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">Nenhum grupo encontrado.</div>';
        return;
    }

    groups.forEach(group => {
        if (!group.isAdmin) return;

        const item = document.createElement('div');
        item.className = 'contact-item';
        item.dataset.id = group.id;

        const initial = group.subject ? group.subject.charAt(0).toUpperCase() : 'G';

       item.innerHTML = `
    <div class="contact-avatar">${initial}</div>
    <div class="contact-info" style="flex: 1; min-width: 0;">
        <span class="contact-name" style="display: flex; justify-content: space-between; align-items: center;">
            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${group.subject || 'Grupo sem nome'}</span>
            ${typeof adminBadge !== 'undefined' ? adminBadge : ''}
        </span>
        <span class="contact-number">${group.participantsCount} participantes</span>
    </div>
`;

        item.addEventListener('click', () => {
            document.querySelectorAll('#group-list-config-container .contact-item').forEach(el => el.classList.remove('selected'));
            item.classList.add('selected');
            state.selectedGroupToConfig = group.id;
        });

        container.appendChild(item);
    });
}

async function handleConfigGroupSubmit() {
    if (!state.selectedGroupToConfig) {
        alert("Selecione um grupo primeiro!");
        return;
    }

    const btnAdmins = document.getElementById('btn-config-admins');
    const isAdminsOnly = btnAdmins ? btnAdmins.classList.contains('selected') : true;

    const btn = document.getElementById('btn-finish-config-group');
    const originalText = btn.innerText;
    btn.innerText = 'Salvando...';

    const result = await runInWa(async (groupId, adminsOnly) => {
        try {
            if (window.Store && window.Store.setGroupOptions && typeof window.Store.setGroupOptions.setGroupProperty === 'function') {
                const wid = window.Store.WidFactory.createWid(groupId);
                await window.Store.setGroupOptions.setGroupProperty(wid, 'announcement', adminsOnly ? 1 : 0);
                return true;
            }
            if (window.FMARK && typeof window.FMARK.setGroupSettings === 'function') {
                return await window.FMARK.setGroupSettings(groupId, 'announcement', adminsOnly ? 1 : 0);
            }
            return false;
        } catch (e) {
            return false;
        }
    }, [state.selectedGroupToConfig, isAdminsOnly]);

    btn.innerText = originalText;

    if (result) {
        alert("Configuração do grupo atualizada com sucesso!");
        document.getElementById('close-flow-config').click();
    } else {
        alert("Falha ao atualizar a configuração. Verifique suas permissões.");
    }
}

async function initMonitoring() {
    await runInWa(() => {
        window.WA_GROUP_STATS = window.WA_GROUP_STATS || { total: 0, groups: {}, users: {} };
        
        if (!window.WA_MONITOR_ACTIVE) {
            window.WA_MONITOR_ACTIVE = true;
            if (window.Store && window.Store.Msg) {
                window.Store.Msg.on('add', (msg) => {
                    if (!msg.isNewMsg) return;
                    const remote = msg.id.remote ? (msg.id.remote._serialized || msg.id.remote) : '';
                    
                    if (remote.endsWith('@g.us')) {
                        window.WA_GROUP_STATS.groups[remote] = (window.WA_GROUP_STATS.groups[remote] || 0) + 1;
                        window.WA_GROUP_STATS.total++;

                        if (!window.WA_GROUP_STATS.users[remote]) window.WA_GROUP_STATS.users[remote] = {};
                        const author = msg.author ? (msg.author._serialized || msg.author) : 'Sistema';
                        window.WA_GROUP_STATS.users[remote][author] = (window.WA_GROUP_STATS.users[remote][author] || 0) + 1;
                    }
                });
            }
        }
    });
}

async function getTopActiveGroups() {
    return await runInWa(() => {
        if (!window.WA_GROUP_STATS) return { top: [], total: 0 };
        const stats = window.WA_GROUP_STATS.groups;
        const usersStats = window.WA_GROUP_STATS.users || {};
        const total = window.WA_GROUP_STATS.total;
        let arr = [];
        
        for (const gid in stats) {
            let name = gid;
            try {
                const wid = window.Store.WidFactory.createWid(gid);
                const chat = window.Store.Chat.get(wid);
                if (chat && chat.name) name = chat.name;
                else if (chat && chat.formattedTitle) name = chat.formattedTitle;
            } catch(e) {}

            let topUsers = [];
            if (usersStats[gid]) {
                let uArr = [];
                for (const uid in usersStats[gid]) {
                    let uName = uid.split('@')[0];
                    try {
                        const uWid = window.Store.WidFactory.createWid(uid);
                        const contact = window.Store.Contact.get(uWid);
                        if (contact && (contact.name || contact.pushname)) {
                            uName = contact.name || contact.pushname;
                        }
                    } catch(e) {}
                    uArr.push({ name: uName, count: usersStats[gid][uid] });
                }
                uArr.sort((a, b) => b.count - a.count);
                topUsers = uArr.slice(0, 3);
            }
            
            arr.push({ id: gid, name: name, count: stats[gid], topUsers: topUsers });
        }
        
        arr.sort((a, b) => b.count - a.count);
        return { top: arr.slice(0, 8), total: total };
    });
}

async function loadGroupsLinksForMonitoring() {
    const container = document.getElementById('monitoring-groups-list');
   
    const groupsJson = await runInWa(async () => {
        if (!window.FMARK || !window.FMARK.infoAllGroupList) return "[]";
        return await window.FMARK.infoAllGroupList();
    });

    const groups = JSON.parse(groupsJson || "[]");
    container.innerHTML = '';

    const adminGroups = groups.filter(g => g.isAdmin);

    if (adminGroups.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">Nenhum grupo administrado encontrado.</div>';
        return;
    }

    state.adminGroupsCache = adminGroups;

    // PASSO 1: Monta toda a interface visual com o status "Carregando link..."
    for (const group of adminGroups) {
        const item = document.createElement('div');
        item.className = 'contact-item';
        item.dataset.id = group.id;
        item.style.cursor = 'default';
        item.style.justifyContent = 'space-between';

        const initial = group.subject ? group.subject.charAt(0).toUpperCase() : 'G';

        item.innerHTML = `
            <div style="display: flex; align-items: center; flex: 1; min-width: 0;">
                <div class="contact-avatar">${initial}</div>
                <div class="contact-info" style="flex: 1;">
                    <span class="contact-name">${group.subject || 'Grupo sem nome'}</span>
                    <span class="contact-number">${group.participantsCount} participantes</span>
                </div>
            </div>
            <div style="display: flex; gap: 10px; align-items: center;">
                <span class="link-display" style="font-size: 11px; color: var(--cp-text-muted); max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">Carregando link...</span>
                <button class="card-btn btn-copy-link" style="width: auto; padding: 8px 15px; display: none;">COPIAR</button>
            </div>
        `;

        container.appendChild(item);
    }

    // PASSO 2: Busca os links sequencialmente (com await) para evitar bloqueio por Rate Limit do WhatsApp
    for (const group of adminGroups) {
        const item = container.querySelector(`.contact-item[data-id="${group.id}"]`);
        if (!item) continue;

        const link = await runInWa(async (groupId) => {
            try {
                // 1. Tenta usar a FMARK original primeiro
                if (window.FMARK && typeof window.FMARK.getGroupInviteLink === 'function') {
                    let fmarkLink = await window.FMARK.getGroupInviteLink(groupId);
                    if (fmarkLink && typeof fmarkLink === 'string' && fmarkLink.includes('chat.whatsapp.com')) {
                        return fmarkLink;
                    }
                }

                // 2. FMARK falhou/deu indisponível pelo lazy load? Forçamos a requisição bruta no servidor do WA
                const wid = window.Store.WidFactory.createWid(groupId);
                
                const forceFetchCode = async (w) => {
                    if (window.Store.GroupInviteAction && typeof window.Store.GroupInviteAction.queryGroupInviteCode === 'function') {
                        return await window.Store.GroupInviteAction.queryGroupInviteCode(w);
                    }
                    if (window.Store.GroupInvite && typeof window.Store.GroupInvite.sendQueryGroupInviteCode === 'function') {
                        return await window.Store.GroupInvite.sendQueryGroupInviteCode(w);
                    }
                    if (window.Store.Invite && typeof window.Store.Invite.queryGroupInviteCode === 'function') {
                        return await window.Store.Invite.queryGroupInviteCode(w);
                    }
                    return null;
                };

                let serverCode = await forceFetchCode(wid);
                if (serverCode) {
                    return 'https://chat.whatsapp.com/' + serverCode;
                }

                // 3. Última alternativa: tenta ler do cache caso a requisição acima o tenha atualizado silenciosamente
                const groupMeta = window.Store.GroupMetadata.get(wid);
                if (groupMeta && groupMeta.inviteCode) {
                    return 'https://chat.whatsapp.com/' + groupMeta.inviteCode;
                }

                return null;
            } catch (e) {
                return null;
            }
        }, [group.id]);

        const linkDisplay = item.querySelector('.link-display');
        const copyBtn = item.querySelector('.btn-copy-link');
       
        if (link) {
            linkDisplay.innerText = link;
            item.dataset.link = link;
            copyBtn.style.display = 'block'; // Mostra o botão copiar
           
            copyBtn.addEventListener('click', () => {
                navigator.clipboard.writeText(link);
                const originalText = copyBtn.innerText;
                copyBtn.innerText = 'COPIADO!';
                copyBtn.style.backgroundColor = 'var(--cp-neon)';
                copyBtn.style.color = '#000';
                setTimeout(() => {
                    copyBtn.innerText = originalText;
                    copyBtn.style.backgroundColor = 'transparent';
                    copyBtn.style.color = 'var(--cp-neon)';
                }, 2000);
            });
        } else {
            linkDisplay.innerText = 'Link indisponível';
            copyBtn.style.display = 'none';
        }

        // Aguarda 600 milissegundos antes de consultar o próximo grupo
        await new Promise(resolve => setTimeout(resolve, 600));
    }
}

async function handleResetAllLinks() {
    if (!state.adminGroupsCache || state.adminGroupsCache.length === 0) return;

    const btn = document.getElementById('btn-reset-all-links');
    btn.disabled = true;
    
    let successCount = 0;
    const total = state.adminGroupsCache.length;

    for (let i = 0; i < total; i++) {
        const group = state.adminGroupsCache[i];
        btn.innerText = `Atualizando (${i + 1}/${total})...`;

        await runInWa(async (groupId) => {
            try {
                const wid = window.Store.WidFactory.createWid(groupId);
                let revoked = false;

                // Tenta revogar direto pela API interna para evitar falha da FMARK em Cold Start
                if (window.Store.GroupInviteAction && typeof window.Store.GroupInviteAction.revokeGroupInvite === 'function') {
                    await window.Store.GroupInviteAction.revokeGroupInvite(wid);
                    revoked = true;
                } else if (window.Store.GroupInvite && typeof window.Store.GroupInvite.sendRevokeGroupInviteCode === 'function') {
                    await window.Store.GroupInvite.sendRevokeGroupInviteCode(wid);
                    revoked = true;
                } else if (window.FMARK && typeof window.FMARK.revokeGroupInviteLink === 'function') {
                    await window.FMARK.revokeGroupInviteLink(groupId);
                    revoked = true;
                }

                // Se revogou com sucesso, força a busca do novo link para já guardá-lo em memória
                if (revoked) {
                    if (window.Store.GroupInviteAction && typeof window.Store.GroupInviteAction.queryGroupInviteCode === 'function') {
                        await window.Store.GroupInviteAction.queryGroupInviteCode(wid).catch(()=>{});
                    } else if (window.Store.GroupInvite && typeof window.Store.GroupInvite.sendQueryGroupInviteCode === 'function') {
                        await window.Store.GroupInvite.sendQueryGroupInviteCode(wid).catch(()=>{});
                    }
                }
                return true;
            } catch (e) {
                return false;
            }
        }, [group.id]);

        successCount++;
        await new Promise(resolve => setTimeout(resolve, 2000)); 
    }

    btn.innerText = 'Recarregando lista...';
    await loadGroupsLinksForMonitoring();
    
    btn.innerText = 'Atualizar Todos os Links';
    btn.disabled = false;
    alert(`Processo concluído. ${successCount} links atualizados.`);
}

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('btn-create-group')?.addEventListener('click', loadContacts);
    setupImageUpload();
    setupEditImageUpload();
   
    document.getElementById('btn-finish-group')?.addEventListener('click', handleCreateGroup);
    document.getElementById('btn-add-members')?.addEventListener('click', loadGroupsForAddMembers);
    document.getElementById('btn-next-node-add')?.addEventListener('click', loadContactsForAddMembers);
    document.getElementById('btn-finish-add-members')?.addEventListener('click', handleAddMembersSubmit);
    document.getElementById('btn-remove-members-card')?.addEventListener('click', () => {
        document.getElementById('flow-overlay-remove-members').classList.add('active');
        document.getElementById('node-remove-1').classList.add('active');
        loadGroupsForRemoveMembers();
    });

    document.getElementById('close-flow-remove')?.addEventListener('click', () => {
        document.getElementById('flow-overlay-remove-members').classList.remove('active');
        document.getElementById('node-remove-1').classList.remove('active');
        document.getElementById('node-remove-2').classList.remove('active');
        document.getElementById('node-connector-remove').classList.remove('active');
        state.selectedGroupToRemove = null;
        state.selectedMembersToRemove = [];
    });

    document.getElementById('btn-next-node-remove')?.addEventListener('click', () => {
        if (!state.selectedGroupToRemove) {
            alert("Selecione um grupo primeiro!");
            return;
        }
        document.getElementById('node-connector-remove').classList.add('active');
        setTimeout(() => {
            document.getElementById('node-remove-2').classList.add('active');
            loadMembersForRemoval();
        }, 300);
    });

    document.getElementById('btn-finish-remove-members')?.addEventListener('click', handleRemoveMembersSubmit);
    document.getElementById('btn-promote-members-card')?.addEventListener('click', () => {
        document.getElementById('flow-overlay-promote-members').classList.add('active');
        document.getElementById('node-promote-1').classList.add('active');
        loadGroupsForPromoteMembers();
    });
    document.getElementById('btn-next-node-promote')?.addEventListener('click', () => {
        if (!state.selectedGroupToPromote) { alert("Selecione um grupo!"); return; }
        document.getElementById('node-connector-promote').classList.add('active');
        setTimeout(() => {
            document.getElementById('node-promote-2').classList.add('active');
            loadMembersForPromotion();
        }, 300);
    });

    document.getElementById('btn-leave-group-card')?.addEventListener('click', () => {
        loadGroupsForLeave();
    });

    document.getElementById('btn-next-node-leave')?.addEventListener('click', () => {
        if (state.selectedGroupsToLeave.length === 0) {
            alert("Selecione pelo menos um grupo para sair!");
            return;
        }
        document.getElementById('node-connector-leave').classList.add('active');
        setTimeout(() => {
            document.getElementById('node-leave-2').classList.add('active');
            loadSelectedGroupsForLeaveConfirm();
        }, 300);
    });

    document.getElementById('btn-finish-leave-group')?.addEventListener('click', handleLeaveGroupsSubmit);

    document.getElementById('btn-finish-promote-members')?.addEventListener('click', handlePromoteMembersSubmit);
    document.getElementById('close-flow-promote')?.addEventListener('click', () => {
        document.getElementById('flow-overlay-promote-members').classList.remove('active');
        document.querySelectorAll('#flow-overlay-promote-members .flow-node').forEach(n => n.classList.remove('active'));
        document.getElementById('node-connector-promote').classList.remove('active');
    });

    document.getElementById('btn-demote-members-card')?.addEventListener('click', () => {
        document.getElementById('flow-overlay-demote-members').classList.add('active');
        document.getElementById('node-demote-1').classList.add('active');
        loadGroupsForDemoteMembers();
    });
    document.getElementById('btn-next-node-demote')?.addEventListener('click', () => {
        if (!state.selectedGroupToDemote) { alert("Selecione um grupo!"); return; }
        document.getElementById('node-connector-demote').classList.add('active');
        setTimeout(() => {
            document.getElementById('node-demote-2').classList.add('active');
            loadMembersForDemotion();
        }, 300);
    });
    document.getElementById('btn-finish-demote-members')?.addEventListener('click', handleDemoteMembersSubmit);
    document.getElementById('close-flow-demote')?.addEventListener('click', () => {
        document.getElementById('flow-overlay-demote-members').classList.remove('active');
        document.querySelectorAll('#flow-overlay-demote-members .flow-node').forEach(n => n.classList.remove('active'));
        document.getElementById('node-connector-demote').classList.remove('active');
    });
    document.getElementById('btn-edit-name-card')?.addEventListener('click', loadGroupsForEditName);
    document.getElementById('btn-finish-edit-name')?.addEventListener('click', handleEditNameSubmit);

    document.getElementById('btn-edit-image-card')?.addEventListener('click', loadGroupsForEditImage);
    document.getElementById('btn-finish-edit-image')?.addEventListener('click', handleEditImageSubmit);


    document.getElementById('btn-extract-contacts-card')?.addEventListener('click', loadGroupsForExtract);
    
    document.getElementById('btn-extract-group-csv')?.addEventListener('click', () => handleExtractGroup('csv'));
    document.getElementById('btn-extract-group-txt')?.addEventListener('click', () => handleExtractGroup('txt'));
    
    document.getElementById('btn-extract-all-csv')?.addEventListener('click', () => handleExtractAll('csv'));
    document.getElementById('btn-extract-all-txt')?.addEventListener('click', () => handleExtractAll('txt'));

    document.getElementById('btn-edit-desc-card')?.addEventListener('click', loadGroupsForEditDesc);
    document.getElementById('btn-finish-edit-desc')?.addEventListener('click', handleEditDescSubmit);

    // --- EVENTOS: TRANSFERIR MEMBROS ---
    document.getElementById('btn-transfer-members-card')?.addEventListener('click', () => {
        document.getElementById('flow-overlay-transfer-members').classList.add('active');
        setTimeout(() => {
            document.getElementById('node-transfer-1').classList.add('active');
            loadGroupsForTransferSource();
        }, 100);
    });

    document.getElementById('close-flow-transfer')?.addEventListener('click', () => {
        document.getElementById('flow-overlay-transfer-members').classList.remove('active');
        document.getElementById('node-transfer-1').classList.remove('active');
        document.getElementById('node-transfer-2').classList.remove('active');
        document.getElementById('node-transfer-3').classList.remove('active');
        document.getElementById('node-connector-transfer-1').classList.remove('active');
        document.getElementById('node-connector-transfer-2').classList.remove('active');
        
        const searchSource = document.getElementById('group-search-transfer-source');
        const searchTarget = document.getElementById('group-search-transfer-target');
        if (searchSource) searchSource.value = '';
        if (searchTarget) searchTarget.value = '';
        
        const selectedItems = document.querySelectorAll('#flow-overlay-transfer-members .contact-item.selected');
        selectedItems.forEach(item => item.classList.remove('selected'));
        
        if (typeof state !== 'undefined') {
            state.selectedGroupTransferSource = null;
            state.selectedGroupTransferTarget = null;
        }
    });

    document.getElementById('btn-next-node-transfer-1')?.addEventListener('click', () => {
        if (!state.selectedGroupTransferSource) {
            alert("Selecione um grupo de origem primeiro!");
            return;
        }
        document.getElementById('node-connector-transfer-1').classList.add('active');
        setTimeout(() => {
            document.getElementById('node-transfer-2').classList.add('active');
            loadGroupsForTransferTarget();
        }, 300);
    });

    document.getElementById('btn-next-node-transfer-2')?.addEventListener('click', () => {
        if (!state.selectedGroupTransferTarget) {
            alert("Selecione um grupo de destino primeiro!");
            return;
        }
        if (state.selectedGroupTransferSource === state.selectedGroupTransferTarget) {
            alert("O grupo de origem e destino não podem ser os mesmos!");
            return;
        }
        document.getElementById('node-connector-transfer-2').classList.add('active');
        setTimeout(() => {
            document.getElementById('node-transfer-3').classList.add('active');
        }, 300);
    });

    document.getElementById('btn-finish-transfer-members')?.addEventListener('click', handleTransferMembersSubmit);

    document.getElementById('btn-config-group-card')?.addEventListener('click', () => {
        const flowOverlay = document.getElementById('flow-overlay-config-group');
        const node1 = document.getElementById('node-config-1');
        
        if (flowOverlay && node1) {
            flowOverlay.classList.add('active');
            setTimeout(() => {
                node1.classList.add('active');
                loadGroupsForConfig();
            }, 100);
        }
    });

    document.getElementById('btn-finish-config-group')?.addEventListener('click', handleConfigGroupSubmit);
    initMonitoring();
});
// --------------------------------- //
state.botEvents = [];

window.WA_ACTION_LOGS = window.WA_ACTION_LOGS || [];

// Funções de Persistência no Banco de Dados
async function saveBotEvents() {
    return new Promise(resolve => {
        chrome.storage.local.set({ wagroup_bot_events: state.botEvents }, resolve);
    });
}

async function loadBotEvents() {
    return new Promise(resolve => {
        chrome.storage.local.get(['wagroup_bot_events'], (result) => {
            state.botEvents = result.wagroup_bot_events || [];
            resolve(state.botEvents);
        });
    });
}

window.addBotEvent = async function(eventData) {
    state.botEvents.push(eventData);
    await saveBotEvents();
    await syncBotEvents();
};

window.removeBotEvent = async function(eventId) {
    state.botEvents = state.botEvents.filter(e => e.id !== eventId);
    await saveBotEvents();
    await syncBotEvents();
};
// --------------------------------- //

window.addBotLog = function(type, text, groupId) {
    let groupName = groupId;
    try {
        const wid = window.Store.WidFactory.createWid(groupId);
        const chat = window.Store.Chat.get(wid);
        if (chat && chat.name) groupName = chat.name;
        else if (chat && chat.formattedTitle) groupName = chat.formattedTitle;
    } catch(e) {}

    window.WA_ACTION_LOGS.push({
        time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
        type: type,
        text: text,
        group: groupName
    });

    if (window.WA_ACTION_LOGS.length > 100) {
        window.WA_ACTION_LOGS.shift();
    }
};

async function syncBotEvents() {
    await runInWa((events, allowedGroups) => {
        window.WA_BOT_EVENTS = events;
        window.WA_BOT_ALLOWED_GROUPS = allowedGroups || [];
        window.WA_BOT_COOLDOWN = window.WA_BOT_COOLDOWN || {};
        window.WA_ACTION_LOGS = window.WA_ACTION_LOGS || [];
        if (window.WA_BOT_ACTIVE === undefined) window.WA_BOT_ACTIVE = true;

        if (!window.WA_TOGGLE_BRIDGE_ACTIVE) {
            window.WA_TOGGLE_BRIDGE_ACTIVE = true;
            window.addEventListener('WA_TOGGLE_BOT', () => {
                window.WA_BOT_ACTIVE = !window.WA_BOT_ACTIVE;
                window.addBotLog('system', `Chatbot foi ${window.WA_BOT_ACTIVE ? 'LIGADO' : 'DESLIGADO'}`, 'Sistema');
                window.dispatchEvent(new CustomEvent('WA_BOT_STATE_CHANGED', { detail: window.WA_BOT_ACTIVE }));
            });
        }

        if (!window.WA_LOG_BRIDGE_ACTIVE) {
            window.WA_LOG_BRIDGE_ACTIVE = true;
            window.addEventListener('WA_REQUEST_LOGS', () => {
                window.dispatchEvent(new CustomEvent('WA_LOG_FETCHED', {
                    detail: JSON.stringify(window.WA_ACTION_LOGS || [])
                }));
            });
        }

        if (!window.addBotLog) {
            window.addBotLog = function(type, text, groupId) {
                let groupName = groupId;
                try {
                    const wid = window.Store.WidFactory.createWid(groupId);
                    const chat = window.Store.Chat.get(wid);
                    if (chat && chat.name) groupName = chat.name;
                    else if (chat && chat.formattedTitle) groupName = chat.formattedTitle;
                } catch(e) {}

                window.WA_ACTION_LOGS.push({
                    time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
                    type: type,
                    text: text,
                    group: groupName
                });

                if (window.WA_ACTION_LOGS.length > 100) {
                    window.WA_ACTION_LOGS.shift();
                }
            };
        }

        const resolveNumber = (widParam) => {
            if (!widParam) return "Desconhecido";
            try {
                let widObj = typeof widParam === 'string' ? window.Store.WidFactory.createWid(widParam) : widParam;
                if (widObj && widObj.server === 'lid') {
                    let pn = window.Store.WeblidPnCache?.getPhoneNumber(widObj) || window.Store.ApiContact?.getPhoneNumber(widObj);
                    if (pn) return pn.user;
                }
                return widObj.user || (typeof widParam === 'string' ? widParam.split('@')[0] : "Desconhecido");
            } catch(e) {
                return typeof widParam === 'string' ? widParam.split('@')[0] : "Desconhecido";
            }
        };

        if (!window.WA_BOT_LISTENER_ACTIVE) {
            window.WA_BOT_LISTENER_ACTIVE = true;
            window.WA_PROCESSED_MSGS = new Set(); // Rastreador de mensagens processadas
            
            if (window.Store && window.Store.Msg) {
                window.Store.Msg.on('add', async (msg) => {
                    if (window.WA_BOT_ACTIVE === false) return;
                    
                    try {
                        if (!msg.isNewMsg || !msg.id || !msg.id.remote) return;
                        
                        // Bloqueio Anti-Duplicação
                        const msgIdStr = msg.id._serialized || msg.id;
                        if (window.WA_PROCESSED_MSGS.has(msgIdStr)) return;
                        window.WA_PROCESSED_MSGS.add(msgIdStr);
                        
                        // Limpa o rastreador para não estourar a memória ram
                        if (window.WA_PROCESSED_MSGS.size > 1000) {
                            const iterator = window.WA_PROCESSED_MSGS.values();
                            window.WA_PROCESSED_MSGS.delete(iterator.next().value);
                        }
                        const groupId = typeof msg.id.remote === 'object' ? msg.id.remote._serialized : msg.id.remote;
                        
                        if (window.WA_BOT_ALLOWED_GROUPS && window.WA_BOT_ALLOWED_GROUPS.length > 0) {
                            if (!window.WA_BOT_ALLOWED_GROUPS.includes(String(groupId))) {
                                return; 
                            }
                        }
                        
                        const isJoinEvent = msg.type === 'gp2' && (msg.subtype === 'add' || msg.subtype === 'invite');
                        const isLeaveEvent = msg.type === 'gp2' && (msg.subtype === 'leave' || msg.subtype === 'remove');
                        const isTextMessage = msg.type === 'chat' || msg.type === 'image' || msg.type === 'video';
                        
                        const now = Date.now();
                        
                        if (isJoinEvent || isLeaveEvent) {
                            let targetUsers = [];
                            if (msg.recipients && msg.recipients.length > 0) {
                                targetUsers = msg.recipients.map(r => resolveNumber(r));
                            } else if (msg.author) {
                                targetUsers = [resolveNumber(msg.author)];
                            }
                            
                            const currentAction = isJoinEvent ? 'joined' : 'left';
                            const actionText = isJoinEvent ? 'Membro entrou' : 'Membro saiu/removido';
                            
                            window.addBotLog(currentAction, `${actionText} (${targetUsers.join(', ')})`, groupId);
                            
                            let targetIds = [];
                            if (msg.recipients && msg.recipients.length > 0) {
                                targetIds = msg.recipients.map(r => r._serialized || r);
                            } else if (msg.author) {
                                targetIds = [msg.author._serialized || msg.author];
                            }

                            if (window.WA_BOT_EVENTS && window.WA_BOT_EVENTS.length > 0) {
                                for (const event of window.WA_BOT_EVENTS) {
                                    if (event.eventType === currentAction) {
                                        if (event.isPrivate) {
                                            for (const userWid of targetIds) {
                                                if (event.isText) {
                                                    await window.FMARK.sendTextMessage(userWid, event.content);
                                                } else if (event.mediaBase64) {
                                                    await window.FMARK.sendFileMessage(userWid, event.mediaBase64, { type: 'auto-detect', caption: event.content });
                                                }
                                            }
                                        } else {
                                            const cooldownKey = `${groupId}_${event.id}`;
                                            if (window.WA_BOT_COOLDOWN[cooldownKey] && (now - window.WA_BOT_COOLDOWN[cooldownKey] < 5000)) continue;
                                            window.WA_BOT_COOLDOWN[cooldownKey] = now;
                                            
                                            if (event.isText) {
                                                await window.FMARK.sendTextMessage(groupId, event.content);
                                            } else if (event.mediaBase64) {
                                                await window.FMARK.sendFileMessage(groupId, event.mediaBase64, { type: 'auto-detect', caption: event.content });
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (isTextMessage && !msg.id.fromMe) {
                            if (!window.WA_BOT_EVENTS || window.WA_BOT_EVENTS.length === 0) return;
                            
                            const body = msg.body ? msg.body.toLowerCase() : (msg.caption ? msg.caption.toLowerCase() : '');
                            const authorId = msg.author ? (msg.author._serialized || msg.author) : groupId;
                            const authorDisplayNumber = resolveNumber(msg.author || msg.id.remote);
                            
                            const urlRegex = /(https?:\/\/[^\s]+)|(www\.[^\s]+)|([a-zA-Z0-9-]+\.[a-zA-Z]{2,})/i;
                            const hasLink = body && urlRegex.test(body);
                            const isGif = msg.type === 'video' && msg.isGif === true;

                            for (const event of window.WA_BOT_EVENTS) {
                                if (event.eventType === 'antispam') {
                                    if ((event.blockLinks && hasLink) || (event.blockGifs && isGif)) {
                                        window.addBotLog('trigger', `Anti-Spam ativado contra ${authorDisplayNumber}`, groupId);
                                        
                                        try {
                                            if (window.FMARK && typeof window.FMARK.deleteMessage === 'function') {
                                                window.FMARK.deleteMessage(groupId, [msg.id._serialized || msg.id], true);
                                                window.addBotLog('action', `Spam apagado`, groupId);
                                            }
                                        } catch(e) {}

                                        if (event.banUser) {
                                            try {
                                                if (window.FMARK && typeof window.FMARK.removeParticipant === 'function') {
                                                    await window.FMARK.removeParticipant(groupId, [authorId]);
                                                    window.addBotLog('action', `Spammer banido`, groupId);
                                                }
                                            } catch(e) {}
                                        }
                                        return; 
                                    }
                                }
                            }

                            if (!body) return;

                            for (const event of window.WA_BOT_EVENTS) {
                                if (event.eventType === 'response') {
                                    if (body.includes(event.keyword.toLowerCase())) {
                                        window.addBotLog('trigger', `Gatilho: "${event.keyword}" disparado por ${authorDisplayNumber}`, groupId);

                                        if (event.deleteMsg) {
                                            try {
                                                if (window.FMARK && typeof window.FMARK.deleteMessage === 'function') {
                                                    window.FMARK.deleteMessage(groupId, [msg.id._serialized || msg.id], true);
                                                    window.addBotLog('action', `Mensagem apagada com sucesso`, groupId);
                                                }
                                            } catch(e) {}
                                        }

                                        if (event.removeUser) {
                                            try {
                                                if (window.FMARK && typeof window.FMARK.removeParticipant === 'function') {
                                                    await window.FMARK.removeParticipant(groupId, [authorId]);
                                                    window.addBotLog('action', `Membro removido: ${authorDisplayNumber}`, groupId);
                                                }
                                            } catch(e) {}
                                        }

                                        const hasContent = (event.isText && event.content) || (!event.isText && event.mediaBase64);
                                        
                                        if (hasContent) {
                                            const targetId = event.isPrivate ? authorId : groupId;
                                            const cooldownKey = `${targetId}_${event.id}`;
                                            
                                            if (!event.isPrivate) {
                                                if (window.WA_BOT_COOLDOWN[cooldownKey] && (now - window.WA_BOT_COOLDOWN[cooldownKey] < 3000)) continue;
                                                window.WA_BOT_COOLDOWN[cooldownKey] = now;
                                            }

                                            if (event.isText) {
                                                await window.FMARK.sendTextMessage(targetId, event.content);
                                                window.addBotLog('response', `Bot respondeu com texto`, groupId);
                                            } else if (event.mediaBase64) {
                                                await window.FMARK.sendFileMessage(targetId, event.mediaBase64, { type: 'auto-detect', caption: event.content });
                                                window.addBotLog('response', `Bot respondeu com mídia`, groupId);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (err) {}
                });
            }
        }
    }, [state.botEvents, state.botAllowedGroups]);
}

// --------------------------------- //
// --- Funções de Gestão de Comunidades --- //

async function loadCommunitiesForSend() {
    const container = document.getElementById('com-list-send-container');
    if (!container) return;
    
    container.innerHTML = '<div style="text-align:center; padding:20px; color:var(--cp-neon);">Carregando comunidades...</div>';

    const groupsJson = await runInWa(async () => {
        if (!window.FMARK || !window.FMARK.infoAllGroupList) return "[]";
        return await window.FMARK.infoAllGroupList();
    });

    const groups = JSON.parse(groupsJson || "[]");
    container.innerHTML = '';
    state.selectedCommunityForSend = null;

    const communities = groups.filter(g => g && g.isCommunity);

    if (communities.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">Nenhuma comunidade encontrada.</div>';
        return;
    }

    communities.forEach(community => {
        const item = document.createElement('div');
        const commName = community.subject || community.name || 'Comunidade sem nome';
        item.className = 'contact-item';
        item.dataset.id = community.id;
        item.dataset.name = commName;

        const initial = commName.charAt(0).toUpperCase();

        item.innerHTML = `
            <div class="contact-avatar" style="background: rgba(0,204,255,0.1); color: #00ccff; border-color: #00ccff;">${initial}</div>
            <div class="contact-info" style="flex: 1; min-width: 0;">
                <span class="contact-name" style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${commName}</span>
                    <span class="status-badge" style="border-color: #00ccff; color: #00ccff; padding: 2px 6px;">COMUNIDADE</span>
                </span>
                <span class="contact-number">${community.participantsCount || 0} participantes</span>
            </div>
        `;

        item.addEventListener('click', () => {
            document.querySelectorAll('#com-list-send-container .contact-item').forEach(el => el.classList.remove('selected'));
            item.classList.add('selected');
            state.selectedCommunityForSend = item.dataset.id;
        });

        container.appendChild(item);
    });
}

function setupMediaUploadComSend() {
    const uploadBtn = document.getElementById('upload-media-com-send');
    const fileInput = document.getElementById('file-media-com-send');
    if (!uploadBtn || !fileInput) return;

    uploadBtn.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
            state.comSendMediaBase64 = event.target.result;
            uploadBtn.innerHTML = `<div style="width: 100%; height: 100%; background-image: url('${state.comSendMediaBase64}'); background-size: cover; background-position: center; border-radius: 6px;"></div>`;
            uploadBtn.style.padding = "0";
            uploadBtn.style.border = "none";
        };
        reader.readAsDataURL(file);
    });
}

async function handleCommunitySendSubmit() {
    if (!state.selectedCommunityForSend) {
        alert("Por favor, selecione uma comunidade primeiro!");
        return;
    }

    const textArea = document.getElementById('com-send-text');
    const textContent = textArea ? textArea.value.trim() : '';
    const hasMedia = !!state.comSendMediaBase64;

    if (!textContent && !hasMedia) {
        alert("Você precisa digitar um texto ou anexar uma mídia para disparar!");
        return;
    }

    const btn = document.getElementById('btn-finish-com-send');
    const originalText = btn.innerText;
    btn.innerText = 'Enviando...';
    btn.disabled = true;

    try {
        let textResult = true;
        let mediaResult = true;

        if (textContent && !hasMedia) {
            textResult = await runInWa(async (targetId, txt) => {
                try {
                    return await window.FMARK.sendTextMessage(targetId, txt);
                } catch(e) { return false; }
            }, [state.selectedCommunityForSend, textContent]);
        }

        if (hasMedia) {
            mediaResult = await runInWa(async (targetId, b64, caption) => {
                try {
                    return await window.FMARK.sendFileMessage(targetId, b64, { type: 'auto-detect', caption: caption });
                } catch(e) { return false; }
            }, [state.selectedCommunityForSend, state.comSendMediaBase64, textContent]);
        }

        if (textResult !== false && mediaResult !== false) {
            alert("Mensagem enviada com sucesso para a Comunidade!");
            document.getElementById('close-flow-com-send').click();
            if (textArea) textArea.value = '';
            state.comSendMediaBase64 = null;
            
            const uploadBtn = document.getElementById('upload-media-com-send');
            if (uploadBtn) {
                uploadBtn.innerHTML = `<svg viewBox="0 0 24 24" style="width: 24px; height: 24px; fill: currentColor; margin-bottom: 5px;"><path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z"></path></svg><span style="font-size: 11px;">Anexar Mídia (Opcional)</span>`;
                uploadBtn.style.padding = "";
                uploadBtn.style.border = "";
            }
        } else {
            alert("Falha ao enviar a mensagem. Verifique se você é um administrador da comunidade de avisos.");
        }

    } catch (err) {
        console.error(err);
        alert("Ocorreu um erro inesperado ao enviar.");
    }

    btn.innerText = originalText;
    btn.disabled = false;
}

document.addEventListener('DOMContentLoaded', () => {
    setupMediaUploadComSend();
});

// --------------------------------- //

async function loadGroupsForCampaign() {
    const container = document.getElementById('campaign-group-list');
    if (!container) return;
    
    container.innerHTML = '<div style="text-align:center; padding:20px; color:var(--cp-neon);">Carregando grupos...</div>';

    const groupsJson = await runInWa(async () => {
        if (!window.FMARK || !window.FMARK.infoAllGroupList) return "[]";
        return await window.FMARK.infoAllGroupList();
    });

    const groups = JSON.parse(groupsJson || "[]");
    container.innerHTML = '';
    state.selectedGroupsForCampaign = [];

    if (groups.error || groups.length === 0) {
        container.innerHTML = '<div style="text-align:center; padding:20px;">Nenhum grupo encontrado.</div>';
        return;
    }

    groups.forEach(group => {
        const item = document.createElement('div');
        const groupName = group.subject || group.name || group.formattedTitle || 'Grupo sem nome';
        const participantsCount = group.participantsCount || 0;

        item.className = 'contact-item';
        item.dataset.id = group.id;
        item.dataset.name = groupName;

        const initial = groupName.charAt(0).toUpperCase();
        const adminBadge = group.isAdmin
            ? '<span style="color:#00ff00; font-size:10px; border:1px solid rgba(0,255,0,0.3); background:rgba(0,255,0,0.1); padding:2px 4px; border-radius:4px; margin-left:8px;">ADMIN</span>'
            : '<span style="color:#ff5555; font-size:10px; border:1px solid rgba(255,85,85,0.3); background:rgba(255,85,85,0.1); padding:2px 4px; border-radius:4px; margin-left:8px;">MEMBRO</span>';

        item.innerHTML = `
    <div class="contact-avatar">${initial}</div>
    <div class="contact-info" style="flex: 1; min-width: 0;">
        <span class="contact-name" style="display: flex; justify-content: space-between; align-items: center;">
            <span style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${group.subject || 'Grupo sem nome'}</span>
            ${typeof adminBadge !== 'undefined' ? adminBadge : ''}
        </span>
        <span class="contact-number">${group.participantsCount} participantes</span>
    </div>
`;

        item.addEventListener('click', () => {
            item.classList.toggle('selected');
            const id = item.dataset.id;
            
            if (item.classList.contains('selected')) {
                state.selectedGroupsForCampaign.push(id);
            } else {
                state.selectedGroupsForCampaign = state.selectedGroupsForCampaign.filter(gId => gId !== id);
            }
        });

        container.appendChild(item);
    });
}

async function handleSendCampaign() {
    if (state.selectedGroupsForCampaign.length === 0) {
        alert("Selecione pelo menos um grupo de destino!");
        return;
    }

    const flowContainer = document.getElementById('campaign-flow-container');
    const items = flowContainer.querySelectorAll('.camp-flow-item');
    
    if (items.length === 0) {
        alert("Adicione pelo menos um texto ou imagem ao fluxo da campanha!");
        return;
    }

    const payload = [];
    let hasError = false;

    items.forEach(item => {
        let delayBefore = 10;
        if (item.previousElementSibling && item.previousElementSibling.classList.contains('camp-flow-delay')) {
            delayBefore = parseInt(item.previousElementSibling.querySelector('.camp-delay-input').value) || 10;
        }

        const type = item.dataset.type;
        if (type === 'text') {
            const text = item.querySelector('.camp-val-text').value.trim().replace(/\\n/g, '\n');
            if (!text) hasError = true;
            const mentionAll = item.querySelector('.camp-mention-all')?.checked || false;
            payload.push({ type: 'text', content: text, mentionAll: mentionAll, delayBefore: delayBefore });
        } else if (type === 'image' || type === 'video') {
            const b64 = item.querySelector('.camp-val-base64').value;
            const caption = item.querySelector('.camp-val-caption').value.trim().replace(/\\n/g, '\n');
            if (!b64) hasError = true;
            payload.push({ type: type, content: caption, base64: b64, delayBefore: delayBefore });
        } else if (type === 'poll') {
            const name = item.querySelector('.camp-poll-name').value.trim();
            const optionsArr = Array.from(item.querySelectorAll('.camp-poll-opt')).map(inp => inp.value.trim()).filter(v => v !== '');
            if (!name || optionsArr.length < 2) hasError = true;
            payload.push({ type: 'poll', name: name, options: optionsArr, delayBefore: delayBefore });
        }
    });

    if (hasError) {
        alert("Preencha todos os campos corretamente. Enquetes exigem no mínimo 2 opções e mídias precisam ser carregadas.");
        return;
    }

    const btn = document.getElementById('btn-send-campaign');
    const originalText = btn.innerHTML;
    btn.innerText = 'ENVIANDO...';
    btn.disabled = true;
    btn.classList.add('btn-sending-anim');

    let success = 0;
    let fails = 0;

    for (let i = 0; i < state.selectedGroupsForCampaign.length; i++) {
        const groupId = state.selectedGroupsForCampaign[i];
        
        const result = await runInWa(async (gId, flowPayload) => {
            try {
                let isFirst = true;
                for (const msg of flowPayload) {
                    if (!isFirst && msg.delayBefore) {
                        await new Promise(r => setTimeout(r, msg.delayBefore * 1000));
                    }
                    isFirst = false;

                    if (msg.type === 'text') {
                        const opts = { detectMentioned: false, linkPreview: true, waitForAck: true };
                        if (msg.mentionAll) {
                            const metadata = await window.FMARK.getGroupMetadata(gId);
                            const participants = metadata?.participants?.getModelsArray
                                ? metadata.participants.getModelsArray()
                                : (metadata?.participants?._models || []);
                            const me = window.FMARK.getMyUserId();
                            const meUser = me ? me.user : "";
                            const mentionedIds = [];
                            for (const p of participants) {
                                const isMe = p.id.user === meUser || (p.contact?.id?.user === meUser);
                                if (isMe) continue;
                                let validId = p.id._serialized;
                                if (p.id.server === 'lid') {
                                    try {
                                        const pn = window.Store?.WeblidPnCache?.getPhoneNumber(p.id) || window.Store?.ApiContact?.getPhoneNumber(p.id);
                                        if (pn) validId = pn._serialized || `${pn.user}@c.us`;
                                    } catch (e) {}
                                }
                                mentionedIds.push(validId);
                            }
                            opts.detectMentioned = true;
                            opts.oculteMembers = true;
                            opts.listMention = mentionedIds;
                        }
                        if (window.FMARK.sendTextMessage) {
                            await window.FMARK.sendTextMessage(gId, msg.content, opts);
                        } else {
                            await window.FMARK.sendMessage(gId, msg.content);
                        }
                    } else if (msg.type === 'image' || msg.type === 'video') {
                        window.FMARK.sendFileMessage(gId, msg.base64, { type: 'auto-detect', caption: msg.content })
                            .catch(err => console.log('Ignorando timeout, WA continua upload.'));
                    } else if (msg.type === 'poll') {
                        if (window.FMARK.sendCreatePollMessage) {
                            await window.FMARK.sendCreatePollMessage(gId, msg.name, msg.options);
                        } else if (window.FMARK.sendPoolTeste) {
                            await window.FMARK.sendPoolTeste(gId, msg.name, msg.options);
                        }
                    }
                }
                return true;
            } catch (e) {
                return false;
            }
        }, [groupId, payload]);

        if (result) success++;
        else fails++;

        if (i < state.selectedGroupsForCampaign.length - 1) {
            const delayMinInput = document.getElementById('camp-delay-min');
            const delayMaxInput = document.getElementById('camp-delay-max');
            const min = (parseInt(delayMinInput?.value) || 10) * 1000;
            const max = (parseInt(delayMaxInput?.value) || 30) * 1000;
            const randomDelay = Math.floor(Math.random() * (max - min + 1)) + min;
            await new Promise(r => setTimeout(r, randomDelay));
        }
    }

    btn.innerHTML = originalText;
    btn.disabled = false;
    btn.classList.remove('btn-sending-anim');

    alert(`Campanha finalizada!\nEnviado com sucesso para: ${success} grupos\nFalhas: ${fails}`);
}

async function saveCampaignToStorage(name, groups, payload) {
    return new Promise((resolve) => {
        chrome.storage.local.get(['wagroup_campaigns'], (result) => {
            const campaigns = result.wagroup_campaigns || [];
            const newCampaign = {
                id: 'camp_' + Date.now(),
                name: name,
                groups: groups,
                payload: payload,
                date: new Date().toLocaleDateString('pt-BR')
            };
            campaigns.push(newCampaign);
            chrome.storage.local.set({ wagroup_campaigns: campaigns }, () => {
                if (chrome.runtime.lastError) {
                    console.error("Erro do Chrome:", chrome.runtime.lastError.message);
                    alert("Erro ao salvar: O arquivo de video e muito grande para o armazenamento atual da extensao. Tente um video menor.");
                    resolve(false);
                } else {
                    resolve(true);
                }
            });
        });
    });
}

async function getSavedCampaigns() {
    return new Promise((resolve) => {
        chrome.storage.local.get(['wagroup_campaigns'], (result) => {
            resolve(result.wagroup_campaigns || []);
        });
    });
}

async function deleteCampaignFromStorage(id) {
    return new Promise((resolve) => {
        chrome.storage.local.get(['wagroup_campaigns'], (result) => {
            const campaigns = (result.wagroup_campaigns || []).filter(c => c.id !== id);
            chrome.storage.local.set({ wagroup_campaigns: campaigns }, () => resolve(true));
        });
    });
}

async function saveScheduledCampaign(scheduledData) {
    return new Promise((resolve) => {
        chrome.storage.local.get(['wagroup_scheduled'], (result) => {
            const scheduled = result.wagroup_scheduled || [];
            scheduled.push(scheduledData);
            chrome.storage.local.set({ wagroup_scheduled: scheduled }, () => {
                if (chrome.runtime.lastError) {
                    console.error("Erro ao agendar:", chrome.runtime.lastError.message);
                    resolve(false);
                } else {
                    resolve(true);
                }
            });
        });
    });
}

async function getScheduledCampaigns() {
    return new Promise((resolve) => {
        chrome.storage.local.get(['wagroup_scheduled'], (result) => {
            resolve(result.wagroup_scheduled || []);
        });
    });
}

async function deleteScheduledCampaign(id) {
    return new Promise((resolve) => {
        chrome.storage.local.get(['wagroup_scheduled'], (result) => {
            const scheduled = (result.wagroup_scheduled || []).filter(s => s.id !== id);
            chrome.storage.local.set({ wagroup_scheduled: scheduled }, () => resolve(true));
        });
    });
}

async function executeScheduledCampaign(scheduledItem) {
    const btn = document.getElementById('btn-send-campaign');
    const originalText = btn ? btn.innerHTML : '';
    if (btn) {
        btn.innerText = 'DISPARO AGENDADO...';
        btn.disabled = true;
        btn.classList.add('btn-sending-anim');
    }

    let success = 0;
    let fails = 0;

    for (let i = 0; i < scheduledItem.groups.length; i++) {
        const groupId = scheduledItem.groups[i];

        const result = await runInWa(async (gId, flowPayload) => {
            try {
                let isFirst = true;
                for (const msg of flowPayload) {
                    if (!isFirst && msg.delayBefore) {
                        await new Promise(r => setTimeout(r, msg.delayBefore * 1000));
                    }
                    isFirst = false;

                    if (msg.type === 'text') {
                        const opts = { detectMentioned: false, linkPreview: true, waitForAck: true };
                        if (msg.mentionAll) {
                            const metadata = await window.FMARK.getGroupMetadata(gId);
                            const participants = metadata?.participants?.getModelsArray
                                ? metadata.participants.getModelsArray()
                                : (metadata?.participants?._models || []);
                            const me = window.FMARK.getMyUserId();
                            const meUser = me ? me.user : "";
                            const mentionedIds = [];
                            for (const p of participants) {
                                const isMe = p.id.user === meUser || (p.contact?.id?.user === meUser);
                                if (isMe) continue;
                                let validId = p.id._serialized;
                                if (p.id.server === 'lid') {
                                    try {
                                        const pn = window.Store?.WeblidPnCache?.getPhoneNumber(p.id) || window.Store?.ApiContact?.getPhoneNumber(p.id);
                                        if (pn) validId = pn._serialized || `${pn.user}@c.us`;
                                    } catch (e) {}
                                }
                                mentionedIds.push(validId);
                            }
                            opts.detectMentioned = true;
                            opts.oculteMembers = true;
                            opts.listMention = mentionedIds;
                        }
                        if (window.FMARK.sendTextMessage) {
                            await window.FMARK.sendTextMessage(gId, msg.content, opts);
                        } else {
                            await window.FMARK.sendMessage(gId, msg.content);
                        }
                    } else if (msg.type === 'image' || msg.type === 'video') {
                        window.FMARK.sendFileMessage(gId, msg.base64, { type: 'auto-detect', caption: msg.content })
                            .catch(err => console.log('Ignorando timeout, WA continua upload.'));
                    } else if (msg.type === 'poll') {
                        if (window.FMARK.sendCreatePollMessage) {
                            await window.FMARK.sendCreatePollMessage(gId, msg.name, msg.options);
                        } else if (window.FMARK.sendPoolTeste) {
                            await window.FMARK.sendPoolTeste(gId, msg.name, msg.options);
                        }
                    }
                }
                return true;
            } catch (e) {
                return false;
            }
        }, [groupId, scheduledItem.payload]);

        if (result) success++;
        else fails++;

        if (i < scheduledItem.groups.length - 1) {
            const min = (scheduledItem.delayMin || 10) * 1000;
            const max = (scheduledItem.delayMax || 30) * 1000;
            const randomDelay = Math.floor(Math.random() * (max - min + 1)) + min;
            await new Promise(r => setTimeout(r, randomDelay));
        }
    }

    if (btn) {
        btn.innerHTML = originalText;
        btn.disabled = false;
        btn.classList.remove('btn-sending-anim');
    }

    alert(`Disparo agendado concluido!\nEnviado com sucesso para: ${success} grupos\nFalhas: ${fails}`);
}

let scheduleCheckInterval = null;

async function checkScheduledCampaigns() {
    const scheduled = await getScheduledCampaigns();
    const now = new Date();
    const pending = scheduled.filter(s => !s.fired);

    for (const item of pending) {
        const scheduledDate = new Date(item.scheduledTimestamp);

        if (now.getFullYear() === scheduledDate.getFullYear() &&
            now.getMonth() === scheduledDate.getMonth() &&
            now.getDate() === scheduledDate.getDate() &&
            now.getHours() === scheduledDate.getHours() &&
            now.getMinutes() === scheduledDate.getMinutes()) {

            await deleteScheduledCampaign(item.id);
            await executeScheduledCampaign(item);
            if (typeof renderScheduledList === 'function') renderScheduledList();
            return;
        }
    }

    for (const item of pending) {
        const scheduledDate = new Date(item.scheduledTimestamp);
        if (now > scheduledDate && (now - scheduledDate) > 60000) {
            await deleteScheduledCampaign(item.id);
            if (typeof renderScheduledList === 'function') renderScheduledList();
        }
    }
}

function startScheduleChecker() {
    if (scheduleCheckInterval) clearInterval(scheduleCheckInterval);
    checkScheduledCampaigns();
    scheduleCheckInterval = setInterval(checkScheduledCampaigns, 15000);
}

async function saveAutoCampaign(autoData) {
    return new Promise((resolve) => {
        chrome.storage.local.set({ wagroup_auto_campaign: autoData }, () => {
            if (chrome.runtime.lastError) {
                console.error("Erro ao salvar auto:", chrome.runtime.lastError.message);
                resolve(false);
            } else {
                resolve(true);
            }
        });
    });
}

async function getAutoCampaign() {
    return new Promise((resolve) => {
        chrome.storage.local.get(['wagroup_auto_campaign'], (result) => {
            resolve(result.wagroup_auto_campaign || null);
        });
    });
}

async function deleteAutoCampaign() {
    return new Promise((resolve) => {
        chrome.storage.local.remove(['wagroup_auto_campaign'], () => resolve(true));
    });
}

async function executeAutoCampaign(autoItem) {
    const btn = document.getElementById('btn-send-campaign');
    const originalText = btn ? btn.innerHTML : '';
    if (btn) {
        btn.innerText = 'DISPARO AUTO...';
        btn.disabled = true;
        btn.classList.add('btn-sending-anim');
    }

    let success = 0;
    let fails = 0;

    for (let i = 0; i < autoItem.groups.length; i++) {
        const groupId = autoItem.groups[i];

        const result = await runInWa(async (gId, flowPayload) => {
            try {
                for (const msg of flowPayload) {
                    if (msg.type === 'text') {
                        const opts = { detectMentioned: false, linkPreview: true, waitForAck: true };
                        if (msg.mentionAll) {
                            const metadata = await window.FMARK.getGroupMetadata(gId);
                            const participants = metadata?.participants?.getModelsArray
                                ? metadata.participants.getModelsArray()
                                : (metadata?.participants?._models || []);
                            const me = window.FMARK.getMyUserId();
                            const meUser = me ? me.user : "";
                            const mentionedIds = [];
                            for (const p of participants) {
                                const isMe = p.id.user === meUser || (p.contact?.id?.user === meUser);
                                if (isMe) continue;
                                let validId = p.id._serialized;
                                if (p.id.server === 'lid') {
                                    try {
                                        const pn = window.Store?.WeblidPnCache?.getPhoneNumber(p.id) || window.Store?.ApiContact?.getPhoneNumber(p.id);
                                        if (pn) validId = pn._serialized || `${pn.user}@c.us`;
                                    } catch (e) {}
                                }
                                mentionedIds.push(validId);
                            }
                            opts.detectMentioned = true;
                            opts.oculteMembers = true;
                            opts.listMention = mentionedIds;
                        }
                        if (window.FMARK.sendTextMessage) {
                            await window.FMARK.sendTextMessage(gId, msg.content, opts);
                        } else {
                            await window.FMARK.sendMessage(gId, msg.content);
                        }
                    } else if (msg.type === 'image' || msg.type === 'video') {
                        window.FMARK.sendFileMessage(gId, msg.base64, { type: 'auto-detect', caption: msg.content })
                            .catch(err => console.log('Ignorando timeout, WA continua upload.'));
                    } else if (msg.type === 'poll') {
                        if (window.FMARK.sendCreatePollMessage) {
                            await window.FMARK.sendCreatePollMessage(gId, msg.name, msg.options);
                        } else if (window.FMARK.sendPoolTeste) {
                            await window.FMARK.sendPoolTeste(gId, msg.name, msg.options);
                        }
                    }
                    await new Promise(r => setTimeout(r, 2500));
                }
                return true;
            } catch (e) {
                return false;
            }
        }, [groupId, autoItem.payload]);

        if (result) success++;
        else fails++;

        await new Promise(r => setTimeout(r, 2000));
    }

    if (btn) {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }

    const autoData = await getAutoCampaign();
    if (autoData) {
        autoData.lastFired = new Date().toLocaleString('pt-BR');
        autoData.lastFiredDate = new Date().toDateString();
        await saveAutoCampaign(autoData);
    }

    if (typeof renderAutoCampaignStatus === 'function') renderAutoCampaignStatus();
}

let autoCheckInterval = null;
let autoLastFiredDate = null;

async function checkAutoCampaign() {
    const autoData = await getAutoCampaign();
    if (!autoData || !autoData.active) return;

    const now = new Date();
    const timeParts = autoData.time.split(':');
    const targetHour = parseInt(timeParts[0]);
    const targetMinute = parseInt(timeParts[1]);

    if (now.getHours() === targetHour && now.getMinutes() === targetMinute) {
        const todayStr = now.toDateString();
        if (autoLastFiredDate !== todayStr) {
            autoLastFiredDate = todayStr;
            await executeAutoCampaign(autoData);
        }
    }
}

function startAutoChecker() {
    if (autoCheckInterval) clearInterval(autoCheckInterval);
    checkAutoCampaign();
    autoCheckInterval = setInterval(checkAutoCampaign, 15000);
}