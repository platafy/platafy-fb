async function getNetworkTime() {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 3000);
        const req = await fetch('http://worldtimeapi.org/api/timezone/Etc/UTC', { signal: controller.signal });
        const json = await req.json();
        clearTimeout(timeoutId);
        return new Date(json.datetime).getTime();
    } catch (e) {
        return Date.now();
    }
}

async function checkLicenseStatus() {
    return new Promise((resolve) => {
        chrome.runtime.sendMessage({ action: "check_status" }, (response) => {
            if (response && response.active) {
                resolve('VALID');
            } else if (response && response.message && (response.message.includes('expirou') || response.message.includes('EXPIRED'))) {
                resolve('EXPIRED');
            } else {
                resolve('NO_LICENSE');
            }
        });
    });
}

class LicenseUI {
    constructor() {
        this.overlayId = "platafy-license-overlay";
    }

    createLicenseOverlay() {
        this.removeLicenseOverlay();
        
        const style = document.createElement('style');
        style.innerHTML = `
            @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Inter:wght@400;600&display=swap');
            @keyframes platafyPulse { 0% { box-shadow: 0 0 10px rgba(255, 170, 0, 0.2); } 50% { box-shadow: 0 0 25px rgba(255, 170, 0, 0.4); } 100% { box-shadow: 0 0 10px rgba(255, 170, 0, 0.2); } }
            .pf-license-btn:hover { background: #ffaa00 !important; box-shadow: 0 0 20px rgba(255, 170, 0, 0.6) !important; color: #0a0d1a !important; }
        `;
        document.head.appendChild(style);

        let e = document.createElement("div");
        e.id = this.overlayId;
        e.style.cssText = `
            position: fixed; top: 0; left: 0; width: 100%; height: 100%; 
            background-color: rgba(10, 13, 26, 0.92); backdrop-filter: blur(15px); -webkit-backdrop-filter: blur(15px);
            z-index: 99999999; display: flex; justify-content: center; align-items: center; 
            font-family: 'Inter', sans-serif;
        `;
        
        let t = document.createElement("div");
        t.style.cssText = `
            background: rgba(10, 13, 30, 0.85); border: 1px solid rgba(255, 170, 0, 0.3); 
            border-radius: 16px; width: 420px; max-width: 90%; 
            box-shadow: 0 0 30px rgba(0, 0, 0, 0.8); text-align: center; overflow: hidden;
            animation: platafyPulse 4s infinite;
        `;
        
        let n = document.createElement("div");
        n.style.cssText = `
            background: linear-gradient(135deg, #0a0d1a 0%, #4d5b9a 100%); color: #ffaa00; 
            padding: 25px; font-family: 'Orbitron', sans-serif; font-size: 24px; letter-spacing: 2px;
            text-shadow: 0 0 10px rgba(255, 170, 0, 0.5); border-bottom: 1px solid rgba(255, 170, 0, 0.3);
        `;
        n.innerHTML = "PLATAFY <span style='font-size:11px; font-family:\"Inter\", sans-serif; color:#b0b8cc; display:block; margin-top:8px; letter-spacing:1px; font-weight:600;'>SISTEMA BLOQUEADO</span>";
        
        let i = document.createElement("div");
        i.style.padding = "35px 30px";

        i.innerHTML = `
            <p style="margin-bottom: 25px; color: #b0b8cc; font-size: 14px; line-height:1.5;">Insira sua chave de autenticação para liberar os recursos da extensão.</p>
            
            <input type="text" id="license-input" placeholder="XXXX-XXXX-XXXX-XXXX" 
                style="width: 100%; padding: 15px; background: rgba(0,0,0,0.5); border: 1px solid rgba(255, 170, 0, 0.2); 
                border-radius: 8px; font-size: 16px; text-align: center; margin-bottom: 15px; 
                box-sizing: border-box; color: #fff; outline: none; transition: 0.3s; font-family: monospace; letter-spacing: 1px;">
            
            <div id="license-message" style="margin-bottom: 20px; min-height: 20px; font-size: 13px; font-weight:600;"></div>
            
            <button id="activate-btn" class="pf-license-btn"
                style="background: rgba(255, 255, 255, 0.03); border: 1px solid #ffaa00; color: #ffaa00; 
                padding: 15px 30px; border-radius: 8px; cursor: pointer; font-size: 15px; 
                font-weight: 600; width: 100%; transition: all 0.3s; letter-spacing: 1px;">
                AUTENTICAR
            </button>

            <p style="margin-top:20px; font-size:12px; color:#b0b8cc;">
                Trocou de computador? <a href="#" id="pf-transfer-link" style="color:#ffaa00; text-decoration:underline;">Desativar licença antiga / Liberar</a>
            </p>
        `;
        t.appendChild(n);
        t.appendChild(i);
        e.appendChild(t);
        document.body.appendChild(e);

        const input = document.getElementById('license-input');
        input.onfocus = () => { input.style.borderColor = '#ffaa00'; input.style.boxShadow = '0 0 15px rgba(255, 170, 0, 0.2)'; };
        input.onblur = () => { input.style.borderColor = 'rgba(255, 170, 0, 0.2)'; input.style.boxShadow = 'none'; };

        this.setupLicenseEvents();
    }

    setupLicenseEvents() {
        let e = document.getElementById("license-input"),
            t = document.getElementById("activate-btn"),
            transferLink = document.getElementById("pf-transfer-link");

        if (transferLink) {
            transferLink.addEventListener("click", (ev) => {
                ev.preventDefault();
                const key = prompt("Digite sua chave de licença para desvincular do computador antigo:");
                if (key && key.trim().length > 0) {
                    this.showMessage("Desvinculando no servidor...", "info");
                    chrome.runtime.sendMessage({ action: "deactivate_license", key: key.trim() }, (resp) => {
                        if (resp && resp.success) {
                            this.showMessage("✅ " + resp.message, "success");
                            e.value = key.trim();
                        } else {
                            this.showMessage("❌ " + (resp ? resp.message : "Erro ao desvincular"), "error");
                        }
                    });
                }
            });
        }

        e.addEventListener("input", (ev) => {
            let val = ev.target.value.replace(/[^a-zA-Z0-9]/g, "").toUpperCase(),
                formatted = val.match(/.{1,4}/g)?.join("-") || val;
            if (formatted.length > 19) formatted = formatted.substring(0, 19);
            ev.target.value = formatted;
        });

        t.addEventListener("click", async () => {
            let keyOriginal = e.value;
            let keyClean = keyOriginal.replace(/-/g, "");

            if (keyClean.length !== 16) {
                this.showMessage("⚠️ Chave inválida (deve ter 16 caracteres)", "error");
                return;
            }

            t.disabled = true;
            t.textContent = "VERIFICANDO...";
            t.style.opacity = "0.7";
            this.showMessage("Conectando ao servidor...", "info");
            
            chrome.runtime.sendMessage({
                action: "activate_license",
                key: keyOriginal,
                name: "Usuario PLATAFY"
            }, (resp) => {
                if (resp && resp.success) {
                    this.showMessage("✅ " + resp.message, "success");
                    setTimeout(() => {
                        this.removeLicenseOverlay();
                        startPlatafyApp();
                    }, 1500);
                } else {
                    this.showMessage("❌ " + (resp ? resp.message : "Erro de conexão"), "error");
                    t.disabled = false;
                    t.textContent = "AUTENTICAR";
                    t.style.opacity = "1";
                }
            });
        });

        e.addEventListener("keypress", (ev) => {
            if (ev.key === "Enter") t.click();
        });
    }

    showMessage(msg, type) {
        let el = document.getElementById("license-message");
        if (!el) return;
        
        let colors = {
            success: "#00ff00",
            error: "#ff5555",
            info: "#ffaa00"
        };
        
        el.style.color = colors[type] || "#ccc";
        el.textContent = msg;
    }

    removeLicenseOverlay() {
        let e = document.getElementById(this.overlayId);
        if (e) e.remove();
    }
}

function renderExpirationScreen() {
    const old = document.getElementById('platafy-expired-overlay');
    if(old) old.remove();

    const overlay = document.createElement('div');
    overlay.id = 'platafy-expired-overlay';
    overlay.style.cssText = `
        position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
        background: rgba(10,13,26,0.95); z-index: 99999999;
        display: flex; flex-direction: column; align-items: center; justify-content: center;
        color: white; font-family: 'Inter', sans-serif; text-align: center;
        backdrop-filter: blur(10px);
    `;
    
    overlay.innerHTML = `
        <div style="font-size: 60px; margin-bottom: 20px; filter: drop-shadow(0 0 10px #ff5555);">⏳</div>
        <h1 style="color: #ff5555; margin-bottom: 10px; font-size: 32px; font-family: 'Orbitron', sans-serif; letter-spacing: 2px; text-shadow: 0 0 15px rgba(255,85,85,0.5);">PERÍODO ENCERRADO</h1>
        <p style="font-size: 16px; color: #b0b8cc; max-width: 500px; line-height: 1.6; margin-bottom: 40px;">
            Obrigado por usar o <b>PLATAFY WAGroup</b>. Seu tempo de uso expirou.<br>
            Renove sua licença para continuar utilizando a ferramenta.
        </p>
        
        <button id="btnRemoveLicense" style="
            background: transparent; border: 1px solid #ffaa00; color: #ffaa00;
            padding: 15px 40px; cursor: pointer; font-size: 14px; border-radius: 8px; font-weight: 600; transition: 0.3s; letter-spacing: 1px;">
            INSERIR NOVA CHAVE
        </button>
    `;
    
    document.body.appendChild(overlay);
    
    const btnRemove = document.getElementById('btnRemoveLicense');
    btnRemove.onmouseover = () => { btnRemove.style.background = "#ffaa00"; btnRemove.style.color = "#0a0d1a"; btnRemove.style.boxShadow = "0 0 20px rgba(255, 170, 0, 0.4)"; };
    btnRemove.onmouseout = () => { btnRemove.style.background = "transparent"; btnRemove.style.color = "#ffaa00"; btnRemove.style.boxShadow = "none"; };

    btnRemove.onclick = async () => {
        chrome.runtime.sendMessage({ action: "deactivate_license" }, () => {
            location.reload();
        });
    };
}

const licenseUI = new LicenseUI();

function checkForUpdates() {
    chrome.runtime.sendMessage({ action: "check_version" }, (resp) => {
        if (resp && resp.update_available) {
            renderUpdateBanner(resp);
        }
    });
}

function renderUpdateBanner(info) {
    if (document.getElementById('platafy-update-banner')) return;
    
    const banner = document.createElement('div');
    banner.id = 'platafy-update-banner';
    banner.style.cssText = `
        position: fixed; top: 15px; right: 20px; z-index: 999999;
        background: linear-gradient(135deg, #1a2040 0%, #0a0d1a 100%);
        border: 1px solid #ffaa00; border-radius: 10px; padding: 14px 20px;
        box-shadow: 0 0 20px rgba(255, 170, 0, 0.4); color: #fff;
        font-family: 'Inter', sans-serif; font-size: 13px; display: flex;
        align-items: center; gap: 15px; animation: platafyPulse 3s infinite;
    `;
    
    banner.innerHTML = `
        <div>
            <div style="font-weight:700; color:#ffaa00; margin-bottom:3px;">🚀 Nova Atualização Disponível! (v${info.latest_version})</div>
            <div style="font-size:11px; color:#b0b8cc;">${info.changelog || 'Novas funcionalidades e melhorias ativas.'}</div>
        </div>
        <a href="${info.download_url}" target="_blank" style="
            background: #ffaa00; color: #0a0d1a; padding: 8px 14px; text-decoration: none;
            font-weight: 700; font-size: 12px; border-radius: 6px; white-space: nowrap;">
            Baixar v${info.latest_version}
        </a>
        <button id="pf-close-update-banner" style="
            background: none; border: none; color: #b0b8cc; font-size: 18px; cursor: pointer;">&times;</button>
    `;
    
    document.body.appendChild(banner);
    document.getElementById('pf-close-update-banner').onclick = () => banner.remove();
}

async function startPlatafyApp() {
    function injectScript(file) {
        return new Promise((resolve) => {
            var th = document.getElementsByTagName('body')[0];
            var s = document.createElement('script');
            s.setAttribute('type', 'text/javascript');
            s.setAttribute('src', chrome.runtime.getURL(file));
            s.onload = () => resolve(); 
            th.appendChild(s);
        });
    }

    await injectScript('scripts/fmark.js'); 

    checkForUpdates();

    (function injectPlatafyUI() {
        const appVersion = chrome.runtime.getManifest().version; 

        const style = document.createElement('style');
        style.id = 'platafy-ui-styles';
        style.textContent = `
            @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Inter:wght@400;600&display=swap');

            :root {
                --cp-neon: #ffaa00;
                --cp-border: rgba(255, 170, 0, 0.3);
                --cp-bg-deep: #0a0d1a;
                --cp-glass-bg: rgba(10, 13, 30, 0.7);
                --cp-text-main: #ffffff;
                --cp-text-muted: #b0b8cc;
                --font-cyber: 'Orbitron', sans-serif;
                --font-main: 'Inter', sans-serif;
            }

            @media screen and (min-width: 1441px) {
                ._ap4q::after {
                    position: fixed; top: 0; left: 0; z-index: 0; width: 100%; height: 127px; content: "";
                    background: linear-gradient(135deg, #0a0d1a 0%, #4d5b9a 100%) !important;
                    border-bottom: 2px solid var(--cp-neon) !important;
                    box-shadow: 0 0 15px var(--cp-border) !important;
                }
            }
            
            header, .xq3y45c, #side > header {
                background: linear-gradient(135deg, rgba(10, 13, 26, 0.8) 0%, rgba(77, 91, 154, 0.7) 100%) !important;
                backdrop-filter: blur(12px) !important;
                -webkit-backdrop-filter: blur(12px) !important;
                border-bottom: 1px solid var(--cp-border) !important;
                box-shadow: 0 4px 30px rgba(0, 0, 0, 0.5) !important;
            }
            
            #platafy-modal-container {
                position: fixed;
                top: 140px;
                right: 20px;
                width: 70px;
                height: auto;
                max-height: calc(100vh - 160px);
                background: var(--cp-glass-bg);
                backdrop-filter: blur(20px) saturate(180%);
                -webkit-backdrop-filter: blur(20px) saturate(180%);
                border: 1px solid var(--cp-border);
                border-radius: 16px;
                box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37), 0 0 15px rgba(255, 170, 0, 0.1) inset;
                z-index: 9999;
                display: flex;
                flex-direction: column;
                align-items: center;
                padding: 15px 0;
                overflow: hidden;
                transition: all 0.3s ease-in-out;
                font-family: var(--font-main);
            }

            #platafy-modal-container::before {
                content: "";
                position: absolute;
                top: 0;
                left: 10%;
                width: 80%;
                height: 2px;
                background: linear-gradient(90deg, transparent, var(--cp-neon), transparent);
                box-shadow: 0 0 10px var(--cp-neon);
            }

            .platafy-modal-header {
                font-family: var(--font-cyber);
                color: var(--cp-neon);
                font-size: 18px;
                text-shadow: 0 0 8px var(--cp-neon);
                margin-bottom: 20px;
                cursor: default;
                user-select: none;
            }

            .platafy-modal-actions {
                display: flex;
                flex-direction: column;
                gap: 12px;
                width: 100%;
                align-items: center;
            }

            .platafy-action-btn {
                width: 45px;
                height: 45px;
                background: rgba(255, 255, 255, 0.03);
                border: 1px solid rgba(255, 255, 255, 0.05);
                border-radius: 12px;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: all 0.2s ease;
                position: relative;
                overflow: hidden;
            }

            .platafy-action-btn:hover {
                background: rgba(255, 170, 0, 0.1);
                border-color: var(--cp-border);
                box-shadow: 0 0 10px rgba(255, 170, 0, 0.3);
                transform: translateY(-2px);
            }

            .platafy-action-btn:active {
                transform: translateY(1px);
                box-shadow: 0 0 5px rgba(255, 170, 0, 0.2);
            }

            .platafy-action-btn svg {
                width: 22px;
                height: 22px;
                fill: var(--cp-text-muted);
                transition: fill 0.2s ease, filter 0.2s ease;
            }

            .platafy-action-btn:hover svg {
                fill: var(--cp-neon);
                filter: drop-shadow(0 0 4px var(--cp-neon));
            }

            .platafy-action-btn::after {
                content: attr(data-tooltip);
                position: absolute;
                right: 60px;
                top: 50%;
                transform: translateY(-50%) translateX(10px);
                background: var(--cp-bg-deep);
                color: #fff;
                padding: 6px 10px;
                border-radius: 6px;
                font-size: 12px;
                white-space: nowrap;
                opacity: 0;
                visibility: hidden;
                transition: all 0.2s ease;
                border: 1px solid var(--cp-border);
                box-shadow: 0 2px 10px rgba(0,0,0,0.5);
                pointer-events: none;
            }

            .platafy-action-btn:hover::after {
                opacity: 1;
                visibility: visible;
                transform: translateY(-50%) translateX(0);
            }

            #platafy-log-panel {
                position: fixed;
                top: 140px;
                right: 110px;
                width: 320px;
                max-height: 450px;
                background: var(--cp-glass-bg);
                backdrop-filter: blur(20px);
                border: 1px solid var(--cp-border);
                border-radius: 12px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.8);
                display: none;
                flex-direction: column;
                z-index: 9998;
                overflow: hidden;
                font-family: var(--font-main);
            }

            #platafy-log-panel.active {
                display: flex;
            }

            .log-header {
                padding: 15px;
                background: rgba(255, 170, 0, 0.1);
                border-bottom: 1px solid var(--cp-border);
                color: var(--cp-neon);
                font-family: var(--font-cyber);
                font-size: 14px;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            .log-close {
                cursor: pointer;
                color: #fff;
                font-size: 18px;
            }

            .log-content {
                flex: 1;
                overflow-y: auto;
                padding: 10px;
                display: flex;
                flex-direction: column;
                gap: 8px;
            }

            .log-content::-webkit-scrollbar { width: 4px; }
            .log-content::-webkit-scrollbar-thumb { background: var(--cp-neon); border-radius: 2px; }

            .log-item {
                background: rgba(255, 255, 255, 0.03);
                border-radius: 6px;
                padding: 10px;
                font-size: 12px;
                color: var(--cp-text-main);
                border-left: 3px solid var(--cp-neon);
            }

            .log-item.type-joined { border-left-color: #00ff00; }
            .log-item.type-left { border-left-color: #ffcc00; }
            .log-item.type-action { border-left-color: #ff5555; }

            .log-meta {
                display: flex;
                justify-content: space-between;
                color: var(--cp-text-muted);
                font-size: 10px;
                margin-bottom: 4px;
            }
        `;
        document.head.appendChild(style);

        async function injectPlatafyBrand() {
            const delay = (ms) => new Promise(res => setTimeout(res, ms));
            let attempts = 0;
            while (attempts < 30) {
                let h = document.querySelector("header header div");
                if (h) {
                    let b = h.querySelector("div");
                    if (!b) { 
                        b = document.createElement("div"); 
                        h.appendChild(b); 
                    }
                    b.className = "platafy-brand-container";
                    b.innerHTML = `
                        <div style="display:flex; align-items:center; gap:8px; padding-top:6px;">
                            <strong style="font-family:'Orbitron', sans-serif; color:var(--cp-neon); font-size:22px; font-weight:normal; letter-spacing:1px; text-shadow:0 0 8px var(--cp-neon); border-right:1px solid var(--cp-border); padding-right:8px; line-height:normal;">PLATAFY</strong>
                            <span style="font-family:'Orbitron', sans-serif; font-size:9px; color:#fff; background:rgba(255, 170, 0, 0.1); backdrop-filter:blur(5px); border:1px solid var(--cp-border); box-shadow:0 0 5px rgba(255, 170, 0, 0.2); padding:2px 6px; border-radius:4px; position:relative; top:1px;">v${appVersion}</span>
                        </div>
                    `;
                    return;
                }
                attempts++; 
                await delay(1000);
            }
        }

        function injectPlatafyModal() {
            if (document.getElementById('platafy-modal-container')) return;

            const modalContainer = document.createElement('div');
            modalContainer.id = 'platafy-modal-container';

            const icons = {
                dashboard: '<svg viewBox="0 0 24 24"><path d="M13 3v6h8V3h-8zM3 3v11h8V3H3zm10 18h8v-8h-8v8zM3 21h8v-6H3v6z"></path></svg>',
                users: '<svg viewBox="0 0 24 24"><path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 1.34 5 3s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"></path></svg>',
                analytics: '<svg viewBox="0 0 24 24"><path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM9 17H7v-7h2v7zm4 0h-2V7h2v10zm4 0h-2v-4h2v4z"></path></svg>',
                settings: '<svg viewBox="0 0 24 24"><path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 0.44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5z"></path></svg>',
                power: '<svg viewBox="0 0 24 24"><path d="M13 3h-2v10h2V3zm4.83 2.17l-1.42 1.42C17.99 7.86 19 9.81 19 12c0 3.87-3.13 7-7 7s-7-3.13-7-7c0-2.19 1.01-4.14 2.58-5.42L6.17 5.17C4.23 6.82 3 9.26 3 12c0 4.97 4.03 9 9 9s9-4.03 9-9c0-2.74-1.23-5.18-3.17-6.83z"></path></svg>'
            };

            modalContainer.innerHTML = `
                <div class="platafy-modal-header">PF</div>
                <div class="platafy-modal-actions">
                    <button class="platafy-action-btn" data-action="stats" data-tooltip="Relatórios do Bot">${icons.analytics}</button>
                    <button class="platafy-action-btn" data-action="config" data-tooltip="Configurações">${icons.settings}</button>
                    <div style="height: 1px; width: 70%; background: var(--cp-border); margin: 5px 0;"></div>
                    <button class="platafy-action-btn" data-action="power" data-tooltip="Desligar Bot" style="border-color: rgba(0,255,0,0.2);">${icons.power.replace('<svg', '<svg style="fill: #00ff00;"')}</button>
                </div>
            `;

            document.body.appendChild(modalContainer);

            const logPanel = document.createElement('div');
            logPanel.id = 'platafy-log-panel';
            logPanel.innerHTML = `
                <div class="log-header">
                    <span>Log de Ações do Bot</span>
                    <span class="log-close" id="platafy-close-logs">&times;</span>
                </div>
                <div class="log-content" id="platafy-log-list">
                    <div style="text-align:center; padding:20px; color:#b0b8cc;">Nenhuma ação registrada ainda.</div>
                </div>
            `;
            document.body.appendChild(logPanel);

            document.getElementById('platafy-close-logs').addEventListener('click', () => {
                logPanel.classList.remove('active');
            });

            window.addEventListener('WA_LOG_FETCHED', (e) => {
                let logs = [];
                try {
                    logs = JSON.parse(e.detail || "[]");
                } catch (err) {
                    logs = [];
                }
                const list = document.getElementById('platafy-log-list');
                if (!list) return;
                
                if (logs.length === 0) {
                    list.innerHTML = '<div style="text-align:center; padding:20px; color:#b0b8cc;">Nenhuma ação registrada ainda.</div>';
                    return;
                }

                list.innerHTML = '';
                [...logs].reverse().forEach(log => {
                    const item = document.createElement('div');
                    item.className = `log-item type-${log.type}`;
                    item.innerHTML = `
                        <div class="log-meta">
                            <span>[${log.time}]</span>
                            <span style="max-width:120px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${log.group}</span>
                        </div>
                        <div>${log.text}</div>
                    `;
                    list.appendChild(item);
                });
            });

            function requestLogs() {
                window.dispatchEvent(new CustomEvent('WA_REQUEST_LOGS'));
            }

            modalContainer.querySelectorAll('.platafy-action-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const action = btn.getAttribute('data-action');
                    if (action === 'config') {
                        window.open(chrome.runtime.getURL('scripts/index.html'), '_blank');
                    }
                    if (action === 'stats') {
                        const panel = document.getElementById('platafy-log-panel');
                        panel.classList.toggle('active');
                        if (panel.classList.contains('active')) requestLogs();
                    }
                    if (action === 'power') {
                        window.dispatchEvent(new CustomEvent('WA_TOGGLE_BOT'));
                    }
                });
            });

            window.addEventListener('WA_BOT_STATE_CHANGED', (e) => {
                const isActive = e.detail;
                const pwrBtn = document.querySelector('.platafy-action-btn[data-action="power"]');
                if (pwrBtn) {
                    const svg = pwrBtn.querySelector('svg');
                    if (isActive) {
                        pwrBtn.setAttribute('data-tooltip', 'Desligar Bot');
                        pwrBtn.style.borderColor = 'rgba(0,255,0,0.2)';
                        svg.style.fill = '#00ff00';
                    } else {
                        pwrBtn.setAttribute('data-tooltip', 'Ligar Bot');
                        pwrBtn.style.borderColor = 'rgba(255,50,50,0.2)';
                        svg.style.fill = '#ff5555';
                    }
                }
            });

        }

        injectPlatafyBrand();
        injectPlatafyModal();
    })();
}

async function initializeSystem() {
    try {
        const status = await checkLicenseStatus();

        if (status === 'EXPIRED') {
            renderExpirationScreen();
            return; 
        }

        if (status === 'NO_LICENSE') {
            licenseUI.createLicenseOverlay();
            return;
        }

        startPlatafyApp();

    } catch (t) {
        startPlatafyApp(); 
    }
}

if (document.readyState === "loading") {
    window.addEventListener("DOMContentLoaded", initializeSystem);
} else {
    initializeSystem();
}