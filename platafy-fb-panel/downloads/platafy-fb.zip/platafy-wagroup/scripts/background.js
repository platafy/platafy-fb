// =================================================================
// 1. CONSTANTES E CONFIGURAÇÕES
// =================================================================
const LICENSE_CONFIG = {
    url: "https://wagroup.platafy.com",
    apiKey: "PF7A9E3B1D4C6F8A2E5",
    productId: "platafy-wagroup"
};

const WA_URL = "https://web.whatsapp.com/";

// =================================================================
// 2. INICIALIZAÇÃO E ABERTURA DO WHATSAPP
// =================================================================
function openWhatsApp() {
    chrome.tabs.query({ url: "*://web.whatsapp.com/*" }, (tabs) => {
        if (tabs.length > 0) {
            chrome.tabs.update(tabs[0].id, { active: true });
        } else {
            chrome.tabs.create({ url: WA_URL });
        }
    });
}

chrome.runtime.onInstalled.addListener(() => {
    getOrGenerateHWID();
    openWhatsApp();
});

chrome.action.onClicked.addListener(openWhatsApp);

// =================================================================
// 3. SISTEMA DE VALIDAÇÃO E PERSISTÊNCIA DE HWID
// =================================================================
async function getOrGenerateHWID() {
    try {
        // Tentar obter do storage sync primeiro (persiste mesmo ao desinstalar a extensão)
        const syncData = await chrome.storage.sync.get(['hwid']);
        if (syncData && syncData.hwid) {
            await chrome.storage.local.set({ hwid: syncData.hwid });
            return syncData.hwid;
        }

        const localData = await chrome.storage.local.get(['hwid']);
        if (localData && localData.hwid) {
            try { await chrome.storage.sync.set({ hwid: localData.hwid }); } catch (e) {}
            return localData.hwid;
        }

        // Criar novo HWID se não existir
        const newHwid = crypto.randomUUID(); 
        await chrome.storage.local.set({ hwid: newHwid });
        try { await chrome.storage.sync.set({ hwid: newHwid }); } catch (e) {}
        return newHwid;
    } catch (err) {
        return crypto.randomUUID();
    }
}

async function verifyLicense(licenseKey, clientName) {
    try {
        const hwid = await getOrGenerateHWID();
        
        const bodyData = {
            product_id: LICENSE_CONFIG.productId,
            license_code: licenseKey,
            client_name: clientName || "Cliente PLATAFY",
            verify_type: "non_envato"
        };

        const response = await fetch(`${LICENSE_CONFIG.url}/api/activate_license.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'LB-API-KEY': LICENSE_CONFIG.apiKey,
                'LB-URL': `http://${hwid}.hwid`,
                'LB-IP': '127.0.0.1'
            },
            body: JSON.stringify(bodyData)
        });

        const responseText = await response.text();
        const jsonStartIndex = responseText.indexOf('{');
        const jsonEndIndex = responseText.lastIndexOf('}') + 1;

        if (jsonStartIndex === -1 || jsonEndIndex === -1) {
            throw new Error("Resposta inválida do servidor.");
        }

        const cleanJson = responseText.substring(jsonStartIndex, jsonEndIndex);
        const result = JSON.parse(cleanJson);

        if (result.status === true || result.status === "true") {
            await chrome.storage.local.set({ 
                licenseKey: licenseKey,
                licenseStatus: 'active',
                clientName: clientName,
                expiryDate: result.end_date 
            });
            return { success: true, message: result.message };
        } else {
            await chrome.storage.local.set({ licenseStatus: 'inactive' });
            return { success: false, message: result.message || "Licença inválida." };
        }

    } catch (error) {
        return { success: false, message: "Erro de conexão. Verifique sua internet." };
    }
}

// ========== REVALIDAÇÃO REMOTA EM TEMPO REAL ==========
async function checkLicenseRemote() {
    try {
        const local = await chrome.storage.local.get(['licenseKey', 'licenseStatus']);
        if (!local.licenseKey || local.licenseStatus !== 'active') {
            return { active: false };
        }

        const hwid = await getOrGenerateHWID();
        
        const response = await fetch(`${LICENSE_CONFIG.url}/api/check_license.php`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'LB-API-KEY': LICENSE_CONFIG.apiKey,
                'LB-URL': `http://${hwid}.hwid`,
                'LB-IP': '127.0.0.1'
            },
            body: JSON.stringify({ license_code: local.licenseKey })
        });

        const data = await response.json();
        if (data.active) {
            if (data.expires_at) {
                await chrome.storage.local.set({ expiryDate: data.expires_at });
            }
            return { active: true };
        } else {
            // Licença expirada, revogada ou HWID trocado
            await chrome.storage.local.set({ licenseStatus: 'inactive' });
            return { active: false, message: data.message || "Licença inativa no servidor." };
        }
    } catch (err) {
        // Se houver erro de rede, mantém o status local temporariamente
        const local = await chrome.storage.local.get(['licenseStatus']);
        return { active: local.licenseStatus === 'active' };
    }
}

// ========== DESATIVAR / LIBERAR LICENÇA DO DISPOSITIVO ==========
async function deactivateLicense(licenseKey = null) {
    try {
        const local = await chrome.storage.local.get(['licenseKey']);
        const keyToDeactivate = licenseKey || local.licenseKey;
        
        if (keyToDeactivate) {
            const hwid = await getOrGenerateHWID();
            
            const response = await fetch(`${LICENSE_CONFIG.url}/api/deactivate_license.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'LB-API-KEY': LICENSE_CONFIG.apiKey,
                    'LB-URL': `http://${hwid}.hwid`,
                    'LB-IP': '127.0.0.1'
                },
                body: JSON.stringify({ license_code: keyToDeactivate })
            });
            const data = await response.json();
            await chrome.storage.local.remove(['licenseKey', 'licenseStatus', 'expiryDate', 'clientName']);
            return { success: true, message: data.message || "Licença desvinculada com sucesso!" };
        }
        
        await chrome.storage.local.remove(['licenseKey', 'licenseStatus', 'expiryDate', 'clientName']);
        return { success: true, message: "Licença removida localmente." };
    } catch (err) {
        await chrome.storage.local.remove(['licenseKey', 'licenseStatus', 'expiryDate', 'clientName']);
        return { success: true, message: "Licença removida localmente." };
    }
}

// ========== VERIFICAÇÃO DE ATUALIZAÇÃO AUTOMÁTICA ==========
async function checkAppVersion() {
    try {
        const manifest = chrome.runtime.getManifest();
        const currentVer = manifest.version || '1.0.0';
        
        const response = await fetch(`${LICENSE_CONFIG.url}/api/version_check.php?current_version=${currentVer}`);
        const data = await response.json();
        
        if (data.success && data.update_available) {
            await chrome.storage.local.set({
                updateAvailable: true,
                latestVersion: data.latest_version,
                downloadUrl: data.download_url,
                changelog: data.changelog,
                mandatory: data.mandatory
            });
            return data;
        } else {
            await chrome.storage.local.set({ updateAvailable: false });
            return { update_available: false };
        }
    } catch (err) {
        return { update_available: false };
    }
}

// =================================================================
// 4. COMUNICAÇÃO COM O CONTENT SCRIPT (TELA DE LOGIN E VERIFICAÇÃO)
// =================================================================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "activate_license") {
        verifyLicense(request.key, request.name).then(sendResponse);
        return true;
    }
    
    if (request.action === "check_status") {
        checkLicenseRemote().then(sendResponse);
        return true;
    }
    
    if (request.action === "deactivate_license") {
        deactivateLicense(request.key).then(sendResponse);
        return true;
    }
    
    if (request.action === "check_version") {
        checkAppVersion().then(sendResponse);
        return true;
    }
});